# AureaRebuild v2.4

Atualização grande focada em estabilidade, tela cheia e empacotamento correto da IPA.

## Correção principal desta versão
- `Info.plist` explícito e versionado.
- `CFBundleExecutable = AureaRebuild` declarado manualmente.
- `CFBundleIdentifier = com.aurea.aurearebuild`.
- Workflow valida o `.app`, o `Info.plist`, o executável e a IPA antes do upload.
- A IPA é criada a partir de `Payload/AureaRebuild.app`.
- Deploy mínimo iOS 16.3.

## Atualizações de interface
- Tela totalmente preta, sem painel cinza artificial ao reduzir o app.
- Editor ocupa melhor a tela do iPhone.
- Preview, playback, timeline e barra de ferramentas reorganizados.
- Inspector de camada com opacidade, escala e rotação.
- Undo/redo.
- Duplicar/excluir/adicionar camadas.
- Tela de exportação H.264.
- Estrutura pronta para expansão de mídia e efeitos.

## Build
Gerado com XcodeGen + xcodebuild em macOS GitHub Actions.
