import SwiftUI

struct ExportView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var model: EditorModel
    var body: some View {
        NavigationStack {
            Form {
                Section("Exportação") { LabeledContent("Resolução", value: "1080p (Full HD)"); LabeledContent("FPS", value: "30"); LabeledContent("Codec", value: "H.264"); LabeledContent("Qualidade", value: "Alta") }
                Section { Button { dismiss() } label: { Text("Exportar vídeo").frame(maxWidth: .infinity) } }
            }.navigationTitle("Exportar").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Fechar") { dismiss() } } }
        }
    }
}
