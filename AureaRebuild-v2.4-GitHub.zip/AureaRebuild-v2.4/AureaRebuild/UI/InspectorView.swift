import SwiftUI

struct InspectorView: View {
    @EnvironmentObject var model: EditorModel
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            Form {
                if let selected = model.selectedLayer {
                    Section("Camada") {
                        Text(selected.name)
                        SliderRow(title: "Opacidade", value: Binding(get: { selected.opacity }, set: { model.updateSelected { $0.opacity = $1 } }), range: 0...1, suffix: "%", multiplier: 100)
                        SliderRow(title: "Escala", value: Binding(get: { selected.scale }, set: { model.updateSelected { $0.scale = $1 } }), range: 0.1...3, suffix: "%", multiplier: 100)
                        SliderRow(title: "Rotação", value: Binding(get: { selected.rotation }, set: { model.updateSelected { $0.rotation = $1 } }), range: -180...180, suffix: "°", multiplier: 1)
                    }
                    Section("Ações") { Button("Excluir camada", role: .destructive) { model.deleteSelected(); dismiss() }; Button("Duplicar camada") { model.duplicateSelected() } }
                } else { VStack(spacing: 12) { Image(systemName: "square.stack.3d.up").font(.largeTitle); Text("Nenhuma camada").font(.headline); Text("Selecione uma camada na timeline.").foregroundStyle(.secondary) }.frame(maxWidth: .infinity, minHeight: 180) }
            }
            .navigationTitle("Inspetor")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("OK") { dismiss() } } }
        }
    }
}

private struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let suffix: String
    let multiplier: Double
    var body: some View {
        VStack(alignment: .leading) { HStack { Text(title); Spacer(); Text(String(format: "%.0f", value * multiplier) + suffix).monospacedDigit() }; Slider(value: $value, in: range) }
    }
}
