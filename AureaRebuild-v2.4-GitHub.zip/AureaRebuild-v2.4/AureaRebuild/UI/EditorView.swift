import SwiftUI

struct EditorView: View {
    @EnvironmentObject private var model: EditorModel
    @State private var showAdd = false

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black.ignoresSafeArea()
                VStack(spacing: 0) {
                    HeaderBar()
                    PreviewCanvas()
                        .frame(height: min(proxy.size.height * 0.43, 430))
                    PlaybackBar()
                    TimelineView()
                    BottomToolBar(showAdd: $showAdd)
                }
                .background(Color.black)
            }
        }
        .sheet(isPresented: $model.showInspector) { InspectorView() }
        .sheet(isPresented: $model.showExport) { ExportView() }
        .sheet(isPresented: $showAdd) { AddLayerView() }
    }
}

private struct HeaderBar: View {
    @EnvironmentObject var model: EditorModel
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: "photo.stack").font(.system(size: 22, weight: .bold))
            Text("Aurea").font(.system(size: 24, weight: .bold))
            Spacer()
            Button { model.undo() } label: { Image(systemName: "arrow.uturn.backward") }
            Button { model.redo() } label: { Image(systemName: "arrow.uturn.forward") }
            Button { model.showInspector = true } label: { Image(systemName: "slider.horizontal.3") }
        }
        .font(.system(size: 22, weight: .semibold))
        .foregroundStyle(.white)
        .padding(.horizontal, 20)
        .frame(height: 64)
        .background(Color.black)
    }
}

private struct PreviewCanvas: View {
    @EnvironmentObject var model: EditorModel
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, Color(red: 0.03, green: 0.08, blue: 0.14), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
            ForEach(0..<55, id: \.self) { i in
                Circle().fill(.white.opacity(0.35 + Double(i % 4) * 0.08))
                    .frame(width: CGFloat((i % 4) + 1) * 2.0)
                    .offset(x: CGFloat((i * 71) % 330) - 165, y: CGFloat((i * 47) % 220) - 110)
            }
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.blue.opacity(0.85))
                .frame(width: 170, height: 170)
                .rotationEffect(.degrees(model.selectedLayer?.rotation ?? 0))
                .scaleEffect(model.selectedLayer?.scale ?? 1)
                .opacity(model.selectedLayer?.opacity ?? 1)
            VStack { Spacer(); HStack { Text("PREVIEW").font(.caption.weight(.bold)); Spacer() } }
                .padding(12).foregroundStyle(.white.opacity(0.6))
        }
        .clipped()
    }
}

private struct PlaybackBar: View {
    @EnvironmentObject var model: EditorModel
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Text(time(model.currentTime)).monospacedDigit()
                Slider(value: $model.currentTime, in: 0...max(model.duration, 0.1))
                Text(time(model.duration)).monospacedDigit()
            }
            .font(.caption)
            .foregroundStyle(.white)
            HStack(spacing: 30) {
                Button { model.currentTime = 0 } label: { Image(systemName: "backward.end.fill") }
                Button { model.currentTime = min(model.duration, model.currentTime + 0.1) } label: { Image(systemName: "backward.frame.fill") }
                Image(systemName: "play.fill").font(.title2)
                Button { model.currentTime = min(model.duration, model.currentTime + 0.1) } label: { Image(systemName: "forward.frame.fill") }
                Button { model.currentTime = model.duration } label: { Image(systemName: "forward.end.fill") }
            }
            .foregroundStyle(.white)
        }
        .padding(.horizontal, 18).padding(.vertical, 8)
        .background(Color(red: 0.035, green: 0.035, blue: 0.04))
    }
    private func time(_ value: Double) -> String { String(format: "%02d:%05.2f", Int(value) / 60, value.truncatingRemainder(dividingBy: 60)) }
}

private struct TimelineView: View {
    @EnvironmentObject var model: EditorModel
    var body: some View {
        VStack(spacing: 0) {
            HStack { Text("Timeline").font(.title3.bold()); Text("1.00x").foregroundStyle(.secondary); Spacer(); Image(systemName: "number"); Text("\(Int(model.duration))s") }
                .foregroundStyle(.white).padding(.horizontal, 18).padding(.vertical, 12)
            GeometryReader { geo in
                ScrollView(.horizontal, showsIndicators: false) {
                    VStack(spacing: 7) {
                        HStack(spacing: 0) { ForEach(0...10, id: \.self) { i in Text("\(i)").frame(width: 70).font(.caption2).foregroundStyle(.secondary) } }
                        ForEach(model.layers) { layer in
                            HStack(spacing: 0) {
                                Image(systemName: layer.visible ? "eye.fill" : "eye.slash").frame(width: 34).foregroundStyle(.white)
                                Button { model.selectedLayerID = layer.id } label: {
                                    HStack { Text(layer.name).bold(); Spacer() }.padding(.horizontal, 12)
                                }
                                .frame(width: 560, height: 38, alignment: .leading)
                                .background(layer.id == model.selectedLayerID ? Color.blue.opacity(0.8) : trackColor(layer.type))
                                .clipShape(RoundedRectangle(cornerRadius: 6))
                            }
                        }
                        Spacer()
                    }.frame(minWidth: max(geo.size.width, 780), alignment: .leading)
                }
            }
        }
        .frame(minHeight: 220)
        .background(Color(red: 0.045, green: 0.055, blue: 0.08))
    }
    private func trackColor(_ type: String) -> Color { type == "effect" ? .purple.opacity(0.55) : type == "media" ? .gray.opacity(0.5) : .orange.opacity(0.55) }
}

private struct BottomToolBar: View {
    @EnvironmentObject var model: EditorModel
    @Binding var showAdd: Bool
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ToolButton("video", "Vídeo") { model.addLayer("Vídeo", type: "media") }
                ToolButton("textformat", "Texto") { model.addLayer("Texto", type: "text") }
                ToolButton("square", "Sólido") { model.addLayer("Sólido", type: "solid") }
                ToolButton("circle", "Forma") { model.addLayer("Forma", type: "shape") }
                ToolButton("plus.square.on.square", "Duplicar") { model.duplicateSelected() }
                ToolButton("wand.and.stars", "Efeitos") { model.showInspector = true }
                ToolButton("diamond", "Keyframe") { }
                ToolButton("square.and.arrow.up", "Exportar") { model.showExport = true }
                ToolButton("plus", "Adicionar") { showAdd = true }
            }.padding(8)
        }
        .frame(height: 82)
        .background(Color(red: 0.02, green: 0.025, blue: 0.035))
    }
    @ViewBuilder private func ToolButton(_ icon: String, _ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) { VStack(spacing: 5) { Image(systemName: icon).font(.title3); Text(title).font(.caption2.bold()) }.frame(width: 74, height: 66) }
            .foregroundStyle(.white).background(Color.white.opacity(0.055)).clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

private struct AddLayerView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var model: EditorModel
    var body: some View {
        NavigationStack { List { ForEach([("Forma","shape"),("Texto","text"),("Sólido","solid"),("Particular","effect")], id: \.0) { item in Button(item.0) { model.addLayer(item.0, type: item.1); dismiss() } } } .navigationTitle("Adicionar camada") .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Fechar") { dismiss() } } } }
    }
}

#Preview { EditorView().environmentObject(EditorModel()) }
