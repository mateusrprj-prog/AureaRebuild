import Foundation
import PhotosUI
import UniformTypeIdentifiers

final class MediaStore: ObservableObject {
    @Published var selectedItem: PhotosPickerItem?
    @Published var importedURL: URL?
    @MainActor
    func importVideo(from item: PhotosPickerItem, completion: @escaping (URL?) -> Void) {
        item.loadTransferable(type: Data.self) { result in
            switch result {
            case .success(let data):
                guard let data else { completion(nil); return }
                let url = FileManager.default.temporaryDirectory.appendingPathComponent("AureaMedia-\(UUID().uuidString).mov")
                try? data.write(to: url)
                DispatchQueue.main.async { self.importedURL = url; completion(url) }
            case .failure:
                DispatchQueue.main.async { completion(nil) }
            }
        }
    }
}
