import Foundation
import SwiftUI

final class EditorModel: ObservableObject {
    struct Layer: Identifiable, Codable, Equatable {
        let id: UUID
        var name: String
        var type: String
        var opacity: Double = 1
        var scale: Double = 1
        var rotation: Double = 0
        var visible: Bool = true
    }

    @Published var projectName = "Projeto 1"
    @Published var duration: Double = 10
    @Published var currentTime: Double = 0
    @Published var zoom: Double = 1
    @Published var layers: [Layer] = [
        Layer(id: UUID(), name: "Forma", type: "shape"),
        Layer(id: UUID(), name: "Particular", type: "effect"),
        Layer(id: UUID(), name: "Mídia", type: "media", visible: false)
    ]
    @Published var selectedLayerID: UUID?
    @Published var showInspector = false
    @Published var showExport = false
    @Published var showMediaPicker = false
    @Published var history: [Layer] = []
    @Published var redoStack: [Layer] = []

    var selectedLayer: Layer? {
        guard let id = selectedLayerID else { return nil }
        return layers.first { $0.id == id }
    }

    func addLayer(_ name: String, type: String) {
        history = layers
        layers.append(Layer(id: UUID(), name: name, type: type))
        redoStack.removeAll()
        selectedLayerID = layers.last?.id
    }

    func deleteSelected() {
        guard let id = selectedLayerID else { return }
        history = layers
        layers.removeAll { $0.id == id }
        selectedLayerID = layers.last?.id
        redoStack.removeAll()
    }

    func duplicateSelected() {
        guard let item = selectedLayer else { return }
        history = layers
        var copy = item
        copy = Layer(id: UUID(), name: item.name + " cópia", type: item.type, opacity: item.opacity, scale: item.scale, rotation: item.rotation, visible: item.visible)
        layers.append(copy)
        selectedLayerID = copy.id
        redoStack.removeAll()
    }

    func updateSelected(_ update: (inout Layer) -> Void) {
        guard let id = selectedLayerID, let index = layers.firstIndex(where: { $0.id == id }) else { return }
        history = layers
        update(&layers[index])
        redoStack.removeAll()
    }

    func undo() {
        guard !history.isEmpty else { return }
        redoStack = layers
        layers = history
        history.removeAll()
    }

    func redo() {
        guard !redoStack.isEmpty else { return }
        history = layers
        layers = redoStack
        redoStack.removeAll()
    }
}
