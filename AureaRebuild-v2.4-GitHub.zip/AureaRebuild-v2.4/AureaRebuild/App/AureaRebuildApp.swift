import SwiftUI

@main
struct AureaRebuildApp: App {
    @StateObject private var model = EditorModel()
    var body: some Scene {
        WindowGroup {
            EditorView()
                .environmentObject(model)
                .preferredColorScheme(.dark)
                .ignoresSafeArea(.container, edges: .bottom)
        }
    }
}
