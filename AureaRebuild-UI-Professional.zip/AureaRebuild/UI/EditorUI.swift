import SwiftUI

/// Main editor shell. Visual layer only; the host supplies media, timeline data and callbacks.
struct EditorUI: View {
    let projectName: String
    let currentTime: String
    let totalDuration: String
    let isPlaying: Bool
    let previewContent: AnyView
    let timelineTracks: [TimelineTrack]
    let playheadProgress: Double

    var onBack: () -> Void = {}
    var onExport: () -> Void = {}
    var onInspector: () -> Void = {}
    var onTogglePlay: () -> Void = {}
    var onSeek: (Double) -> Void = { _ in }
    var onToolSelected: (EditorTool) -> Void = { _ in }
    var onLayerSelected: (String) -> Void = { _ in }

    @State private var selectedTool: EditorTool = .media

    // Design tokens
    private let accent = Color(red: 0.22, green: 0.84, blue: 0.42)
    private let surface = Color(white: 0.07)
    private let surfaceElevated = Color(white: 0.10)
    private let border = Color.white.opacity(0.08)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                PreviewUI(
                    content: previewContent,
                    currentTime: currentTime,
                    isPlaying: isPlaying,
                    onTogglePlay: onTogglePlay
                )
                .frame(maxHeight: .infinity)

                transportBar

                TimelineUI(
                    currentTime: currentTime,
                    totalDuration: totalDuration,
                    tracks: timelineTracks,
                    playheadProgress: playheadProgress,
                    onSeek: onSeek,
                    onLayerSelected: onLayerSelected
                )
                .frame(height: 168)

                ToolbarUI(
                    selectedTool: $selectedTool,
                    onToolSelected: { tool in
                        withAnimation(.easeInOut(duration: 0.15)) {
                            selectedTool = tool
                        }
                        onToolSelected(tool)
                    }
                )
            }
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - Top Bar

    private var topBar: some View {
        HStack(spacing: 10) {
            Button(action: onBack) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white.opacity(0.9))
                    .frame(width: 32, height: 32)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Voltar")

            VStack(alignment: .leading, spacing: 1) {
                Text(projectName)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                Text("\(currentTime)  ·  \(totalDuration)")
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundColor(.white.opacity(0.45))
            }

            Spacer(minLength: 8)

            Button(action: onInspector) {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.white.opacity(0.85))
                    .frame(width: 34, height: 34)
                    .background(surfaceElevated)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Inspector")

            Button(action: onExport) {
                Text("Export")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(.black)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(accent)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Exportar projeto")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.black)
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(border)
                .frame(height: 0.5)
        }
    }

    // MARK: - Transport

    private var transportBar: some View {
        HStack(spacing: 0) {
            // Left utilities
            HStack(spacing: 4) {
                transportIcon("bookmark", label: "Marcador")
                transportChip("Fit")
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // Center playback
            HStack(spacing: 22) {
                Button(action: {}) {
                    Image(systemName: "backward.end.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Ir para o início")

                Button(action: onTogglePlay) {
                    ZStack {
                        Circle()
                            .fill(accent)
                            .frame(width: 40, height: 40)
                        Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.black)
                            .offset(x: isPlaying ? 0 : 1)
                    }
                }
                .buttonStyle(.plain)
                .accessibilityLabel(isPlaying ? "Pausar" : "Reproduzir")

                Button(action: {}) {
                    Image(systemName: "forward.end.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Ir para o fim")
            }

            // Right utilities
            HStack(spacing: 4) {
                transportIcon("arrow.uturn.backward", label: "Desfazer")
                transportIcon("arrow.uturn.forward", label: "Refazer")
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(surface)
        .overlay(alignment: .top) {
            Rectangle()
                .fill(border)
                .frame(height: 0.5)
        }
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(border)
                .frame(height: 0.5)
        }
    }

    private func transportIcon(_ name: String, label: String) -> some View {
        Button(action: {}) {
            Image(systemName: name)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white.opacity(0.55))
                .frame(width: 32, height: 32)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    private func transportChip(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 11, weight: .semibold))
            .foregroundColor(.white.opacity(0.6))
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(Color.white.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
    }
}

// MARK: - Tool enum

enum EditorTool: String, CaseIterable, Identifiable {
    case media, text, solid, adjustment, null, shape, audio, presets, element, inspector

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .media: return "photo.on.rectangle.angled"
        case .text: return "textformat"
        case .solid: return "rectangle.fill"
        case .adjustment: return "slider.horizontal.3"
        case .null: return "circle.dashed"
        case .shape: return "square.on.circle"
        case .audio: return "waveform"
        case .presets: return "sparkles"
        case .element: return "circle.grid.3x3"
        case .inspector: return "info.circle"
        }
    }

    var title: String {
        switch self {
        case .media: return "Media"
        case .text: return "Text"
        case .solid: return "Solid"
        case .adjustment: return "Adjust"
        case .null: return "Null"
        case .shape: return "Shape"
        case .audio: return "Audio"
        case .presets: return "Presets"
        case .element: return "Element"
        case .inspector: return "Info"
        }
    }
}
