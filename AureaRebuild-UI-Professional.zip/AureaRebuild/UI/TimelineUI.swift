import SwiftUI

struct TimelineTrack: Identifiable {
    let id: String
    let name: String
    let color: Color
    let height: CGFloat
    let icon: String
    var isSelected: Bool = false
}

/// Dense multi-track timeline with ruler, playhead and track rows.
/// Data is supplied by the host app; no editor logic is owned here.
struct TimelineUI: View {
    let currentTime: String
    let totalDuration: String
    let tracks: [TimelineTrack]
    let playheadProgress: Double
    var onSeek: (Double) -> Void = { _ in }
    var onLayerSelected: (String) -> Void = { _ in }

    private let accent = Color(red: 0.22, green: 0.84, blue: 0.42)
    private let trackLabelWidth: CGFloat = 48
    private let rulerHeight: CGFloat = 22

    var body: some View {
        GeometryReader { geo in
            let contentWidth = max(geo.size.width, 1)
            let playheadX = max(2, min(contentWidth - 2, playheadProgress * contentWidth))

            VStack(spacing: 0) {
                // Ruler + time labels
                ruler(width: contentWidth)

                // Tracks
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 3) {
                        if tracks.isEmpty {
                            emptyTimeline
                        } else {
                            ForEach(tracks) { track in
                                trackRow(track, width: contentWidth)
                            }
                        }
                    }
                    .padding(.vertical, 5)
                    .padding(.bottom, 4)
                }
            }
            .background(Color(white: 0.045))
            .overlay {
                // Playhead line spanning full height
                Rectangle()
                    .fill(accent)
                    .frame(width: 1.5)
                    .position(x: playheadX, y: geo.size.height / 2)
                    .allowsHitTesting(false)

                // Playhead head
                Capsule()
                    .fill(accent)
                    .frame(width: 9, height: 14)
                    .position(x: playheadX, y: 8)
                    .allowsHitTesting(false)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let progress = max(0, min(1, value.location.x / contentWidth))
                        onSeek(progress)
                    }
            )
        }
    }

    // MARK: - Ruler

    private func ruler(width: CGFloat) -> some View {
        ZStack(alignment: .leading) {
            Color(white: 0.065)

            // Tick marks
            Canvas { context, size in
                let majorCount = 6
                let minorPerMajor = 4
                let totalTicks = majorCount * minorPerMajor
                for i in 0...totalTicks {
                    let x = CGFloat(i) / CGFloat(totalTicks) * size.width
                    let isMajor = i % minorPerMajor == 0
                    let h: CGFloat = isMajor ? 10 : 5
                    var path = Path()
                    path.move(to: CGPoint(x: x, y: size.height - h))
                    path.addLine(to: CGPoint(x: x, y: size.height))
                    context.stroke(
                        path,
                        with: .color(.white.opacity(isMajor ? 0.35 : 0.15)),
                        lineWidth: 0.5
                    )
                }
            }

            HStack {
                Text(currentTime)
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundColor(accent)
                Spacer()
                Text(totalDuration)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundColor(.white.opacity(0.4))
            }
            .padding(.horizontal, 10)
        }
        .frame(height: rulerHeight)
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(Color.white.opacity(0.06))
                .frame(height: 0.5)
        }
    }

    // MARK: - Empty

    private var emptyTimeline: some View {
        VStack(spacing: 6) {
            Image(systemName: "film.stack")
                .font(.system(size: 20))
                .foregroundColor(.white.opacity(0.2))
            Text("Importe um vídeo para começar")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(.white.opacity(0.3))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
    }

    // MARK: - Track row

    private func trackRow(_ track: TimelineTrack, width: CGFloat) -> some View {
        HStack(spacing: 0) {
            // Side controls
            HStack(spacing: 5) {
                Image(systemName: "eye")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(.white.opacity(0.4))
                Image(systemName: track.icon)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(track.color.opacity(0.9))
            }
            .frame(width: trackLabelWidth)

            // Clip body
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .fill(track.color.opacity(track.isSelected ? 0.95 : 0.7))
                    .frame(height: track.height)
                    .overlay(
                        RoundedRectangle(cornerRadius: 4, style: .continuous)
                            .stroke(
                                track.isSelected ? Color.white.opacity(0.45) : Color.clear,
                                lineWidth: 1.5
                            )
                    )

                // Keyframe markers (visual only)
                HStack(spacing: 16) {
                    ForEach(0..<3, id: \.self) { _ in
                        DiamondShape()
                            .fill(Color.white.opacity(0.85))
                            .frame(width: 6, height: 6)
                    }
                }
                .padding(.leading, 10)

                Text(track.name)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.leading, 8)
                    .lineLimit(1)
                    .shadow(color: .black.opacity(0.4), radius: 1, x: 0, y: 0)
            }
            .padding(.trailing, 8)
            .contentShape(Rectangle())
            .onTapGesture { onLayerSelected(track.id) }
        }
        .padding(.leading, 2)
        .opacity(1)
    }
}

// MARK: - Diamond for keyframes

private struct DiamondShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.midY))
        path.closeSubpath()
        return path
    }
}
