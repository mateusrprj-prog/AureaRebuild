import Foundation
import SwiftUI
import UIKit
import Combine
import PhotosUI
import UniformTypeIdentifiers

@MainActor
final class MediaStore: ObservableObject {
    @Published var isImporting = false
    @Published var errorMessage: String?
    @Published var showVideoPicker = false

    func importVideo(from result: PHPickerResult) {
        guard result.itemProvider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) else {
            errorMessage = "O item selecionado não é um vídeo."
            return
        }

        isImporting = true
        result.itemProvider.loadFileRepresentation(forTypeIdentifier: UTType.movie.identifier) { [weak self] sourceURL, error in
            Task { @MainActor in
                defer { self?.isImporting = false }
                guard let self else { return }
                guard let sourceURL, error == nil else {
                    self.errorMessage = "Não foi possível importar o vídeo."
                    return
                }

                do {
                    let ext = sourceURL.pathExtension.isEmpty ? "mov" : sourceURL.pathExtension
                    let destination = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                        .appendingPathComponent("Imported-\(UUID().uuidString).\(ext)")
                    try? FileManager.default.removeItem(at: destination)
                    try FileManager.default.copyItem(at: sourceURL, to: destination)
                    self.onVideoImported?(destination)
                } catch {
                    self.errorMessage = "Não foi possível copiar o vídeo para o projeto."
                }
            }
        }
    }

    var onVideoImported: ((URL) -> Void)?
}

struct VideoPicker: UIViewControllerRepresentable {
    let onPicked: (PHPickerResult) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration(photoLibrary: .shared())
        configuration.filter = .videos
        configuration.selectionLimit = 1
        configuration.preferredAssetRepresentationMode = .current

        let controller = PHPickerViewController(configuration: configuration)
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: VideoPicker
        init(_ parent: VideoPicker) { self.parent = parent }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true) {
                if let result = results.first {
                    self.parent.onPicked(result)
                } else {
                    self.parent.onCancel()
                }
            }
        }
    }
}
