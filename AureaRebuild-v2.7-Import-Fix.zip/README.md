# Aurea Rebuild 2.7.0

Atualização focada em importação de vídeo e limpeza da interface.

- Botão **Importar vídeo** visível no topo, no centro do preview e na barra inferior.
- Importação da galeria usando `PhotosPicker` + `CoreTransferable`/`FileRepresentation`, evitando carregar o vídeo inteiro como `Data`.
- Validação real do arquivo e duração antes de criar a camada.
- O vídeo importado entra imediatamente no preview e na timeline.
- Relógio da timeline acompanha a reprodução do `AVPlayer`.
- Removidas as camadas fictícias que apareciam cinza no primeiro carregamento.
- Removido o placeholder com partículas/círculos cinza do preview vazio.
- Interface inicial mais limpa e com ação de importação impossível de confundir.
- Mantido iOS 16.3+ e bundle id `com.aurea.aurearebuild`.

Build: 2700
