# AureaRebuild V2

Grande atualização da interface do editor.

## Objetivos desta versão
- A janela inteira é preta e ocupa 100% do espaço disponível.
- Remove o fundo cinza/“área sobrando” quando o app é reduzido no seletor de apps.
- Layout adaptativo usando GeometryReader, sem altura fixa para a janela.
- Cabeçalho, preview, timeline e barra de ferramentas ocupam a janela inteira.
- Timeline com camadas selecionáveis e duração ajustável.
- Importação de vídeo via Photos.
- Inspector com opacidade, escala e rotação.
- Ações de adicionar, duplicar, dividir e excluir.
- Exportação H.264 do vídeo importado.
- Compatível com iOS 16.3+.
- Projeto gerado por XcodeGen para o workflow do GitHub Actions.

## Build
No GitHub Actions, o workflow existente pode continuar usando:
1. unzip do ZIP
2. brew install xcodegen
3. xcodegen generate --spec project.yml
4. xcodebuild archive
5. criação do IPA unsigned

Esta versão é uma reconstrução independente; não copia código proprietário do app original.
