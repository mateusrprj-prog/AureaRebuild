import Foundation
import AVFoundation
import SwiftUI

enum LayerKind: String, Codable, CaseIterable {
    case video = "Vídeo"
    case text = "Texto"
    case solid = "Sólido"
    case shape = "Forma"
    case audio = "Áudio"
}

struct EditorLayer: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var kind: LayerKind
    var start: Double = 0
    var duration: Double = 10
    var visible: Bool = true
    var opacity: Double = 1
    var scale: Double = 1
    var rotation: Double = 0
}

struct EditorProject: Codable {
    var name = "Projeto 1"
    var duration: Double = 10
    var layers: [EditorLayer] = [
        EditorLayer(name: "Forma", kind: .shape)
    ]
}

@MainActor
final class EditorModel: ObservableObject {
    @Published var project = EditorProject()
    @Published var currentTime: Double = 0
    @Published var selectedLayerID: UUID?
    @Published var importedVideoURL: URL?
    @Published var lastExportURL: URL?

    init() {
        selectedLayerID = project.layers.first?.id
    }

    var selectedLayer: EditorLayer? {
        guard let id = selectedLayerID else { return nil }
        return project.layers.first(where: { $0.id == id })
    }

    func add(_ kind: LayerKind) {
        let name = kind == .shape ? "Forma" : kind.rawValue
        let layer = EditorLayer(name: name, kind: kind)
        project.layers.append(layer)
        selectedLayerID = layer.id
    }

    func duplicateSelected() {
        guard let selected = selectedLayer,
              let index = project.layers.firstIndex(where: { $0.id == selected.id }) else { return }
        var copy = selected
        copy.id = UUID()
        copy.name += " 2"
        project.layers.insert(copy, at: index + 1)
        selectedLayerID = copy.id
    }

    func deleteSelected() {
        guard let id = selectedLayerID else { return }
        project.layers.removeAll { $0.id == id }
        selectedLayerID = project.layers.last?.id
    }

    func splitSelected() {
        guard let id = selectedLayerID,
              let index = project.layers.firstIndex(where: { $0.id == id }) else { return }
        let layer = project.layers[index]
        guard currentTime > layer.start + 0.05,
              currentTime < layer.start + layer.duration - 0.05 else { return }

        let leftDuration = currentTime - layer.start
        var right = layer
        right.id = UUID()
        right.start = currentTime
        right.duration = max(0.05, layer.duration - leftDuration)
        project.layers[index].duration = leftDuration
        project.layers.insert(right, at: index + 1)
        selectedLayerID = right.id
    }

    func updateSelected(opacity: Double? = nil, scale: Double? = nil, rotation: Double? = nil) {
        guard let id = selectedLayerID,
              let index = project.layers.firstIndex(where: { $0.id == id }) else { return }
        if let opacity { project.layers[index].opacity = opacity }
        if let scale { project.layers[index].scale = scale }
        if let rotation { project.layers[index].rotation = rotation }
    }

    func importVideo(url: URL) {
        importedVideoURL = url

        // AVAsset.duration foi descontinuado no iOS 16.
        // Carregamos a duração pela API assíncrona moderna para manter compatibilidade.
        Task { @MainActor in
            let asset = AVAsset(url: url)
            let loadedDuration = (try? await asset.load(.duration))?.seconds ?? 10
            let duration = max(0.1, loadedDuration.isFinite ? loadedDuration : 10)
            project.duration = duration

            if let index = project.layers.firstIndex(where: { $0.kind == .video }) {
                project.layers[index].duration = project.duration
            } else {
                let video = EditorLayer(name: "Vídeo", kind: .video, duration: project.duration)
                project.layers.insert(video, at: 0)
                selectedLayerID = video.id
            }
        }
    }
}
