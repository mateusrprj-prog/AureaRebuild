import SwiftUI

struct BottomToolbar: View {
    @ObservedObject var model: EditorModel
    @ObservedObject var mediaStore: MediaStore
    @Binding var showVideoPicker: Bool
    @Binding var showInspector: Bool
    @Binding var showProjectSettings: Bool

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                Button { showVideoPicker = true } label: { tool("video.badge.plus", "Vídeo") }

                Button { model.add(.text) } label: { tool("textformat", "Texto") }
                Button { model.add(.solid) } label: { tool("square.fill", "Sólido") }
                Button { model.add(.shape) } label: { tool("circle", "Forma") }
                Button { model.duplicateSelected() } label: { tool("square.on.square", "Duplicar") }
                Button { model.splitSelected() } label: { tool("scissors", "Dividir") }
                Button { model.deleteSelected() } label: { tool("trash", "Excluir") }
                Button { showInspector = true } label: { tool("wand.and.stars", "Efeitos") }
                Button { showProjectSettings = true } label: { tool("gearshape", "Ajustes") }
                Button { showInspector = true } label: { tool("diamond", "Keyframe") }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
        }
        .frame(height: 82)
        .background(Color.black)
        .overlay(alignment: .top) {
            Rectangle().fill(.white.opacity(0.08)).frame(height: 1)
        }
    }

    private func tool(_ icon: String, _ title: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 25, weight: .semibold))
            Text(title)
                .font(.system(size: 12, weight: .semibold))
                .lineLimit(1)
        }
        .frame(width: 82, height: 60)
        .foregroundStyle(.white)
        .background(Color.white.opacity(0.035))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
