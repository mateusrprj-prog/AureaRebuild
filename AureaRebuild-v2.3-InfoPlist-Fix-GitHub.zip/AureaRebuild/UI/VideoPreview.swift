import SwiftUI
import AVKit

struct VideoPreview: View {
    let url: URL?

    var body: some View {
        ZStack {
            Color.black

            if let url {
                VideoPlayer(player: AVPlayer(url: url))
                    .background(Color.black)
                    .aspectRatio(16/9, contentMode: .fit)
                    .clipped()
            } else {
                VStack(spacing: 18) {
                    Image(systemName: "film.stack")
                        .font(.system(size: 72, weight: .bold))
                    Text("Importe um vídeo para começar")
                        .font(.system(size: 24, weight: .bold))
                        .multilineTextAlignment(.center)
                    Text("Aurea V3")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.25))
                }
                .foregroundStyle(.white)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
        .clipped()
    }
}
