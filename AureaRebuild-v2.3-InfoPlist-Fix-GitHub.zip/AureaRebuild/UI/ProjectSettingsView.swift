import SwiftUI

struct ProjectSettingsView: View {
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Projeto") {
                    TextField("Nome", text: Binding(get: { model.project.name }, set: { model.project.name = $0 }))
                    Stepper("Duração: \(String(format: "%.1f", model.project.duration))s", value: Binding(get: { model.project.duration }, set: { model.project.duration = $0 }), in: 0.5...600, step: 0.5)
                }
                Section("Interface") {
                    Toggle("Modo tela cheia", isOn: .constant(true))
                    Toggle("Timeline compacta", isOn: .constant(false))
                }
            }
            .navigationTitle("Configurações")
            .safeAreaInset(edge: .bottom) {
                HStack { Spacer(); Button("Fechar") { dismiss() }.buttonStyle(.borderedProminent) }
                    .padding().background(.ultraThinMaterial)
            }
        }
    }
}
