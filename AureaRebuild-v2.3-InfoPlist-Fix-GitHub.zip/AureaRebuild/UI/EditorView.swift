import SwiftUI

struct EditorView: View {
    @StateObject private var model = EditorModel()
    @StateObject private var mediaStore = MediaStore()

    @State private var showVideoPicker = false
    @State private var showInspector = false
    @State private var showSettings = false
    @State private var showExport = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 0) {
                    header
                        .frame(height: 66)

                    previewArea
                        .frame(height: max(210, min(geo.size.height * 0.31, 470)))

                    TimelineView(model: model)
                        .frame(minHeight: 240, maxHeight: geo.size.height * 0.43)

                    BottomToolbar(
                        model: model,
                        mediaStore: mediaStore,
                        showVideoPicker: $showVideoPicker,
                        showInspector: $showInspector,
                        showProjectSettings: $showSettings
                    )
                }
                .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
                .background(Color.black)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .background(Color.black)
        .ignoresSafeArea(.all)
        .sheet(isPresented: $showInspector) {
            InspectorView(model: model)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showSettings) {
            ProjectSettingsView(model: model)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showExport) {
            ExportView(model: model)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showVideoPicker) {
            VideoPicker(
                onPicked: { result in
                    mediaStore.importVideo(from: result) { url in
                        model.importVideo(url: url)
                    }
                },
                onCancel: {}
            )
        }
        .alert("Importação", isPresented: Binding(
            get: { mediaStore.errorMessage != nil },
            set: { if !$0 { mediaStore.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(mediaStore.errorMessage ?? "")
        }
    }

    private var header: some View {
        HStack(spacing: 20) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 26, weight: .bold))

            Text("Aurea")
                .font(.system(size: 28, weight: .bold))

            Spacer()

            Button { } label: {
                Image(systemName: "arrow.uturn.backward")
            }

            Button { } label: {
                Image(systemName: "arrow.uturn.forward")
            }

            Button { showSettings = true } label: {
                Image(systemName: "gearshape")
            }

            Button { showInspector = true } label: {
                Image(systemName: "slider.horizontal.3")
            }
        }
        .font(.system(size: 25, weight: .semibold))
        .foregroundStyle(.white)
        .padding(.horizontal, 18)
        .background(Color.black)
    }

    private var previewArea: some View {
        VStack(spacing: 0) {
            VideoPreview(url: model.importedVideoURL)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            HStack(spacing: 12) {
                Text(time(model.currentTime))
                Slider(value: Binding(
                    get: { model.currentTime },
                    set: { model.currentTime = min(max(0, $0), model.project.duration) }
                ), in: 0...max(0.1, model.project.duration))
                Text(time(model.project.duration))
            }
            .font(.system(size: 13, weight: .semibold))
            .monospacedDigit()
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .frame(height: 42)
            .background(Color.black)
        }
        .background(Color.black)
    }

    private func time(_ value: Double) -> String {
        let m = Int(value) / 60
        let s = Int(value) % 60
        return String(format: "%02d:%02d", m, s)
    }
}
