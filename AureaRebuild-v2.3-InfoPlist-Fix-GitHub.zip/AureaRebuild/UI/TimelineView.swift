import SwiftUI

struct TimelineView: View {
    @ObservedObject var model: EditorModel

    var body: some View {
        VStack(spacing: 0) {
            timelineHeader
                .frame(height: 58)

            GeometryReader { geo in
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 8) {
                        ruler
                        ForEach(model.project.layers) { layer in
                            layerRow(layer, width: max(geo.size.width - 26, 320))
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.bottom, 10)
                }
                .overlay(alignment: .leading) {
                    Rectangle()
                        .fill(.red)
                        .frame(width: 2)
                        .offset(x: 12)
                        .allowsHitTesting(false)
                }
            }
        }
        .background(Color(red: 0.055, green: 0.055, blue: 0.06))
    }

    private var timelineHeader: some View {
        HStack(spacing: 14) {
            Text("Timeline")
                .font(.system(size: 26, weight: .bold))
                .lineLimit(1)

            Text(String(format: "%.2fx", 1.0))
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white.opacity(0.55))

            Spacer()

            Image(systemName: "number.circle")
                .font(.system(size: 25, weight: .medium))
                .foregroundStyle(.white.opacity(0.85))

            Slider(value: Binding(
                get: { model.project.duration },
                set: { model.project.duration = max(0.5, $0) }
            ), in: 1...60)
            .frame(width: 130)

            Text(timeText(model.project.duration))
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.white.opacity(0.55))
                .monospacedDigit()
        }
        .padding(.horizontal, 14)
        .foregroundStyle(.white)
        .background(Color(red: 0.055, green: 0.055, blue: 0.06))
    }

    private var ruler: some View {
        HStack(spacing: 0) {
            ForEach(0..<11, id: \.self) { i in
                VStack(spacing: 4) {
                    Rectangle()
                        .fill(.white.opacity(0.35))
                        .frame(width: 1, height: i % 5 == 0 ? 14 : 8)
                    Text("\(i)")
                        .font(.system(size: 10))
                        .foregroundStyle(.white.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 34)
    }

    private func layerRow(_ layer: EditorLayer, width: CGFloat) -> some View {
        let selected = model.selectedLayerID == layer.id

        return Button {
            model.selectedLayerID = layer.id
        } label: {
            HStack(spacing: 0) {
                Image(systemName: icon(for: layer.kind))
                    .frame(width: 34)

                Text(layer.name)
                    .font(.system(size: 16, weight: .semibold))
                    .lineLimit(1)
                    .frame(width: 105, alignment: .leading)

                GeometryReader { barGeo in
                    let total = max(model.project.duration, 0.1)
                    let x = CGFloat(layer.start / total) * barGeo.size.width
                    let w = max(70, CGFloat(layer.duration / total) * barGeo.size.width)

                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(color(for: layer.kind).opacity(selected ? 0.95 : 0.72))
                            .frame(width: min(w, barGeo.size.width), height: 38)
                            .offset(x: min(x, max(0, barGeo.size.width - 70)))

                        if selected {
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(.white.opacity(0.9), lineWidth: 1.5)
                                .frame(width: min(w, barGeo.size.width), height: 38)
                                .offset(x: min(x, max(0, barGeo.size.width - 70)))
                        }
                    }
                }
            }
            .frame(width: width, height: 46)
            .foregroundStyle(.white)
            .background(Color.white.opacity(selected ? 0.06 : 0.01))
            .clipShape(RoundedRectangle(cornerRadius: 9))
        }
        .buttonStyle(.plain)
    }

    private func icon(for kind: LayerKind) -> String {
        switch kind {
        case .video: return "video"
        case .text: return "textformat"
        case .solid: return "square.fill"
        case .shape: return "circle"
        case .audio: return "music.note"
        }
    }

    private func color(for kind: LayerKind) -> Color {
        switch kind {
        case .video: return .gray
        case .text: return .purple
        case .solid: return .orange
        case .shape: return .blue
        case .audio: return .green
        }
    }

    private func timeText(_ value: Double) -> String {
        String(format: "%.1fs", value)
    }
}
