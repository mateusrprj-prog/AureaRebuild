import SwiftUI
import UIKit

@main
struct AureaRebuildApp: App {
    init() {
        let nav = UINavigationBarAppearance()
        nav.configureWithOpaqueBackground()
        nav.backgroundColor = .black
        nav.shadowColor = .clear
        UINavigationBar.appearance().standardAppearance = nav
        UINavigationBar.appearance().scrollEdgeAppearance = nav
        UINavigationBar.appearance().compactAppearance = nav

        UITabBar.appearance().isHidden = true
    }

    var body: some Scene {
        WindowGroup {
            AureaRootView()
                .preferredColorScheme(.dark)
                .background(Color.black)
                .ignoresSafeArea(.all)
        }
    }
}

struct AureaRootView: View {
    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea(.all)

            EditorView()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
                .ignoresSafeArea(.all)
        }
        .background(Color.black)
    }
}
