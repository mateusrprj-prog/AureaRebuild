import Foundation
import PhotosUI
import UniformTypeIdentifiers

@MainActor
final class MediaStore: ObservableObject {
    @Published var isImporting = false
    @Published var errorMessage: String?

    func importVideo(from item: PhotosPickerItem, completion: @escaping (URL) -> Void) {
        isImporting = true
        errorMessage = nil

        Task {
            do {
                guard let data = try await item.loadTransferable(type: Data.self) else {
                    throw NSError(domain: "Aurea", code: 1, userInfo: [NSLocalizedDescriptionKey: "Não foi possível carregar o vídeo."])
                }

                let ext = item.supportedContentTypes.first?.preferredFilenameExtension ?? "mov"
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("Aurea-\(UUID().uuidString).\(ext)")

                try data.write(to: url, options: .atomic)

                await MainActor.run {
                    self.isImporting = false
                    completion(url)
                }
            } catch {
                await MainActor.run {
                    self.isImporting = false
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
