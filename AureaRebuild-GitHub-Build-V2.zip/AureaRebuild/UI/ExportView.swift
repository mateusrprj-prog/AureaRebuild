import SwiftUI
import AVFoundation

struct ExportView: View {
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss
    @State private var isExporting = false
    @State private var status = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Exportação") {
                    LabeledContent("Formato", value: "MP4 / H.264")
                    LabeledContent("Duração", value: String(format: "%.1fs", model.project.duration))
                    Button(isExporting ? "Exportando..." : "Exportar") {
                        export()
                    }
                    .disabled(isExporting || model.importedVideoURL == nil)
                }

                if !status.isEmpty {
                    Section {
                        Text(status)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Exportar")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Fechar") { dismiss() }
                }
            }
        }
    }

    private func export() {
        guard let input = model.importedVideoURL else { return }
        isExporting = true
        status = "Preparando..."

        let asset = AVAsset(url: input)
        let output = FileManager.default.temporaryDirectory
            .appendingPathComponent("Aurea-Export-\(UUID().uuidString).mp4")

        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            isExporting = false
            status = "Este vídeo não pode ser exportado."
            return
        }

        session.outputURL = output
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true

        session.exportAsynchronously {
            Task { @MainActor in
                switch session.status {
                case .completed:
                    model.lastExportURL = output
                    isExporting = false
                    status = "Exportação concluída."
                case .failed, .cancelled:
                    isExporting = false
                    status = session.error?.localizedDescription ?? "A exportação não foi concluída."
                default:
                    break
                }
            }
        }
    }
}
