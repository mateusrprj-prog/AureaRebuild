# AureaRebuild v3.2

Independent SwiftUI reconstruction project.

- iOS 16.3+
- Bundle ID: com.aurea.aurearebuild
- Swift 6
- XcodeGen project specification included
- Black window/safe-area background fix
- Video import UI and timeline
