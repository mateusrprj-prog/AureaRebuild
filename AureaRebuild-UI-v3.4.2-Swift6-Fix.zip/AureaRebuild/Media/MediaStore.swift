import Foundation
import AVFoundation
import CoreTransferable
import UniformTypeIdentifiers

struct GalleryVideo: Transferable, Sendable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let source = received.file
            let ext = source.pathExtension.isEmpty ? "mov" : source.pathExtension
            let destination = FileManager.default.temporaryDirectory
                .appendingPathComponent("AureaMedia-\(UUID().uuidString).\(ext)")
            try FileManager.default.copyItem(at: source, to: destination)
            return GalleryVideo(url: destination)
        }
    }
}

@MainActor
final class MediaStore: ObservableObject {
    @Published var importedURL: URL?
    @Published var duration: Double = 0
    @Published var isImporting = false
    @Published var errorMessage: String?

    func importVideo(from url: URL) async -> URL? {
        isImporting = true
        errorMessage = nil
        defer { isImporting = false }

        do {
            try await validateVideo(at: url)
            clearOldFile()
            importedURL = url
            return url
        } catch {
            errorMessage = "Não foi possível importar o vídeo: \(error.localizedDescription)"
            return nil
        }
    }

    private func validateVideo(at url: URL) async throws {
        let asset = AVURLAsset(url: url)
        let loadedDuration = try await asset.load(.duration)
        let seconds = loadedDuration.seconds
        guard seconds.isFinite && seconds > 0 else {
            throw ImportError.invalidVideo
        }
        duration = max(0.1, seconds)
    }

    func clear() {
        clearOldFile()
        importedURL = nil
        duration = 0
        errorMessage = nil
    }

    private func clearOldFile() {
        if let importedURL { try? FileManager.default.removeItem(at: importedURL) }
    }

    enum ImportError: LocalizedError {
        case emptyData
        case invalidVideo

        var errorDescription: String? {
            switch self {
            case .emptyData:
                return "O vídeo selecionado não retornou um arquivo utilizável."
            case .invalidVideo:
                return "O arquivo selecionado não contém uma duração de vídeo válida."
            }
        }
    }
}
