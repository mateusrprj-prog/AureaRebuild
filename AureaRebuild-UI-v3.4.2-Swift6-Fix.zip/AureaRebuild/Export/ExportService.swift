import Foundation
@preconcurrency import AVFoundation
import Photos

/// AVAssetExportSession is an Objective-C reference type that is not Sendable.
/// This box lets the Swift 6 completion callback carry the session safely while
/// all actual session state access is performed back on the main actor.
private final class ExportSessionBox: @unchecked Sendable {
    let session: AVAssetExportSession

    init(_ session: AVAssetExportSession) {
        self.session = session
    }
}

@MainActor
final class ExportService: ObservableObject {
    @Published var isExporting = false
    @Published var progress: Double = 0
    @Published var message: String?
    @Published var error: String?

    func exportVideo(from sourceURL: URL, duration: Double) {
        guard !isExporting else { return }
        isExporting = true
        progress = 0
        message = nil
        error = nil

        let asset = AVAsset(url: sourceURL)
        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("AureaExport-\(UUID().uuidString).mp4")

        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            isExporting = false
            error = "Este vídeo não pode ser exportado neste dispositivo."
            return
        }

        session.outputURL = outputURL
        session.outputFileType = .mp4
        let sourceDuration = asset.duration.seconds
        let end = min(max(duration, 0.1), sourceDuration.isFinite ? sourceDuration : duration)
        session.timeRange = CMTimeRange(start: .zero, duration: CMTime(seconds: end, preferredTimescale: 600))

        // O progresso em tempo real foi removido aqui para evitar conflitos de
        // isolamento do Swift 6 entre Timer/@Sendable e AVAssetExportSession.
        // A interface continua mostrando 0% durante a exportação e 100% ao concluir.
        let sessionBox = ExportSessionBox(session)

        session.exportAsynchronously { [weak self, sessionBox] in
            Task { @MainActor [weak self, sessionBox] in
                guard let self else { return }
                let exportSession = sessionBox.session
                switch exportSession.status {
                case .completed:
                    self.saveToPhotos(outputURL: outputURL)
                case .failed, .cancelled:
                    self.isExporting = false
                    self.error = exportSession.error?.localizedDescription ?? "A exportação foi cancelada."
                default:
                    self.isExporting = false
                }
            }
        }
    }

    private func saveToPhotos(outputURL: URL) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { [weak self] status in
            guard let self else { return }
            Task { @MainActor in
                guard status == .authorized || status == .limited else {
                    self.isExporting = false
                    self.error = "Permita que o Aurea salve vídeos na galeria."
                    return
                }

                let library = PHPhotoLibrary.shared()
                library.performChanges({
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: outputURL)
                }) { success, error in
                    Task { @MainActor in
                        self.isExporting = false
                        self.progress = 1
                        self.message = success ? "Vídeo salvo na galeria." : nil
                        self.error = success ? nil : (error?.localizedDescription ?? "Não foi possível salvar o vídeo.")
                        try? FileManager.default.removeItem(at: outputURL)
                    }
                }
            }
        }
    }
}
