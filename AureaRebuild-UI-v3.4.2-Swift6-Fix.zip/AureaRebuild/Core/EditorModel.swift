import Foundation
import SwiftUI

@MainActor
final class EditorModel: ObservableObject {
    struct Layer: Identifiable, Codable, Equatable {
        let id: UUID
        var name: String
        var type: String
        var opacity: Double = 1
        var scale: Double = 1
        var rotation: Double = 0
        var positionX: Double = 0
        var positionY: Double = 0
        var brightness: Double = 0
        var contrast: Double = 0
        var saturation: Double = 0
        var blur: Double = 0
        var visible: Bool = true
        var start: Double = 0
        var end: Double = 10
    }

    @Published var projectName = "Projeto 1"
    @Published var duration: Double = 10
    @Published var currentTime: Double = 0
    @Published var zoom: Double = 1
    @Published var isPlaying = false
    @Published var layers: [Layer] = []
    @Published var selectedLayerID: UUID?
    @Published var showInspector = false
    @Published var showExport = false
    @Published var history: [[Layer]] = []
    @Published var redoStack: [[Layer]] = []

    var selectedLayer: Layer? {
        guard let id = selectedLayerID else { return nil }
        return layers.first { $0.id == id }
    }

    func addLayer(_ name: String, type: String) {
        pushHistory()
        layers.append(Layer(id: UUID(), name: name, type: type, start: 0, end: duration))
        selectedLayerID = layers.last?.id
    }

    func addImportedVideo() {
        pushHistory()
        let layer = Layer(id: UUID(), name: "Vídeo", type: "media", start: 0, end: duration)
        layers.append(layer)
        selectedLayerID = layer.id
    }

    func deleteSelected() {
        guard let id = selectedLayerID else { return }
        pushHistory()
        layers.removeAll { $0.id == id }
        selectedLayerID = layers.last?.id
    }

    func duplicateSelected() {
        guard let item = selectedLayer else { return }
        pushHistory()
        let newID = UUID()
        let copy = Layer(
            id: newID,
            name: item.name + " cópia",
            type: item.type,
            opacity: item.opacity,
            scale: item.scale,
            rotation: item.rotation,
            positionX: item.positionX,
            positionY: item.positionY,
            brightness: item.brightness,
            contrast: item.contrast,
            saturation: item.saturation,
            blur: item.blur,
            visible: item.visible,
            start: item.start,
            end: item.end
        )
        layers.append(copy)
        selectedLayerID = newID
    }

    func updateSelected(recordHistory: Bool = true, _ update: (inout Layer) -> Void) {
        guard let id = selectedLayerID, let index = layers.firstIndex(where: { $0.id == id }) else { return }
        if recordHistory { pushHistory() }
        update(&layers[index])
        layers[index].opacity = min(1, max(0, layers[index].opacity))
        layers[index].scale = min(3, max(0.1, layers[index].scale))
        layers[index].start = max(0, min(layers[index].start, duration))
        layers[index].end = max(layers[index].start + 0.1, min(layers[index].end, duration))
        layers[index].brightness = min(1, max(-1, layers[index].brightness))
        layers[index].contrast = min(1, max(-1, layers[index].contrast))
        layers[index].saturation = min(1, max(-1, layers[index].saturation))
        layers[index].blur = min(20, max(0, layers[index].blur))
    }

    func toggleVisibility(_ layer: Layer) {
        guard let index = layers.firstIndex(where: { $0.id == layer.id }) else { return }
        pushHistory()
        layers[index].visible.toggle()
    }

    func setDuration(_ value: Double) {
        duration = max(0.1, value)
        currentTime = min(currentTime, duration)
        layers = layers.map { var item = $0; item.end = min(item.end, duration); return item }
    }

    func pushHistory() {
        history.append(layers)
        if history.count > 40 { history.removeFirst() }
        redoStack.removeAll()
    }

    func undo() {
        guard let previous = history.popLast() else { return }
        redoStack.append(layers)
        layers = previous
        selectedLayerID = layers.last?.id
    }

    func redo() {
        guard let next = redoStack.popLast() else { return }
        history.append(layers)
        layers = next
        selectedLayerID = layers.last?.id
    }
}
