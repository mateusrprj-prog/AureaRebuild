import SwiftUI

/// Single clip/layer row representation on the timeline track.
struct TimelineClip: View {
    let layer: EditorModel.Layer
    let isSelected: Bool
    let pixelsPerSecond: CGFloat
    let onSelect: () -> Void
    let onToggleVisibility: () -> Void

    private var width: CGFloat {
        let span = max(0.15, layer.end - layer.start)
        return max(48, span * pixelsPerSecond)
    }

    private var offsetX: CGFloat {
        CGFloat(layer.start) * pixelsPerSecond
    }

    var body: some View {
        HStack(spacing: 0) {
            // Track side controls (eye + type icon)
            HStack(spacing: 6) {
                Button(action: onToggleVisibility) {
                    Image(systemName: layer.visible ? "eye.fill" : "eye.slash")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(layer.visible ? .white.opacity(0.85) : .white.opacity(0.35))
                }
                .buttonStyle(.plain)

                Image(systemName: iconName)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(trackColor)
                    .frame(width: 18, height: 18)
                    .background(trackColor.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
            }
            .frame(width: 52)
            .padding(.leading, 6)

            // Clip body
            Button(action: onSelect) {
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(trackColor.opacity(isSelected ? 0.85 : 0.55))

                    // Fake thumbnail strip for media layers
                    if layer.type == "media" {
                        HStack(spacing: 1) {
                            ForEach(0..<max(1, Int(width / 28)), id: \.self) { i in
                                RoundedRectangle(cornerRadius: 2)
                                    .fill(Color.white.opacity(0.08 + Double(i % 3) * 0.04))
                                    .frame(width: 26, height: 28)
                            }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                    }

                    HStack(spacing: 4) {
                        Text(layer.name)
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 8)

                    // Selection border
                    if isSelected {
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .strokeBorder(Color.white.opacity(0.9), lineWidth: 1.5)
                    }

                    // Keyframe diamonds (decorative)
                    HStack {
                        diamond
                        Spacer()
                        diamond
                        Spacer()
                        diamond
                    }
                    .padding(.horizontal, 10)
                    .allowsHitTesting(false)
                }
                .frame(width: width, height: 32)
            }
            .buttonStyle(.plain)
            .padding(.leading, offsetX)
            .opacity(layer.visible ? 1 : 0.45)
        }
        .frame(height: 36, alignment: .leading)
    }

    private var diamond: some View {
        Image(systemName: "diamond.fill")
            .font(.system(size: 7))
            .foregroundStyle(.white.opacity(0.85))
    }

    private var iconName: String {
        switch layer.type {
        case "media": return "photo.on.rectangle"
        case "text": return "textformat"
        case "effect": return "wand.and.stars"
        case "solid": return "square.fill"
        case "audio": return "music.note"
        case "shape": return "circle"
        default: return "square.stack.3d.up"
        }
    }

    private var trackColor: Color {
        switch layer.type {
        case "effect": return Color(red: 0.55, green: 0.35, blue: 0.95)
        case "media": return Color(red: 0.25, green: 0.55, blue: 0.95)
        case "text": return Color(red: 0.3, green: 0.7, blue: 0.95)
        case "audio": return Color(red: 0.95, green: 0.55, blue: 0.25)
        case "solid": return Color(red: 0.9, green: 0.55, blue: 0.2)
        default: return Color(red: 0.95, green: 0.6, blue: 0.25)
        }
    }
}
