import SwiftUI

struct TimelineView: View {
    @EnvironmentObject private var model: EditorModel

    private let pixelsPerSecond: CGFloat = 72

    var body: some View {
        VStack(spacing: 0) {
            // Ruler + time readout
            ZStack(alignment: .top) {
                // Time ruler
                ScrollView(.horizontal, showsIndicators: false) {
                    ZStack(alignment: .topLeading) {
                        rulerContent
                            .frame(width: timelineWidth, height: 28, alignment: .topLeading)

                        // Playhead
                        playhead
                            .offset(x: CGFloat(model.currentTime) * pixelsPerSecond)
                    }
                }

                // Centered time badge
                Text(formatTime(model.currentTime))
                    .font(.system(size: 13, weight: .semibold).monospacedDigit())
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.black.opacity(0.75))
                    .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                    .offset(y: 2)
            }
            .frame(height: 32)
            .background(Color(red: 0.06, green: 0.06, blue: 0.08))

            // Layer tracks
            ScrollView(.vertical, showsIndicators: false) {
                ScrollView(.horizontal, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 4) {
                        if model.layers.isEmpty {
                            emptyTracks
                        } else {
                            ForEach(model.layers) { layer in
                                TimelineClip(
                                    layer: layer,
                                    isSelected: model.selectedLayerID == layer.id,
                                    pixelsPerSecond: pixelsPerSecond,
                                    onSelect: {
                                        model.selectedLayerID = layer.id
                                        model.showInspector = true
                                    },
                                    onToggleVisibility: {
                                        model.toggleVisibility(layer)
                                    }
                                )
                            }
                        }
                    }
                    .padding(.vertical, 8)
                    .padding(.trailing, 24)
                    .frame(minWidth: timelineWidth, alignment: .leading)
                }
            }
            .background(Color(red: 0.05, green: 0.055, blue: 0.07))
        }
    }

    private var timelineWidth: CGFloat {
        max(320, CGFloat(model.duration + 2) * pixelsPerSecond)
    }

    private var rulerContent: some View {
        HStack(spacing: 0) {
            ForEach(0...Int(ceil(model.duration)), id: \.self) { second in
                VStack(alignment: .leading, spacing: 2) {
                    Rectangle()
                        .fill(Color.white.opacity(0.35))
                        .frame(width: 1, height: 8)
                    Text("\(second)s")
                        .font(.system(size: 9).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.45))
                }
                .frame(width: pixelsPerSecond, alignment: .leading)
            }
        }
        .padding(.leading, 58) // align with clip bodies (side controls width)
    }

    private var playhead: some View {
        VStack(spacing: 0) {
            Image(systemName: "arrowtriangle.down.fill")
                .font(.system(size: 8))
                .foregroundStyle(Color(red: 0.35, green: 0.6, blue: 1.0))
            Rectangle()
                .fill(Color(red: 0.35, green: 0.6, blue: 1.0))
                .frame(width: 1.5)
                .frame(maxHeight: .infinity)
        }
        .frame(width: 12)
        .offset(x: 58 - 6) // align under ruler offset
        .allowsHitTesting(false)
    }

    private var emptyTracks: some View {
        HStack {
            Spacer()
            VStack(spacing: 8) {
                Image(systemName: "rectangle.split.3x1")
                    .font(.system(size: 22))
                    .foregroundStyle(.white.opacity(0.25))
                Text("Timeline vazia")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(.white.opacity(0.35))
                Text("Importe um vídeo ou adicione uma camada")
                    .font(.system(size: 11))
                    .foregroundStyle(.white.opacity(0.25))
            }
            .padding(.vertical, 28)
            Spacer()
        }
        .frame(minWidth: timelineWidth)
    }

    private func formatTime(_ value: Double) -> String {
        let totalMs = Int((value * 1000).rounded())
        let m = totalMs / 60_000
        let s = (totalMs % 60_000) / 1000
        let ms = totalMs % 1000
        return String(format: "%02d:%02d:%03d", m, s, ms)
    }
}
