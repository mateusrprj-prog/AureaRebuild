import SwiftUI

struct InspectorView: View {
    @EnvironmentObject private var model: EditorModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                if let selected = model.selectedLayer {
                    Section {
                        HStack {
                            Image(systemName: icon(for: selected.type))
                                .foregroundStyle(accent)
                            Text(selected.name)
                                .font(.headline)
                            Spacer()
                            Text(selected.type.uppercased())
                                .font(.caption2.weight(.bold))
                                .foregroundStyle(.secondary)
                        }
                    }

                    Section("Transformar") {
                        slider("Opacidade", value: binding(\.opacity), range: 0...1, suffix: "%", mult: 100)
                        slider("Posição X", value: binding(\.positionX), range: -500...500, suffix: "px", mult: 1)
                        slider("Posição Y", value: binding(\.positionY), range: -500...500, suffix: "px", mult: 1)
                        slider("Escala", value: binding(\.scale), range: 0.1...3, suffix: "%", mult: 100)
                        slider("Rotação", value: binding(\.rotation), range: -180...180, suffix: "°", mult: 1)
                    }

                    Section("Ajustes") {
                        slider("Brilho", value: binding(\.brightness), range: -1...1, suffix: "", mult: 100)
                        slider("Contraste", value: binding(\.contrast), range: -1...1, suffix: "", mult: 100)
                        slider("Saturação", value: binding(\.saturation), range: -1...1, suffix: "", mult: 100)
                        slider("Blur", value: binding(\.blur), range: 0...20, suffix: "px", mult: 1)
                    }

                    Section("Tempo") {
                        slider(
                            "Início",
                            value: Binding(
                                get: { model.selectedLayer?.start ?? 0 },
                                set: { newValue in
                                    model.updateSelected(recordHistory: false) { layer in
                                        layer.start = min(newValue, layer.end - 0.1)
                                    }
                                }
                            ),
                            range: 0...max(0.1, model.duration - 0.1),
                            suffix: "s",
                            mult: 1
                        )
                        slider(
                            "Fim",
                            value: Binding(
                                get: { model.selectedLayer?.end ?? model.duration },
                                set: { newValue in
                                    model.updateSelected(recordHistory: false) { layer in
                                        layer.end = max(newValue, layer.start + 0.1)
                                    }
                                }
                            ),
                            range: 0.1...max(0.1, model.duration),
                            suffix: "s",
                            mult: 1
                        )
                    }

                    Section("Ações") {
                        Button {
                            model.duplicateSelected()
                        } label: {
                            Label("Duplicar camada", systemImage: "plus.square.on.square")
                        }
                        Button(role: .destructive) {
                            model.deleteSelected()
                            dismiss()
                        } label: {
                            Label("Excluir camada", systemImage: "trash")
                        }
                    }
                } else {
                    Section {
                        VStack(spacing: 14) {
                            Image(systemName: "square.stack.3d.up")
                                .font(.system(size: 36))
                                .foregroundStyle(.secondary)
                            Text("Nenhuma camada selecionada")
                                .font(.headline)
                            Text("Toque em um clip na timeline para editar suas propriedades.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 28)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color(red: 0.07, green: 0.07, blue: 0.09))
            .navigationTitle("Inspetor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var accent: Color {
        Color(red: 0.4, green: 0.55, blue: 1.0)
    }

    private func binding(_ keyPath: WritableKeyPath<EditorModel.Layer, Double>) -> Binding<Double> {
        Binding(
            get: { model.selectedLayer?[keyPath: keyPath] ?? 0 },
            set: { newValue in
                model.updateSelected(recordHistory: false) { layer in
                    layer[keyPath: keyPath] = newValue
                }
            }
        )
    }

    private func slider(
        _ title: String,
        value: Binding<Double>,
        range: ClosedRange<Double>,
        suffix: String,
        mult: Double
    ) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title)
                    .font(.subheadline)
                Spacer()
                Text(String(format: "%.0f", value.wrappedValue * mult) + suffix)
                    .font(.subheadline.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Slider(value: value, in: range)
                .tint(accent)
        }
        .padding(.vertical, 2)
    }

    private func icon(for type: String) -> String {
        switch type {
        case "media": return "photo.on.rectangle"
        case "text": return "textformat"
        case "effect": return "wand.and.stars"
        case "audio": return "music.note"
        case "solid": return "square.fill"
        default: return "circle"
        }
    }
}
