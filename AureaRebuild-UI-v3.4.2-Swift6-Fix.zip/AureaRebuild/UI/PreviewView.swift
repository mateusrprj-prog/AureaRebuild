import SwiftUI
import AVKit
import PhotosUI

struct PreviewView: View {
    @EnvironmentObject private var model: EditorModel
    let player: AVPlayer?
    @Binding var selectedVideo: PhotosPickerItem?

    var body: some View {
        ZStack {
            Color.black

            if let player {
                VideoPlayer(player: player)
                    .background(Color.black)
                    .onDisappear { player.pause() }
            } else {
                EmptyPreview(selectedVideo: $selectedVideo)
            }

            // Overlay badges
            VStack {
                HStack {
                    // Zoom indicator (decorative / future hook)
                    HStack(spacing: 4) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 11, weight: .bold))
                        Text(String(format: "%.0f%%", model.zoom * 100))
                            .font(.system(size: 11, weight: .bold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.55))
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))

                    Spacer()

                    Text(model.selectedLayer?.name ?? "AUTO")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.55))
                        .clipShape(Capsule())
                }
                Spacer()
            }
            .padding(10)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
        .clipped()
        .overlay(
            RoundedRectangle(cornerRadius: 0)
                .strokeBorder(Color.white.opacity(0.06), lineWidth: 1)
        )
    }
}

struct EmptyPreview: View {
    @Binding var selectedVideo: PhotosPickerItem?

    var body: some View {
        ZStack {
            Color.black
            VStack(spacing: 16) {
                Image(systemName: "video.badge.plus")
                    .font(.system(size: 48, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.85))

                Text("Nenhum vídeo no projeto")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white)

                Text("Importe um vídeo da galeria para começar a editar.")
                    .font(.system(size: 13))
                    .foregroundStyle(.white.opacity(0.5))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 28)

                PhotosPicker(selection: $selectedVideo, matching: .videos) {
                    Label("Importar vídeo", systemImage: "photo.on.rectangle.angled")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 12)
                        .background(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.3, green: 0.5, blue: 1.0),
                                    Color(red: 0.45, green: 0.35, blue: 0.95)
                                ],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(Capsule())
                }
            }
            .padding(20)
        }
    }
}
