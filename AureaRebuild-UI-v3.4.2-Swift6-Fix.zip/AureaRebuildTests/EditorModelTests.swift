import XCTest
@testable import AureaRebuild

final class EditorModelTests: XCTestCase {
    func testCanAddAndDeleteLayer() {
        let model = EditorModel()
        let count = model.layers.count
        model.addLayer("Teste", type: "shape")
        XCTAssertEqual(model.layers.count, count + 1)
        model.deleteSelected()
        XCTAssertEqual(model.layers.count, count)
    }
}
