import Foundation
import Combine
import PhotosUI

@MainActor
final class MediaStore: ObservableObject {
    @Published var pickerItem: PhotosPickerItem?
    @Published var isImporting = false
    @Published var errorMessage: String?

    func importPickedVideo() async -> URL? {
        guard let item = pickerItem else { return nil }
        isImporting = true
        defer { isImporting = false; pickerItem = nil }
        do {
            guard let data = try await item.loadTransferable(type: Data.self) else { throw NSError(domain: "Aurea", code: 1) }
            let ext = (item.supportedContentTypes.first?.preferredFilenameExtension).flatMap { $0.isEmpty ? nil : $0 } ?? "mov"
            let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("Imported-\(UUID().uuidString).\(ext)")
            try data.write(to: url, options: Data.WritingOptions.atomic)
            return url
        } catch {
            errorMessage = "Não foi possível importar o vídeo."
            return nil
        }
    }
}
