import SwiftUI
import PhotosUI
import AVFoundation

struct EditorView: View {
    @StateObject private var model = EditorModel()
    @StateObject private var media = MediaStore()
    @State private var isPlaying = false
    @State private var showExporter = false
    @State private var showInspector = false
    @State private var exportError: String?
    private let exporter = CompositionExporter()

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                VideoPreview(url: model.videoURL, currentTime: $model.currentTime, isPlaying: $isPlaying)
                    .padding(.horizontal, 10)
                    .padding(.top, 8)
                    .frame(maxHeight: .infinity)

                timeline
                    .frame(height: 178)

                toolbar
                    .frame(height: 68)
            }
            .background(Color.black)
            .navigationTitle("Aurea")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) {
                    PhotosPicker(selection: $media.pickerItem, matching: .videos) {
                        Image(systemName: "photo.on.rectangle.angled")
                    }
                    .onChange(of: media.pickerItem) { _ in
                        Task {
                            if let url = await media.importPickedVideo() {
                                model.importVideo(url: url)
                            }
                        }
                    }
                }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { model.undo() } label: { Image(systemName: "arrow.uturn.backward") }
                    Button { model.redo() } label: { Image(systemName: "arrow.uturn.forward") }
                    Button { showInspector = true } label: { Image(systemName: "slider.horizontal.3") }
                }
            }
            .sheet(isPresented: $showInspector) { InspectorView(model: model) }
            .alert("Exportação", isPresented: Binding(get: { exportError != nil }, set: { if !$0 { exportError = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(exportError ?? "") }
            .sheet(isPresented: $showExporter) {
                ExportView(url: model.lastExportURL)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var timeline: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Timeline").font(.headline)
                Spacer()
                Text(String(format: "%.1fs", model.composition.duration)).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 12)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(model.composition.layers) { layer in
                        Button { model.selectedID = layer.id } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Image(systemName: icon(for: layer.kind))
                                Text(layer.name).font(.caption.bold()).lineLimit(1)
                            }
                            .padding(10)
                            .frame(width: 120, height: 74, alignment: .leading)
                            .background(model.selectedID == layer.id ? Color.blue.opacity(0.4) : Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                }
                .padding(.horizontal, 12)
            }

            if model.videoURL != nil {
                HStack(spacing: 8) {
                    Text("IN").font(.caption2.bold())
                    Slider(value: $model.trimStart, in: 0...max(model.trimEnd - 0.05, 0.05))
                    Text("OUT").font(.caption2.bold())
                    Slider(value: $model.trimEnd, in: min(model.trimStart + 0.05, model.composition.duration)...max(model.composition.duration, 0.1))
                }
                .padding(.horizontal, 12)
            }
        }
        .padding(.vertical, 10)
        .background(Color(white: 0.07))
    }

    private var toolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 18) {
                tool("Vídeo", "video.badge.plus") { media.pickerItem = nil }
                tool("Texto", "textformat") { model.addText() }
                tool("Sólido", "square.fill") { model.addSolid() }
                tool("Forma", "circle") { model.addShape() }
                tool("Duplicar", "plus.square.on.square") { model.duplicateSelected() }
                tool("Dividir", "scissors") { model.splitSelected() }
                tool("Excluir", "trash") { model.deleteSelected() }
                tool("Exportar", "square.and.arrow.up") {
                    guard model.videoURL != nil else { exportError = "Importe um vídeo primeiro."; return }
                    Task {
                        do { _ = try await exporter.export(model: model); showExporter = true }
                        catch { exportError = error.localizedDescription }
                    }
                }
            }
            .padding(.horizontal, 14)
        }
        .background(Color(white: 0.05))
    }

    private func tool(_ title: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) { Image(systemName: icon); Text(title).font(.caption2) }
        }
        .foregroundStyle(.white)
    }

    private func icon(for kind: LayerKind) -> String {
        switch kind { case .video: return "video"; case .image: return "photo"; case .text: return "textformat"; case .solid: return "square.fill"; case .shape: return "circle" }
    }
}

struct InspectorView: View {
    @ObservedObject var model: EditorModel
    var body: some View {
        NavigationStack {
            Form {
                Section("Efeitos") {
                    VStack(alignment: .leading) { Text("Brilho"); Slider(value: $model.brightness, in: -1...1) }
                    VStack(alignment: .leading) { Text("Contraste"); Slider(value: $model.contrast, in: 0...2) }
                    VStack(alignment: .leading) { Text("Saturação"); Slider(value: $model.saturation, in: 0...2) }
                    VStack(alignment: .leading) { Text("Desfoque"); Slider(value: $model.blur, in: 0...20) }
                    VStack(alignment: .leading) { Text("Volume"); Slider(value: $model.volume, in: 0...1) }
                    Button("Restaurar efeitos") { model.resetEffects() }
                }
                Section("Camada") {
                    if model.selectedLayer != nil {
                        VStack(alignment: .leading) { Text("Opacidade"); Slider(value: Binding(get: { model.selectedLayer?.opacity ?? 1 }, set: { model.updateSelected(opacity: $0) }), in: 0...1) }
                        VStack(alignment: .leading) { Text("Escala"); Slider(value: Binding(get: { model.selectedLayer?.scale ?? 1 }, set: { model.updateSelected(scale: $0) }), in: 0.1...3) }
                        VStack(alignment: .leading) { Text("Rotação"); Slider(value: Binding(get: { model.selectedLayer?.rotation ?? 0 }, set: { model.updateSelected(rotation: $0) }), in: -180...180) }
                    } else { Text("Selecione uma camada na timeline.").foregroundStyle(.secondary) }
                }
            }
            .navigationTitle("Inspector")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ExportView: View {
    let url: URL?
    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Image(systemName: "checkmark.circle.fill").font(.system(size: 56)).foregroundStyle(.green)
                Text("Exportação concluída").font(.title2.bold())
                if let url { ShareLink(item: url) { Label("Compartilhar vídeo", systemImage: "square.and.arrow.up") } }
                Text("O arquivo MP4 foi gerado pelo editor.").foregroundStyle(.secondary)
            }
            .padding()
            .navigationTitle("Exportar")
        }
    }
}
