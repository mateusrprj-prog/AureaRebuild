# AureaRebuild v2.5.0

Atualização grande do editor iOS independente.

## Principais mudanças
- Tela raiz fullscreen com fundo preto real e `ignoresSafeArea`, evitando áreas cinzas quando o app é reduzido ou aparece no App Switcher.
- Importação real de vídeos da galeria usando `PhotosPicker`.
- Leitura da duração do vídeo e atualização automática da timeline.
- Preview real do vídeo com `VideoPlayer`.
- Controles de reprodução, pausa, avanço, retrocesso e busca na timeline.
- Camada de vídeo criada automaticamente após uma importação bem-sucedida.
- Timeline com seleção, visibilidade, ícones por tipo e camada selecionada.
- Histórico de Undo/Redo ampliado.
- Inspector para opacidade, escala e rotação.
- Exclusão e duplicação de camadas.
- Exportação H.264 do vídeo importado para a galeria.
- Tratamento de erros de importação/exportação.
- Mantém iOS 16.3+.
- `CFBundleExecutable = AureaRebuild` e bundle ID estável.

## Observação
A exportação atual renderiza o vídeo importado/recortado; a composição completa com efeitos e camadas ainda é uma etapa futura.
