import Foundation
import AVFoundation
import PhotosUI
import UniformTypeIdentifiers

@MainActor
final class MediaStore: ObservableObject {
    @Published var importedURL: URL?
    @Published var duration: Double = 10
    @Published var isImporting = false
    @Published var errorMessage: String?

    func importVideo(from item: PhotosPickerItem) async -> URL? {
        isImporting = true
        errorMessage = nil
        defer { isImporting = false }

        let movieType = item.supportedContentTypes.first(where: { $0.conforms(to: .movie) })
            ?? UTType.movie
        let preferredExtension = movieType.preferredFilenameExtension ?? "mov"

        do {
            let data = try await item.loadTransferable(type: Data.self)
            guard let data, !data.isEmpty else {
                throw ImportError.emptyData
            }

            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent("AureaMedia-\(UUID().uuidString).\(preferredExtension)")
            try data.write(to: url, options: .atomic)

            let asset = AVURLAsset(url: url)
            let seconds = try await asset.load(.duration).seconds
            importedURL = url
            duration = max(0.1, seconds.isFinite ? seconds : 10)
            return url
        } catch {
            errorMessage = "Não foi possível importar o vídeo: \(error.localizedDescription)"
            return nil
        }
    }

    func clear() {
        importedURL = nil
        duration = 10
        errorMessage = nil
    }

    enum ImportError: LocalizedError {
        case emptyData
        var errorDescription: String? {
            switch self {
            case .emptyData: return "O vídeo selecionado não retornou dados."
            }
        }
    }
}
