import SwiftUI

struct ExportUI: View {
    let projectName: String
    let estimatedSize: String
    let isExporting: Bool
    let progress: Double
    let message: String?
    let error: String?
    var onCancel: () -> Void = {}
    var onExport: (ExportSettings) -> Void = { _ in }

    @State private var selectedResolution: ExportResolution = .p1080
    @State private var selectedFPS: ExportFPS = .fps30

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        sectionTitle("Resolution")
                        resolutionPicker

                        sectionTitle("Frame Rate (FPS)")
                        fpsPicker

                        sizeRow

                        if isExporting {
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    Text("Exportando")
                                        .font(.system(size: 14, weight: .semibold))
                                    Spacer()
                                    Text("\(Int(progress * 100))%")
                                        .font(.system(size: 13, weight: .semibold, design: .monospaced))
                                        .foregroundColor(.green)
                                }
                                ProgressView(value: progress)
                                    .tint(.green)
                            }
                            .padding(16)
                            .background(Color.white.opacity(0.06))
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }

                        if let message {
                            Label(message, systemImage: "checkmark.circle.fill")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(.green)
                        }

                        if let error {
                            Label(error, systemImage: "exclamationmark.triangle.fill")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(.orange)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 40)
                }

                bottomBar
            }
            .background(Color.black)
            .navigationTitle("Export Project")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: onCancel) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 13, weight: .semibold))
            .foregroundColor(.white.opacity(0.55))
    }

    private var resolutionPicker: some View {
        HStack(spacing: 10) {
            ForEach(ExportResolution.allCases) { res in
                Button {
                    selectedResolution = res
                } label: {
                    Text(res.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(selectedResolution == res ? .black : .white.opacity(0.8))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(selectedResolution == res ? Color.green : Color.white.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(isExporting)
            }
        }
    }

    private var fpsPicker: some View {
        HStack(spacing: 10) {
            ForEach(ExportFPS.allCases) { fps in
                Button {
                    selectedFPS = fps
                } label: {
                    Text(fps.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(selectedFPS == fps ? .black : .white.opacity(0.8))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(selectedFPS == fps ? Color.green : Color.white.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(isExporting)
            }
        }
    }

    private var sizeRow: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Estimated File Size")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.white.opacity(0.55))
                Text(estimatedSize)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
            }
            Spacer()
            Image(systemName: "arrow.down.circle.fill")
                .font(.system(size: 28))
                .foregroundColor(.white.opacity(0.3))
        }
        .padding(16)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var bottomBar: some View {
        HStack(spacing: 12) {
            Button(action: onCancel) {
                Text("Cancel")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(Color.white.opacity(0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(.plain)

            Button {
                onExport(ExportSettings(resolution: selectedResolution, fps: selectedFPS))
            } label: {
                Text(isExporting ? "Exportando…" : "Export Project")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(isExporting ? Color.green.opacity(0.45) : Color.green)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(isExporting)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .background(Color(white: 0.05))
    }
}

enum ExportResolution: String, CaseIterable, Identifiable {
    case p720, p1080, p4k
    var id: String { rawValue }
    var title: String {
        switch self {
        case .p720: return "720p"
        case .p1080: return "1080p"
        case .p4k: return "4K"
        }
    }
}

enum ExportFPS: String, CaseIterable, Identifiable {
    case fps24, fps30, fps60
    var id: String { rawValue }
    var title: String {
        switch self {
        case .fps24: return "24 FPS"
        case .fps30: return "30 FPS"
        case .fps60: return "60 FPS"
        }
    }
}

struct ExportSettings {
    let resolution: ExportResolution
    let fps: ExportFPS
}
