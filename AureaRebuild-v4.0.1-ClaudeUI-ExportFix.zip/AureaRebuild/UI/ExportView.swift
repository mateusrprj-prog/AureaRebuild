import SwiftUI

struct ExportView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: EditorModel
    @EnvironmentObject private var mediaStore: MediaStore
    @StateObject private var exporter = ExportService()

    @State private var resolution = "1080p"
    @State private var fps = "30"
    @State private var quality = "Alta"

    private let resolutions = ["720p", "1080p", "Original"]
    private let fpsOptions = ["24", "30", "60"]
    private let qualities = ["Baixa", "Média", "Alta"]

    var body: some View {
        NavigationStack {
            Form {
                Section("Configurações") {
                    Picker("Resolução", selection: $resolution) {
                        ForEach(resolutions, id: \.self) { Text($0) }
                    }
                    Picker("FPS", selection: $fps) {
                        ForEach(fpsOptions, id: \.self) { Text("\($0) fps") }
                    }
                    Picker("Qualidade", selection: $quality) {
                        ForEach(qualities, id: \.self) { Text($0) }
                    }
                    LabeledContent("Codec", value: "H.264")
                    LabeledContent("Duração", value: String(format: "%.2fs", model.duration))
                }

                if exporter.isExporting {
                    Section("Progresso") {
                        ProgressView(value: exporter.progress)
                            .tint(Color(red: 0.35, green: 0.55, blue: 1.0))
                        Text("Exportando… \(Int(exporter.progress * 100))%")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }

                Section {
                    Button {
                        guard let url = mediaStore.importedURL else {
                            exporter.error = "Importe um vídeo da galeria antes de exportar."
                            return
                        }
                        // UI-only resolution/FPS/quality for now; wires into existing ExportService.
                        Task {
                            await exporter.exportVideo(from: url, duration: model.duration)
                        }
                    } label: {
                        HStack {
                            Spacer()
                            if exporter.isExporting {
                                ProgressView()
                                    .padding(.trailing, 6)
                            }
                            Label("Exportar", systemImage: "square.and.arrow.up")
                                .font(.headline)
                            Spacer()
                        }
                    }
                    .disabled(exporter.isExporting)
                    .listRowBackground(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color(red: 0.3, green: 0.5, blue: 1.0).opacity(exporter.isExporting ? 0.35 : 0.85))
                    )
                    .foregroundStyle(.white)
                }

                if let message = exporter.message {
                    Section {
                        Label(message, systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                }
                if let error = exporter.error {
                    Section {
                        Label(error, systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.orange)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color(red: 0.07, green: 0.07, blue: 0.09))
            .navigationTitle("Exportar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Fechar") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
