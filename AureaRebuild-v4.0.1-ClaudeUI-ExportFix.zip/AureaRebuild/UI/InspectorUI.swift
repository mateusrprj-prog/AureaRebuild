import SwiftUI

/// Premium inspector presentation. Values are supplied as bindings by the host editor.
struct InspectorUI: View {
    let onDismiss: () -> Void
    @Binding var opacity: Double
    @Binding var scale: Double
    @Binding var rotation: Double
    @Binding var positionX: Double
    @Binding var positionY: Double

    init(
        onDismiss: @escaping () -> Void = {},
        opacity: Binding<Double>,
        scale: Binding<Double>,
        rotation: Binding<Double>,
        positionX: Binding<Double>,
        positionY: Binding<Double>
    ) {
        self.onDismiss = onDismiss
        _opacity = opacity
        _scale = scale
        _rotation = rotation
        _positionX = positionX
        _positionY = positionY
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    sectionHeader("Transform")
                    propertySlider(title: "Position X", value: $positionX, range: -500...500, unit: "px")
                    propertySlider(title: "Position Y", value: $positionY, range: -500...500, unit: "px")
                    propertySlider(title: "Scale", value: $scale, range: 0.1...3.0, unit: "×")
                    propertySlider(title: "Rotation", value: $rotation, range: -180...180, unit: "°")

                    Divider().background(Color.white.opacity(0.1))
                    sectionHeader("Appearance")
                    propertySlider(title: "Opacity", value: $opacity, range: 0...1, unit: "%")

                    Divider().background(Color.white.opacity(0.1))
                    sectionHeader("Blend Mode")
                    blendModeChips
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
            }
            .background(Color(white: 0.07))
            .navigationTitle("Inspector")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done", action: onDismiss)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.green)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private func sectionHeader(_ title: String) -> some View {
        Text(title.uppercased())
            .font(.system(size: 11, weight: .semibold))
            .foregroundColor(.white.opacity(0.4))
            .tracking(0.8)
    }

    private func propertySlider(title: String, value: Binding<Double>, range: ClosedRange<Double>, unit: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.85))
                Spacer()
                Text(formatted(value.wrappedValue, unit: unit))
                    .font(.system(size: 13, weight: .medium, design: .monospaced))
                    .foregroundColor(.green)
            }
            Slider(value: value, in: range)
                .tint(.green)
        }
    }

    private var blendModeChips: some View {
        let modes = ["Normal", "Add", "Multiply", "Screen", "Overlay"]
        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(modes, id: \.self) { mode in
                    Text(mode)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(mode == "Normal" ? .black : .white.opacity(0.8))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(mode == "Normal" ? Color.green : Color.white.opacity(0.08))
                        .clipShape(Capsule())
                }
            }
        }
    }

    private func formatted(_ value: Double, unit: String) -> String {
        switch unit {
        case "%": return String(format: "%.0f%%", value * 100)
        case "×": return String(format: "%.2f×", value)
        case "°": return String(format: "%.0f°", value)
        default: return String(format: "%.0f%@", value, unit)
        }
    }
}
