import SwiftUI

/// Large preview canvas. Receives any content view from the caller.
struct PreviewUI: View {
    let content: AnyView
    let currentTime: String
    let isPlaying: Bool
    var onTogglePlay: () -> Void = {}
    
    var body: some View {
        ZStack {
            // Subtle grid background
            GridBackground()
                .opacity(0.35)
            
            // Caller-provided content
            content
                .clipped()
            
            // Time badge (top-center when playing)
            VStack {
                HStack {
                    Spacer()
                    Text(currentTime)
                        .font(.system(size: 12, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.black.opacity(0.55))
                        .clipShape(Capsule())
                        .padding(.top, 12)
                        .padding(.trailing, 14)
                }
                Spacer()
            }
            
            // Center play overlay (only when paused)
            if !isPlaying {
                Button(action: onTogglePlay) {
                    Image(systemName: "play.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                        .padding(18)
                        .background(Color.black.opacity(0.45))
                        .clipShape(Circle())
                }
            }
        }
        .background(Color(white: 0.04))
    }
}

// MARK: - Subtle grid
private struct GridBackground: View {
    var body: some View {
        Canvas { context, size in
            let step: CGFloat = 24
            var path = Path()
            for x in stride(from: 0, through: size.width, by: step) {
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
            }
            for y in stride(from: 0, through: size.height, by: step) {
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(.white.opacity(0.07)), lineWidth: 0.5)
        }
    }
}

#Preview {
    PreviewUI(
        content: AnyView(
            ZStack {
                Color.black
                RoundedRectangle(cornerRadius: 12)
                    .fill(LinearGradient(
                        colors: [.blue.opacity(0.7), .purple.opacity(0.5)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 220, height: 160)
                    .rotation3DEffect(.degrees(18), axis: (x: 0.3, y: 1, z: 0))
            }
        ),
        currentTime: "00:00:06.2",
        isPlaying: false
    )
    .frame(height: 320)
    .preferredColorScheme(.dark)
}