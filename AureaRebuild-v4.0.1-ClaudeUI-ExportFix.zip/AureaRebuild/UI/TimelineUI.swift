import SwiftUI

struct TimelineTrack: Identifiable {
    let id: String
    let name: String
    let color: Color
    let height: CGFloat
    let icon: String
}

/// Dense multi-track timeline. Data is supplied by the host app; no editor logic is owned here.
struct TimelineUI: View {
    let currentTime: String
    let totalDuration: String
    let tracks: [TimelineTrack]
    let playheadProgress: Double
    var onSeek: (Double) -> Void = { _ in }
    var onLayerSelected: (String) -> Void = { _ in }

    var body: some View {
        GeometryReader { geo in
            VStack(spacing: 0) {
                timeRuler

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 4) {
                        if tracks.isEmpty {
                            emptyTimeline
                        } else {
                            ForEach(tracks) { track in
                                trackRow(track)
                            }
                        }
                    }
                    .padding(.vertical, 6)
                }
            }
            .background(Color(white: 0.05))
            .overlay {
                let x = max(2, min(geo.size.width - 2, playheadProgress * geo.size.width))
                Rectangle()
                    .fill(Color.green)
                    .frame(width: 2)
                    .position(x: x, y: geo.size.height / 2)
                    .overlay(alignment: .top) {
                        Capsule()
                            .fill(Color.green)
                            .frame(width: 10, height: 18)
                            .position(x: x, y: 10)
                    }
                    .allowsHitTesting(false)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let progress = max(0, min(1, value.location.x / max(1, geo.size.width)))
                        onSeek(progress)
                    }
            )
        }
    }

    private var timeRuler: some View {
        HStack {
            Text(currentTime)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundColor(.green)
            Spacer()
            Text(totalDuration)
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundColor(.white.opacity(0.45))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
        .background(Color(white: 0.07))
    }

    private var emptyTimeline: some View {
        VStack(spacing: 6) {
            Image(systemName: "film.stack")
                .font(.system(size: 22))
                .foregroundColor(.white.opacity(0.25))
            Text("Importe um vídeo para começar")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.white.opacity(0.35))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 30)
    }

    private func trackRow(_ track: TimelineTrack) -> some View {
        HStack(spacing: 0) {
            HStack(spacing: 6) {
                Image(systemName: "eye")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.5))
                Image(systemName: track.icon)
                    .font(.system(size: 11))
                    .foregroundColor(.white.opacity(0.45))
            }
            .frame(width: 44)

            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 5)
                    .fill(track.color)
                    .frame(height: track.height)

                HStack(spacing: 18) {
                    ForEach(0..<3, id: \.self) { _ in
                        Image(systemName: "diamond.fill")
                            .font(.system(size: 7))
                            .foregroundColor(.white.opacity(0.8))
                    }
                }
                .padding(.leading, 12)

                Text(track.name)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.leading, 10)
                    .lineLimit(1)
            }
            .padding(.trailing, 12)
            .contentShape(Rectangle())
            .onTapGesture { onLayerSelected(track.id) }
        }
        .padding(.leading, 4)
    }
}
