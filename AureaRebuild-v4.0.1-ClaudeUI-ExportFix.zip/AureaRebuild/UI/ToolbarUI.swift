import SwiftUI

/// Bottom tool strip. Matches the dense, icon-first style of professional mobile editors.
struct ToolbarUI: View {
    @Binding var selectedTool: EditorTool
    var onToolSelected: (EditorTool) -> Void = { _ in }
    
    // Tools shown in the strip (order matches references)
    private let tools: [EditorTool] = [
        .media, .text, .solid, .adjustment, .null, .shape, .audio, .presets
    ]
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(tools) { tool in
                toolButton(tool)
            }
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 8)
        .background(
            Color(white: 0.04)
                .overlay(
                    Rectangle()
                        .fill(Color.white.opacity(0.06))
                        .frame(height: 0.5),
                    alignment: .top
                )
        )
    }
    
    private func toolButton(_ tool: EditorTool) -> some View {
        Button {
            selectedTool = tool
            onToolSelected(tool)
        } label: {
            VStack(spacing: 4) {
                Image(systemName: tool.icon)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(selectedTool == tool ? .green : .white.opacity(0.65))
                
                Text(tool.title)
                    .font(.system(size: 9, weight: .medium))
                    .foregroundColor(selectedTool == tool ? .green : .white.opacity(0.45))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    VStack {
        Spacer()
        ToolbarUI(selectedTool: .constant(.media))
    }
    .background(Color.black)
    .preferredColorScheme(.dark)
}