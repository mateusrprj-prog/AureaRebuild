import SwiftUI

/// Main editor shell. Visual layer only; the host supplies media, timeline data and callbacks.
struct EditorUI: View {
    let projectName: String
    let currentTime: String
    let totalDuration: String
    let isPlaying: Bool
    let previewContent: AnyView
    let timelineTracks: [TimelineTrack]
    let playheadProgress: Double

    var onBack: () -> Void = {}
    var onExport: () -> Void = {}
    var onInspector: () -> Void = {}
    var onTogglePlay: () -> Void = {}
    var onSeek: (Double) -> Void = { _ in }
    var onToolSelected: (EditorTool) -> Void = { _ in }
    var onLayerSelected: (String) -> Void = { _ in }

    @State private var selectedTool: EditorTool = .media

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                PreviewUI(
                    content: previewContent,
                    currentTime: currentTime,
                    isPlaying: isPlaying,
                    onTogglePlay: onTogglePlay
                )
                .frame(maxHeight: .infinity)

                transportBar

                TimelineUI(
                    currentTime: currentTime,
                    totalDuration: totalDuration,
                    tracks: timelineTracks,
                    playheadProgress: playheadProgress,
                    onSeek: onSeek,
                    onLayerSelected: onLayerSelected
                )
                .frame(height: 180)

                ToolbarUI(
                    selectedTool: $selectedTool,
                    onToolSelected: { tool in
                        selectedTool = tool
                        onToolSelected(tool)
                    }
                )
            }
        }
        .preferredColorScheme(.dark)
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            Button(action: onBack) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
            }

            VStack(alignment: .leading, spacing: 1) {
                Text(projectName)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                Text("\(currentTime) / \(totalDuration)")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(.white.opacity(0.55))
            }

            Spacer()

            Button(action: onInspector) {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundColor(.white.opacity(0.85))
                    .frame(width: 34, height: 34)
            }
            .buttonStyle(.plain)

            Button(action: onExport) {
                Text("Export")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.black)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background(Color.green)
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color.black)
    }

    private var transportBar: some View {
        HStack(spacing: 24) {
            Button(action: {}) {
                Image(systemName: "square.grid.2x2")
                    .font(.system(size: 16))
                    .foregroundColor(.white.opacity(0.7))
            }
            .buttonStyle(.plain)

            Button(action: {}) {
                Text("Fit")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.white.opacity(0.7))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
            }
            .buttonStyle(.plain)

            Button(action: {}) {
                Image(systemName: "bookmark")
                    .font(.system(size: 16))
                    .foregroundColor(.white.opacity(0.7))
            }
            .buttonStyle(.plain)

            Spacer()

            Button(action: {}) {
                Image(systemName: "backward.end.fill")
                    .font(.system(size: 18))
                    .foregroundColor(.white)
            }
            .buttonStyle(.plain)

            Button(action: onTogglePlay) {
                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 22))
                    .foregroundColor(.white)
            }
            .buttonStyle(.plain)

            Button(action: {}) {
                Image(systemName: "forward.end.fill")
                    .font(.system(size: 18))
                    .foregroundColor(.white)
            }
            .buttonStyle(.plain)

            Spacer()

            Button(action: {}) {
                Image(systemName: "square.stack.3d.up")
                    .font(.system(size: 16))
                    .foregroundColor(.white.opacity(0.7))
            }
            .buttonStyle(.plain)

            Button(action: {}) {
                Image(systemName: "arrow.uturn.backward")
                    .font(.system(size: 16))
                    .foregroundColor(.white.opacity(0.7))
            }
            .buttonStyle(.plain)

            Button(action: {}) {
                Image(systemName: "arrow.uturn.forward")
                    .font(.system(size: 16))
                    .foregroundColor(.white.opacity(0.7))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .background(Color(white: 0.06))
    }
}

enum EditorTool: String, CaseIterable, Identifiable {
    case media, text, solid, adjustment, null, shape, audio, presets, element, inspector

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .media: return "photo.on.rectangle"
        case .text: return "textformat"
        case .solid: return "rectangle.fill"
        case .adjustment: return "slider.horizontal.3"
        case .null: return "circle.dashed"
        case .shape: return "square.on.circle"
        case .audio: return "waveform"
        case .presets: return "sparkles"
        case .element: return "circle.grid.3x3"
        case .inspector: return "info.circle"
        }
    }

    var title: String {
        switch self {
        case .media: return "Media"
        case .text: return "Text"
        case .solid: return "Solid"
        case .adjustment: return "Adjust"
        case .null: return "Null"
        case .shape: return "Shape"
        case .audio: return "Audio"
        case .presets: return "Presets"
        case .element: return "Element"
        case .inspector: return "Info"
        }
    }
}
