import SwiftUI

/// Compact icon-only control for playback / header actions.
struct EditorIconButton: View {
    let systemName: String
    var size: CGFloat = 18
    var disabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size, weight: .semibold))
                .foregroundStyle(disabled ? Color.white.opacity(0.28) : Color.white.opacity(0.95))
                .frame(width: 36, height: 36)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(disabled)
    }
}
