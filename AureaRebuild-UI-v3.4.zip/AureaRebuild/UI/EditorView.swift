import SwiftUI
import AVKit
import PhotosUI

struct EditorView: View {
    @EnvironmentObject private var model: EditorModel
    @EnvironmentObject private var mediaStore: MediaStore

    @State private var selectedVideo: PhotosPickerItem?
    @State private var showAdd = false
    @State private var showDeleteConfirm = false
    @State private var player: AVPlayer?
    @State private var timeObserver: Any?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea(.all)

            VStack(spacing: 0) {
                header

                PreviewView(player: player, selectedVideo: $selectedVideo)
                    .frame(maxHeight: UIScreen.main.bounds.height * 0.36)
                    .layoutPriority(1)

                MediaToolbar(showDeleteConfirm: $showDeleteConfirm)
                    .environmentObject(model)

                scrubber

                TimelineView()
                    .environmentObject(model)
                    .frame(maxHeight: .infinity)

                ToolbarView(
                    selectedVideo: $selectedVideo,
                    showAdd: $showAdd,
                    showDeleteConfirm: $showDeleteConfirm
                )
                .environmentObject(model)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
        }
        .preferredColorScheme(.dark)
        .onChange(of: selectedVideo) { item in
            guard let item else { return }
            Task { @MainActor in
                do {
                    guard let galleryVideo = try await item.loadTransferable(type: GalleryVideo.self) else {
                        throw MediaStore.ImportError.emptyData
                    }
                    if let url = await mediaStore.importVideo(from: galleryVideo.url) {
                        player?.pause()
                        removeTimeObserver()
                        let newPlayer = AVPlayer(url: url)
                        player = newPlayer
                        model.setDuration(mediaStore.duration)
                        model.addImportedVideo()
                        model.currentTime = 0
                        addTimeObserver(to: newPlayer)
                        newPlayer.play()
                        model.isPlaying = true
                    }
                } catch {
                    mediaStore.errorMessage = error.localizedDescription
                }
            }
        }
        .onChange(of: model.isPlaying) { playing in
            if playing {
                player?.play()
            } else {
                player?.pause()
            }
        }
        .onChange(of: model.currentTime) { time in
            if !model.isPlaying, let player {
                let current = player.currentTime().seconds
                if abs(current - time) > 0.08 {
                    player.seek(
                        to: CMTime(seconds: time, preferredTimescale: 600),
                        toleranceBefore: .zero,
                        toleranceAfter: .zero
                    )
                }
            }
        }
        .sheet(isPresented: $model.showInspector) {
            InspectorView()
                .environmentObject(model)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $model.showExport) {
            ExportView()
                .environmentObject(model)
                .environmentObject(mediaStore)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showAdd) {
            AddLayerView()
                .environmentObject(model)
                .presentationDetents([.medium])
        }
        .confirmationDialog("Excluir camada?", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
            Button("Excluir", role: .destructive) { model.deleteSelected() }
            Button("Cancelar", role: .cancel) {}
        }
        .onDisappear {
            removeTimeObserver()
            player?.pause()
        }
        .alert("Importação", isPresented: Binding(
            get: { mediaStore.errorMessage != nil },
            set: { if !$0 { mediaStore.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { mediaStore.errorMessage = nil }
        } message: {
            Text(mediaStore.errorMessage ?? "")
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "chevron.left")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.7))
                .frame(width: 28, height: 28)

            Text(model.projectName)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)

            Spacer()

            EditorIconButton(systemName: "gearshape") {
                model.showInspector = true
            }

            Button {
                model.showExport = true
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 36, height: 36)
                    .background(Color(red: 0.3, green: 0.55, blue: 0.95))
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .frame(height: 52)
        .background(Color.black)
    }

    // MARK: - Scrubber

    private var scrubber: some View {
        HStack(spacing: 10) {
            Text(formatTime(model.currentTime))
                .font(.system(size: 11, weight: .medium).monospacedDigit())
                .foregroundStyle(.white.opacity(0.8))
                .frame(width: 64, alignment: .leading)

            Slider(value: $model.currentTime, in: 0...max(model.duration, 0.1))
                .tint(Color(red: 0.35, green: 0.55, blue: 1.0))

            Text(formatTime(model.duration))
                .font(.system(size: 11, weight: .medium).monospacedDigit())
                .foregroundStyle(.white.opacity(0.55))
                .frame(width: 64, alignment: .trailing)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
        .background(Color(red: 0.04, green: 0.04, blue: 0.05))
    }

    // MARK: - Player time observer

    private func addTimeObserver(to player: AVPlayer) {
        removeTimeObserver()
        let interval = CMTime(seconds: 0.05, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak model] time in
            guard let model else { return }
            let seconds = time.seconds
            if seconds.isFinite {
                model.currentTime = min(max(0, seconds), model.duration)
                if seconds >= model.duration - 0.05 {
                    model.isPlaying = false
                    player.pause()
                }
            }
        }
    }

    private func removeTimeObserver() {
        if let timeObserver {
            player?.removeTimeObserver(timeObserver)
            self.timeObserver = nil
        }
    }

    private func formatTime(_ value: Double) -> String {
        let totalCs = Int((value * 100).rounded())
        let m = totalCs / 6000
        let s = (totalCs % 6000) / 100
        let cs = totalCs % 100
        return String(format: "%02d:%02d.%02d", m, s, cs)
    }
}

// MARK: - Add layer sheet

private struct AddLayerView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: EditorModel

    private let options: [(String, String, String)] = [
        ("Forma", "shape", "circle"),
        ("Texto", "text", "textformat"),
        ("Sólido", "solid", "square.fill"),
        ("Particular", "effect", "sparkles"),
        ("Áudio", "audio", "music.note")
    ]

    var body: some View {
        NavigationStack {
            List {
                ForEach(options, id: \.0) { item in
                    Button {
                        model.addLayer(item.0, type: item.1)
                        dismiss()
                    } label: {
                        Label(item.0, systemImage: item.2)
                            .foregroundStyle(.primary)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color(red: 0.07, green: 0.07, blue: 0.09))
            .navigationTitle("Adicionar camada")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Fechar") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

#Preview {
    EditorView()
        .environmentObject(EditorModel())
        .environmentObject(MediaStore())
}
