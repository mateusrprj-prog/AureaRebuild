import SwiftUI
import PhotosUI

/// Bottom tool strip with media / text / effects / export actions.
struct ToolbarView: View {
    @EnvironmentObject private var model: EditorModel
    @Binding var selectedVideo: PhotosPickerItem?
    @Binding var showAdd: Bool
    @Binding var showDeleteConfirm: Bool

    @State private var selectedTool: String? = nil

    private let tools: [(id: String, icon: String, title: String)] = [
        ("media", "photo.on.rectangle", "Mídia"),
        ("text", "textformat", "Texto"),
        ("audio", "music.note", "Áudio"),
        ("filters", "camera.filters", "Filtros"),
        ("adjust", "slider.horizontal.3", "Ajustes"),
        ("effects", "wand.and.stars", "Efeitos"),
        ("transform", "arrow.up.left.and.arrow.down.right", "Transformar"),
        ("speed", "gauge.with.needle", "Velocidade"),
        ("export", "square.and.arrow.up", "Exportar")
    ]

    var body: some View {
        VStack(spacing: 0) {
            Divider()
                .background(Color.white.opacity(0.08))

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    // Explicit import when no media yet
                    if model.layers.isEmpty {
                        PhotosPicker(selection: $selectedVideo, matching: .videos) {
                            VStack(spacing: 5) {
                                Image(systemName: "video.badge.plus")
                                    .font(.system(size: 18, weight: .medium))
                                Text("Importar vídeo")
                                    .font(.system(size: 10, weight: .semibold))
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.75)
                            }
                            .frame(width: 88, height: 58)
                            .foregroundStyle(.white)
                            .background(
                                LinearGradient(
                                    colors: [
                                        Color(red: 0.3, green: 0.5, blue: 1.0),
                                        Color(red: 0.45, green: 0.35, blue: 0.95)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                    } else {
                        PhotosPicker(selection: $selectedVideo, matching: .videos) {
                            EditorButton(icon: "plus.rectangle.on.rectangle", title: "Adicionar") {
                                // PhotosPicker handles selection
                            }
                        }
                    }

                    ForEach(tools, id: \.id) { tool in
                        EditorButton(
                            icon: tool.icon,
                            title: tool.title,
                            isSelected: selectedTool == tool.id
                        ) {
                            handleTool(tool.id)
                        }
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
            }
            .frame(height: 74)
            .background(Color(red: 0.04, green: 0.04, blue: 0.05))
        }
    }

    private func handleTool(_ id: String) {
        selectedTool = id
        switch id {
        case "media":
            // PhotosPicker is the primary entry; fallback opens add sheet
            showAdd = true
        case "text":
            model.addLayer("Texto", type: "text")
            model.showInspector = true
        case "audio":
            model.addLayer("Áudio", type: "audio")
        case "filters", "adjust", "effects", "transform", "speed":
            model.showInspector = true
        case "export":
            model.showExport = true
        default:
            break
        }
    }
}

/// Secondary media / layer actions strip (duplicate, delete, etc.)
struct MediaToolbar: View {
    @EnvironmentObject private var model: EditorModel
    @Binding var showDeleteConfirm: Bool

    var body: some View {
        HStack(spacing: 4) {
            EditorIconButton(systemName: "arrow.uturn.backward", disabled: model.history.isEmpty) {
                model.undo()
            }
            EditorIconButton(systemName: "arrow.uturn.forward", disabled: model.redoStack.isEmpty) {
                model.redo()
            }
            EditorIconButton(systemName: "backward.end.fill") {
                model.currentTime = 0
            }
            EditorIconButton(systemName: "bookmark") {
                // Marker placeholder
            }

            Spacer(minLength: 8)

            Button {
                model.isPlaying.toggle()
            } label: {
                Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(Color.white.opacity(0.1))
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)

            Spacer(minLength: 8)

            EditorIconButton(systemName: "forward.end.fill") {
                model.currentTime = model.duration
            }
            EditorIconButton(systemName: "plus.square.on.square") {
                model.duplicateSelected()
            }
            EditorIconButton(systemName: "trash", disabled: model.selectedLayerID == nil) {
                showDeleteConfirm = true
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color(red: 0.045, green: 0.045, blue: 0.055))
    }
}
