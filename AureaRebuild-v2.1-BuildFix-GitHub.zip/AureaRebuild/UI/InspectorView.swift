import SwiftUI

struct InspectorView: View {
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                if let layer = model.selectedLayer {
                    Section("Camada") {
                        LabeledContent("Nome", value: layer.name)
                        LabeledContent("Tipo", value: layer.kind.rawValue)
                    }
                    Section("Transformação") {
                        VStack(alignment: .leading) {
                            Text("Opacidade \(Int(layer.opacity * 100))%")
                            Slider(value: Binding(get: { layer.opacity }, set: { model.updateSelected(opacity: $0) }), in: 0...1)
                        }
                        VStack(alignment: .leading) {
                            Text("Escala \(Int(layer.scale * 100))%")
                            Slider(value: Binding(get: { layer.scale }, set: { model.updateSelected(scale: $0) }), in: 0.1...3)
                        }
                        VStack(alignment: .leading) {
                            Text("Rotação \(Int(layer.rotation))°")
                            Slider(value: Binding(get: { layer.rotation }, set: { model.updateSelected(rotation: $0) }), in: -180...180)
                        }
                    }
                    Section("Efeitos") {
                        Label("Brilho / Contraste", systemImage: "sun.max")
                        Label("Saturação", systemImage: "circle.lefthalf.filled")
                        Label("Desfoque", systemImage: "drop")
                        Label("Glow", systemImage: "sparkles")
                        Label("Transform", systemImage: "arrow.up.left.and.arrow.down.right")
                    }
                } else {
                    ContentUnavailableView("Nenhuma camada", systemImage: "square.stack.3d.up")
                }
            }
            .navigationTitle("Inspector")
            .safeAreaInset(edge: .bottom) {
                HStack {
                    Spacer()
                    Button("Fechar") { dismiss() }
                        .buttonStyle(.borderedProminent)
                }
                .padding()
                .background(.ultraThinMaterial)
            }
        }
    }
}
