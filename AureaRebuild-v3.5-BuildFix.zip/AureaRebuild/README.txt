AureaRebuild V3.4

UI/layout overhaul based on the supplied Aurea reference screenshots and recordings.

Highlights:
- True edge-to-edge editor root with black background.
- Status bar hidden while editing to remove top dead space.
- Deterministic vertical layout: header, flexible preview, compact timeline, bottom tools.
- Preview absorbs all remaining height instead of leaving a large blank region.
- Compact single-row tool strip with horizontal scrolling.
- Timeline with ruler, zoom, snap/grid controls and layer tracks.
- Video picker via PHPicker (iOS 16 compatible).
- Real AVPlayer preview and playback controls.
- Project settings, inspector, undo/redo and export hooks retained.

The project remains an independent reconstruction. It does not contain proprietary Aurea source code.
