import SwiftUI

@main
struct AureaRebuildApp: App {
    var body: some Scene {
        WindowGroup {
            EditorView()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black.ignoresSafeArea())
        }
    }
}
