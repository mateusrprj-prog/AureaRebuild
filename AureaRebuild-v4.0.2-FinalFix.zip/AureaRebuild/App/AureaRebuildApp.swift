import SwiftUI
import UIKit

@main
struct AureaRebuildApp: App {
    init() {
        // Prevent the UIKit window from exposing the default light-gray background
        // in the safe-area regions or app-switcher snapshot.
        UIView.appearance().backgroundColor = .black
    }

    @StateObject private var model = EditorModel()
    @StateObject private var mediaStore = MediaStore()

    var body: some Scene {
        WindowGroup {
            ZStack {
                Color.black.ignoresSafeArea()
                EditorView()
                    .environmentObject(model)
                    .environmentObject(mediaStore)
                    .preferredColorScheme(.dark)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
            .ignoresSafeArea()
        }
    }
}
