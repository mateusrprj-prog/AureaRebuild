import SwiftUI

struct InspectorView: View {
    @EnvironmentObject private var model: EditorModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                if let selected = model.selectedLayer {
                    Section {
                        Text(selected.name)

                        SliderRow(
                            title: "Opacidade",
                            value: Binding(
                                get: { model.selectedLayer?.opacity ?? 1 },
                                set: { newValue in model.updateSelected { $0.opacity = newValue } }
                            ),
                            range: 0...1,
                            suffix: "%",
                            multiplier: 100
                        )

                        SliderRow(
                            title: "Escala",
                            value: Binding(
                                get: { model.selectedLayer?.scale ?? 1 },
                                set: { newValue in model.updateSelected { $0.scale = newValue } }
                            ),
                            range: 0.1...3,
                            suffix: "%",
                            multiplier: 100
                        )

                        SliderRow(
                            title: "Rotação",
                            value: Binding(
                                get: { model.selectedLayer?.rotation ?? 0 },
                                set: { newValue in model.updateSelected { $0.rotation = newValue } }
                            ),
                            range: -180...180,
                            suffix: "°",
                            multiplier: 1
                        )
                    } header: {
                        Text("Camada")
                    }

                    Section {
                        Button("Excluir camada", role: .destructive) {
                            model.deleteSelected()
                            dismiss()
                        }
                        Button("Duplicar camada") {
                            model.duplicateSelected()
                        }
                    } header: {
                        Text("Ações")
                    }
                } else {
                    Section {
                        VStack(spacing: 12) {
                            Image(systemName: "square.stack.3d.up")
                                .font(.largeTitle)
                            Text("Nenhuma camada")
                                .font(.headline)
                            Text("Selecione uma camada na timeline.")
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, minHeight: 180)
                    }
                }
            }
            .navigationTitle("Inspetor")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { dismiss() }
                }
            }
        }
    }
}

private struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let suffix: String
    let multiplier: Double

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title)
                Spacer()
                Text(String(format: "%.0f", value * multiplier) + suffix)
                    .monospacedDigit()
            }
            Slider(value: $value, in: range)
        }
    }
}
