import Foundation

final class MediaStore: ObservableObject {
    @Published var importedURL: URL?

    @MainActor
    func importMedia(data: Data, fileExtension: String = "mov", completion: @escaping (URL?) -> Void) {
        let ext = fileExtension.isEmpty ? "mov" : fileExtension
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("AureaMedia-\(UUID().uuidString).\(ext)")

        do {
            try data.write(to: url, options: .atomic)
            importedURL = url
            completion(url)
        } catch {
            completion(nil)
        }
    }
}
