# AureaRebuild v2.4.2

Build iOS independente do AureaRebuild.

## Correções desta versão
- Remove dependência direta de `PhotosPickerItem` do `MediaStore`, eliminando os erros de tipo no Xcode 16.4.
- Reescreve o `InspectorView` para evitar inferência genérica ambígua em `Section`.
- Mantém deployment target iOS 16.3.
- Mantém `CFBundleExecutable = AureaRebuild` e `CFBundleIdentifier = com.aurea.aurearebuild`.
- Workflow valida executável, Info.plist e IPA antes do upload.
