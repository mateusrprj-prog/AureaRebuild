import SwiftUI
import UIKit

@main
struct AureaRebuildApp: App {
    init() {
        // Force pure black chrome so safe-area insets never show the system gray window.
        let black = UIColor.black
        UIView.appearance().backgroundColor = black
        UIWindow.appearance().backgroundColor = black
        UINavigationBar.appearance().backgroundColor = black
        UINavigationBar.appearance().barTintColor = black
        UINavigationBar.appearance().isTranslucent = false
        UITableView.appearance().backgroundColor = black
        UICollectionView.appearance().backgroundColor = black
        UIScrollView.appearance().backgroundColor = black

        // Status bar: light content on dark background
        UINavigationBar.appearance().barStyle = .black
    }

    @StateObject private var model = EditorModel()
    @StateObject private var mediaStore = MediaStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .environmentObject(mediaStore)
                .preferredColorScheme(.dark)
        }
    }
}

/// Root container that paints black edge-to-edge and keeps the editor content
/// inside the safe area for controls, without gray letterboxing.
private struct RootView: View {
    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea(.all)

            EditorView()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color.black.ignoresSafeArea(.all))
        .preferredColorScheme(.dark)
        .onAppear {
            // Extra pass: every window in the app must stay black.
            for scene in UIApplication.shared.connectedScenes {
                guard let windowScene = scene as? UIWindowScene else { continue }
                for window in windowScene.windows {
                    window.backgroundColor = .black
                    window.overrideUserInterfaceStyle = .dark
                }
            }
        }
    }
}
