import SwiftUI
import AVFoundation

struct EditorView: View {
    @StateObject private var model = EditorModel()
    @StateObject private var media = MediaStore()
    @State private var isPlaying = false
    @State private var showInspector = false
    @State private var showVideoPicker = false
    @State private var showProjectSettings = false
    @State private var showExport = false
    @State private var exportError: String?
    @State private var selectedTool: EditorTool = .select
    private let exporter = CompositionExporter()

    enum EditorTool { case select, trim, transform, effects, keyframe }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            GeometryReader { geo in
                let h = geo.size.height
                let headerH: CGFloat = 48
                let toolbarH: CGFloat = 78
                let timelineH = min(max(h * 0.22, 158), 210)
                let previewH = max(150, h - headerH - timelineH - toolbarH)

                VStack(spacing: 0) {
                    editorHeader
                        .frame(height: headerH)

                    previewArea
                        .frame(height: previewH)
                        .frame(maxWidth: .infinity)

                    timelinePanel
                        .frame(height: timelineH)

                    bottomTools
                        .frame(height: toolbarH)
                }
                .frame(width: geo.size.width, height: h, alignment: .top)
                .background(Color.black)
            }
        }
        .ignoresSafeArea(.all)
        .statusBarHidden(true)
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showVideoPicker) {
            VideoPicker(onPicked: { media.importVideo(from: $0) }, onCancel: {})
        }
        .sheet(isPresented: $showInspector) { InspectorView(model: model) }
        .sheet(isPresented: $showProjectSettings) { ProjectSettingsView(model: model) }
        .sheet(isPresented: $showExport) { ExportView(url: model.lastExportURL) }
        .alert("Exportação", isPresented: Binding(get: { exportError != nil }, set: { if !$0 { exportError = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(exportError ?? "") }
        .onAppear {
            media.onVideoImported = { url in model.importVideo(url: url) }
        }
    }

    private var editorHeader: some View {
        HStack(spacing: 0) {
            HeaderIcon("photo.on.rectangle.angled", label: "Mídia") { showVideoPicker = true }
            Text("Aurea")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .frame(maxWidth: .infinity, alignment: .leading)
            HeaderIcon("arrow.uturn.backward", label: "Desfazer") { model.undo() }
                .disabled(model.undoStack.isEmpty)
            HeaderIcon("arrow.uturn.forward", label: "Refazer") { model.redo() }
                .disabled(model.redoStack.isEmpty)
            HeaderIcon("gearshape", label: "Projeto") { showProjectSettings = true }
            HeaderIcon("slider.horizontal.3", label: "Ajustes") { showInspector = true }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 8)
        .background(Color.black)
    }

    private var previewArea: some View {
        ZStack {
            VideoPreview(url: model.videoURL, currentTime: $model.currentTime, isPlaying: $isPlaying, duration: model.duration, showGrid: model.showGrid)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()

            VStack {
                Spacer()
                HStack(spacing: 8) {
                    Text(timeString(model.currentTime))
                    Slider(value: $model.currentTime, in: 0...max(0.1, model.duration))
                    Text(timeString(model.duration))
                }
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundStyle(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.black.opacity(0.62))
                .clipShape(Capsule())
                .padding(.bottom, 8)
            }
        }
        .background(Color.black)
    }

    private var timelinePanel: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Text("Timeline")
                    .font(.system(size: 18, weight: .bold))
                Text(String(format: "%.2fx", model.timelineZoom))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.secondary)
                Spacer()
                Button { model.snapEnabled.toggle() } label: {
                    Image(systemName: model.snapEnabled ? "magnet.fill" : "magnet")
                }
                Button { model.showGrid.toggle() } label: {
                    Image(systemName: model.showGrid ? "grid.circle.fill" : "grid.circle")
                }
                Slider(value: $model.timelineZoom, in: 0.6...2.5)
                    .frame(width: 72)
                Text(timeString(model.duration))
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.secondary)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 10)
            .frame(height: 34)

            ZStack(alignment: .leading) {
                ScrollView(.horizontal, showsIndicators: false) {
                    VStack(spacing: 5) {
                        timelineRuler
                        ForEach(model.composition.layers) { layer in
                            LayerTrack(layer: layer, duration: model.duration, zoom: model.timelineZoom, selected: model.selectedID == layer.id) {
                                model.selectedID = layer.id
                                showInspector = true
                            }
                        }
                    }
                    .padding(.horizontal, 8)
                }

                GeometryReader { geo in
                    let x = min(max(8, CGFloat(model.currentTime / max(model.duration, 0.1)) * geo.size.width), geo.size.width - 8)
                    Rectangle()
                        .fill(Color.red)
                        .frame(width: 2)
                        .frame(height: geo.size.height)
                        .position(x: x, y: geo.size.height / 2)
                        .allowsHitTesting(false)
                }
            }
        }
        .background(Color(red: 0.055, green: 0.055, blue: 0.055))
    }

    private var timelineRuler: some View {
        HStack(spacing: 0) {
            ForEach(0...10, id: \.self) { i in
                VStack(spacing: 1) {
                    Rectangle().frame(width: 1, height: i % 5 == 0 ? 7 : 4)
                    Text(String(format: "%.0f", model.duration * Double(i) / 10))
                        .font(.system(size: 7, design: .monospaced))
                }
                .frame(width: 62, alignment: .leading)
                .foregroundStyle(.secondary)
            }
        }
        .frame(height: 20, alignment: .leading)
    }

    private var bottomTools: some View {
        HStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 5) {
                    ToolButton(title: "Vídeo", icon: "video.badge.plus") { showVideoPicker = true }
                    ToolButton(title: "Texto", icon: "textformat") { model.addText() }
                    ToolButton(title: "Sólido", icon: "square.fill") { model.addSolid() }
                    ToolButton(title: "Forma", icon: "circle") { model.addShape() }
                    ToolButton(title: "Duplicar", icon: "plus.square.on.square") { model.duplicateSelected() }
                    ToolButton(title: "Dividir", icon: "scissors") { model.splitSelected() }
                    ToolButton(title: "Excluir", icon: "trash") { model.deleteSelected() }
                    ToolButton(title: "Mover", icon: "move.3d") { selectedTool = .transform; showInspector = true }
                    ToolButton(title: "Efeitos", icon: "wand.and.stars") { selectedTool = .effects; showInspector = true }
                    ToolButton(title: "Keyframe", icon: "diamond") { selectedTool = .keyframe; showInspector = true }
                    ToolButton(title: "Exportar", icon: "square.and.arrow.up") { exportVideo() }
                }
                .padding(.horizontal, 6)
            }
        }
        .background(Color.black)
        .overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.07)).frame(height: 1) }
    }

    private func exportVideo() {
        guard model.videoURL != nil else { exportError = "Importe um vídeo primeiro."; return }
        Task {
            do {
                _ = try await exporter.export(model: model)
                showExport = true
            } catch { exportError = error.localizedDescription }
        }
    }

    private func timeString(_ value: Double) -> String {
        let total = max(0, Int(value.rounded(.down)))
        return String(format: "%02d:%02d", total / 60, total % 60)
    }
}

private struct HeaderIcon: View {
    let systemName: String
    let label: String
    let action: () -> Void
    init(_ systemName: String, label: String, action: @escaping () -> Void) {
        self.systemName = systemName; self.label = label; self.action = action
    }
    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 18, weight: .medium))
                .frame(width: 38, height: 42)
                .contentShape(Rectangle())
        }
        .accessibilityLabel(label)
    }
}

struct LayerTrack: View {
    let layer: EditorLayer
    let duration: Double
    let zoom: Double
    let selected: Bool
    let action: () -> Void

    var body: some View {
        GeometryReader { geo in
            let total = max(geo.size.width, 620)
            let start = max(0, layer.startTime / max(duration, 0.1))
            let end = min(1, layer.endTime / max(duration, 0.1))
            let leading = total * start * zoom
            let width = max(92, total * max(0.03, end - start) * zoom)
            Button(action: action) {
                HStack(spacing: 8) {
                    Image(systemName: icon).frame(width: 20)
                    Text(layer.name).font(.system(size: 11, weight: .semibold)).lineLimit(1)
                    if !layer.keyframes.isEmpty { Image(systemName: "diamond.fill").font(.system(size: 8)) }
                }
                .padding(.horizontal, 9)
                .frame(width: width, height: 38)
                .background(selected ? Color.blue.opacity(0.62) : Color.white.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .offset(x: leading)
        }
        .frame(width: max(620, 620 * zoom), height: 40)
    }

    private var icon: String {
        switch layer.kind {
        case .video: return "video"
        case .image: return "photo"
        case .text: return "textformat"
        case .solid: return "square.fill"
        case .shape: return "circle"
        }
    }
}

struct ToolButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 19, weight: .medium))
                Text(title).font(.system(size: 9, weight: .medium))
            }
            .frame(width: 64, height: 64)
            .background(Color.white.opacity(0.055))
            .clipShape(RoundedRectangle(cornerRadius: 9))
        }
        .buttonStyle(.plain)
        .foregroundStyle(.white)
    }
}
