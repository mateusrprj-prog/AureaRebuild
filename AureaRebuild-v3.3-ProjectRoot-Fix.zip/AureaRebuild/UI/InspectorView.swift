import SwiftUI

struct InspectorView: View {
    @EnvironmentObject private var model: EditorModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                if let selected = model.selectedLayer {
                    Section(header: Text("Camada")) {
                        Text(selected.name)
                        SliderRow(title: "Opacidade", value: Binding(get: { model.selectedLayer?.opacity ?? 1 }, set: { newValue in model.updateSelected(recordHistory: false) { layer in layer.opacity = newValue } }), range: 0...1, suffix: "%", multiplier: 100)
                        SliderRow(title: "Escala", value: Binding(get: { model.selectedLayer?.scale ?? 1 }, set: { newValue in model.updateSelected(recordHistory: false) { layer in layer.scale = newValue } }), range: 0.1...3, suffix: "%", multiplier: 100)
                        SliderRow(title: "Rotação", value: Binding(get: { model.selectedLayer?.rotation ?? 0 }, set: { newValue in model.updateSelected(recordHistory: false) { layer in layer.rotation = newValue } }), range: -180...180, suffix: "°", multiplier: 1)
                        SliderRow(title: "Início", value: Binding(get: { model.selectedLayer?.start ?? 0 }, set: { newValue in model.updateSelected(recordHistory: false) { layer in layer.start = min(newValue, layer.end - 0.1) } }), range: 0...max(0.1, model.duration - 0.1), suffix: "s", multiplier: 1)
                        SliderRow(title: "Fim", value: Binding(get: { model.selectedLayer?.end ?? model.duration }, set: { newValue in model.updateSelected(recordHistory: false) { layer in layer.end = max(newValue, layer.start + 0.1) } }), range: 0.1...max(0.1, model.duration), suffix: "s", multiplier: 1)
                    }

                    Section(header: Text("Ações")) {
                        Button("Duplicar camada") { model.duplicateSelected() }
                        Button("Excluir camada", role: .destructive) {
                            model.deleteSelected()
                            dismiss()
                        }
                    }
                } else {
                    Section(header: Text("Camada")) {
                        VStack(spacing: 12) {
                            Image(systemName: "square.stack.3d.up")
                                .font(.largeTitle)
                            Text("Nenhuma camada")
                                .font(.headline)
                            Text("Selecione uma camada na timeline.")
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, minHeight: 180)
                    }
                }
            }
            .navigationTitle("Inspetor")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { dismiss() }
                }
            }
        }
    }
}

private struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let suffix: String
    let multiplier: Double

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title)
                Spacer()
                Text(String(format: "%.0f", value * multiplier) + suffix)
                    .monospacedDigit()
            }
            Slider(value: $value, in: range)
        }
    }
}
