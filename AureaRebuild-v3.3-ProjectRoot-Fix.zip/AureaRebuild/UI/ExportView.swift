import SwiftUI

struct ExportView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: EditorModel
    @EnvironmentObject private var mediaStore: MediaStore
    @StateObject private var exporter = ExportService()

    var body: some View {
        NavigationStack {
            Form {
                Section("Exportação") {
                    LabeledContent("Resolução", value: "Original / até 1080p")
                    LabeledContent("FPS", value: "30")
                    LabeledContent("Codec", value: "H.264")
                    LabeledContent("Qualidade", value: "Alta")
                    LabeledContent("Duração", value: String(format: "%.2fs", model.duration))
                }

                if exporter.isExporting {
                    Section("Progresso") {
                        ProgressView(value: exporter.progress)
                        Text("Exportando… \(Int(exporter.progress * 100))%")
                            .foregroundStyle(.secondary)
                    }
                }

                Section {
                    Button {
                        guard let url = mediaStore.importedURL else {
                            exporter.error = "Importe um vídeo da galeria antes de exportar."
                            return
                        }
                        exporter.exportVideo(from: url, duration: model.duration)
                    } label: {
                        HStack {
                            Spacer()
                            Label("Exportar para a galeria", systemImage: "square.and.arrow.down")
                            Spacer()
                        }
                    }
                    .disabled(exporter.isExporting)
                }

                if let message = exporter.message {
                    Section { Label(message, systemImage: "checkmark.circle.fill") }
                }
                if let error = exporter.error {
                    Section { Label(error, systemImage: "exclamationmark.triangle.fill") }
                }
            }
            .navigationTitle("Exportar")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Fechar") { dismiss() }
                }
            }
        }
    }
}
