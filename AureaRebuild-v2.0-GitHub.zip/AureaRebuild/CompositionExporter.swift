import Foundation
import AVFoundation
import CoreImage
import CoreImage.CIFilterBuiltins

@MainActor
final class CompositionExporter {
    func export(model: EditorModel) async throws -> URL {
        guard let inputURL = model.videoURL else {
            throw NSError(domain: "Aurea", code: 10, userInfo: [NSLocalizedDescriptionKey: "Importe um vídeo primeiro."])
        }
        let asset = AVAsset(url: inputURL)
        guard let sourceVideo = try await asset.loadTracks(withMediaType: .video).first else {
            throw NSError(domain: "Aurea", code: 11, userInfo: [NSLocalizedDescriptionKey: "O arquivo não contém vídeo."])
        }

        let duration = try await asset.load(.duration)
        let sourceDuration = max(0, duration.seconds)
        let start = max(0, min(model.trimStart, sourceDuration))
        let end = max(start + 0.05, min(model.trimEnd, sourceDuration))
        let range = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600),
                                end: CMTime(seconds: end, preferredTimescale: 600))

        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw NSError(domain: "Aurea", code: 12)
        }
        try videoTrack.insertTimeRange(range, of: sourceVideo, at: .zero)
        videoTrack.preferredTransform = try await sourceVideo.load(.preferredTransform)

        if let audio = try await asset.loadTracks(withMediaType: .audio).first,
           let audioTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            try audioTrack.insertTimeRange(range, of: audio, at: .zero)
            let params = AVMutableAudioMixInputParameters(track: audioTrack)
            params.setVolume(Float(model.volume), at: .zero)
            let mix = AVMutableAudioMix()
            mix.inputParameters = [params]
            return try await performExport(composition: composition, audioMix: mix, model: model)
        }
        return try await performExport(composition: composition, audioMix: nil, model: model)
    }

    private func performExport(composition: AVMutableComposition, audioMix: AVAudioMix?, model: EditorModel) async throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Aurea-V2-\(UUID().uuidString).mp4")
        try? FileManager.default.removeItem(at: url)
        guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
            throw NSError(domain: "Aurea", code: 13)
        }
        session.outputURL = url
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true
        session.audioMix = audioMix

        let brightness = model.brightness
        let contrast = model.contrast
        let saturation = model.saturation
        let blur = model.blur
        let videoComposition = AVVideoComposition(asset: composition) { request in
            var image = request.sourceImage
            let controls = CIFilter.colorControls()
            controls.inputImage = image
            controls.brightness = Float(brightness)
            controls.contrast = Float(contrast)
            controls.saturation = Float(saturation)
            if let output = controls.outputImage { image = output }
            if blur > 0 {
                let filter = CIFilter.gaussianBlur()
                filter.inputImage = image
                filter.radius = Float(blur)
                if let output = filter.outputImage?.cropped(to: image.extent) { image = output }
            }
            request.finish(with: image, context: nil)
        }
        session.videoComposition = videoComposition

        model.isExporting = true
        model.exportProgress = 0
        defer { model.isExporting = false }

        let progressTask = Task { @MainActor in
            while !Task.isCancelled {
                let status = session.status
                if status == .completed || status == .failed || status == .cancelled { break }
                model.exportProgress = Double(session.progress)
                try? await Task.sleep(nanoseconds: 150_000_000)
            }
        }
        defer { progressTask.cancel() }

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            session.exportAsynchronously {
                switch session.status {
                case .completed:
                    continuation.resume()
                case .failed, .cancelled:
                    continuation.resume(throwing: session.error ?? NSError(domain: "Aurea", code: 14, userInfo: [NSLocalizedDescriptionKey: "Falha ao exportar."]))
                default:
                    continuation.resume(throwing: NSError(domain: "Aurea", code: 15, userInfo: [NSLocalizedDescriptionKey: "Exportação interrompida."]))
                }
            }
        }
        model.exportProgress = 1
        model.lastExportURL = url
        return url
    }
}
