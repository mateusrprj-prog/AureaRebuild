import SwiftUI
import AVFoundation

struct EditorView: View {
    @StateObject private var model = EditorModel()
    @StateObject private var media = MediaStore()
    @State private var isPlaying = false
    @State private var showInspector = false
    @State private var showVideoPicker = false
    @State private var showProjectSettings = false
    @State private var showExport = false
    @State private var exportError: String?
    @State private var activeTool: ToolMode = .select
    private let exporter = CompositionExporter()

    enum ToolMode { case select, trim, transform, keyframe }

    var body: some View {
        // Compact edge-to-edge editor. The preview is the flexible region;
        // timeline and tools use fixed, compact heights so there is no dead space.
        VStack(spacing: 0) {
            header
                .frame(height: 50)

            previewArea
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .layoutPriority(1)

            timelinePanel
                .frame(height: 188)

            bottomTools
                .frame(height: 112)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
        .ignoresSafeArea(.all)
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showVideoPicker) {
            VideoPicker(onPicked: { media.importVideo(from: $0) }, onCancel: {})
        }
        .sheet(isPresented: $showInspector) { InspectorView(model: model) }
        .sheet(isPresented: $showProjectSettings) { ProjectSettingsView(model: model) }
        .sheet(isPresented: $showExport) { ExportView(url: model.lastExportURL) }
        .alert("Exportação", isPresented: Binding(get: { exportError != nil }, set: { if !$0 { exportError = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(exportError ?? "") }
        .onAppear { media.onVideoImported = { url in model.importVideo(url: url) } }
    }

    private var header: some View {
        HStack(spacing: 18) {
            Button { showVideoPicker = true } label: { Image(systemName: "photo.on.rectangle.angled") }
            Text("Aurea").font(.headline.bold())
            Spacer()
            Button { model.undo() } label: { Image(systemName: "arrow.uturn.backward") }
                .disabled(model.undoStack.isEmpty)
            Button { model.redo() } label: { Image(systemName: "arrow.uturn.forward") }
                .disabled(model.redoStack.isEmpty)
            Button { showProjectSettings = true } label: { Image(systemName: "gearshape") }
            Button { showInspector = true } label: { Image(systemName: "slider.horizontal.3") }
        }
        .font(.title3)
        .foregroundStyle(.white)
        .padding(.horizontal, 18)
        .background(Color.black)
    }

    private var previewArea: some View {
        ZStack {
            VideoPreview(url: model.videoURL, currentTime: $model.currentTime, isPlaying: $isPlaying, duration: model.duration, showGrid: model.showGrid)
                .padding(.horizontal, 6)
                .padding(.vertical, 4)
            VStack {
                Spacer()
                HStack(spacing: 10) {
                    Text(timeString(model.currentTime)).font(.caption.monospacedDigit())
                    Slider(value: $model.currentTime, in: 0...max(0.1, model.duration))
                    Text(timeString(model.duration)).font(.caption.monospacedDigit())
                }
                .padding(.horizontal, 14)
                .padding(.bottom, 6)
                .foregroundStyle(.white)
            }
        }
        .background(Color(white: 0.035))
    }

    private var timelinePanel: some View {
        VStack(spacing: 4) {
            HStack {
                Text("Timeline").font(.title3.bold())
                Text("•").foregroundStyle(.secondary)
                Text("\(model.composition.width)×\(model.composition.height)")
                    .font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button { model.snapEnabled.toggle() } label: {
                    Image(systemName: model.snapEnabled ? "magnet.fill" : "magnet")
                }
                Button { model.showGrid.toggle() } label: {
                    Image(systemName: model.showGrid ? "grid.circle.fill" : "grid.circle")
                }
                Slider(value: $model.timelineZoom, in: 0.6...2.5)
                    .frame(width: 90)
                Text(String(format: "%.1fs", model.duration)).font(.caption.monospacedDigit())
            }
            .padding(.horizontal, 14)

            timelineRuler
            ScrollView(.vertical, showsIndicators: true) {
                VStack(spacing: 7) {
                    ForEach(model.composition.layers) { layer in
                        LayerTrack(layer: layer, duration: model.duration, zoom: model.timelineZoom, selected: model.selectedID == layer.id, currentTime: model.currentTime) {
                            model.selectedID = layer.id
                            showInspector = true
                        }
                    }
                }
                .padding(.horizontal, 12)
                .padding(.bottom, 8)
            }
        }
        .padding(.vertical, 4)
        .background(Color(white: 0.075))
    }

    private var timelineRuler: some View {
        GeometryReader { geo in
            let width = max(geo.size.width - 24, 1)
            HStack(spacing: 0) {
                ForEach(0...10, id: \.self) { i in
                    VStack(spacing: 2) {
                        Rectangle().frame(width: 1, height: i % 5 == 0 ? 9 : 5)
                        Text(String(format: "%.0f", model.duration * Double(i) / 10.0)).font(.system(size: 8))
                    }
                    .frame(width: width / 10, alignment: .leading)
                    .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 12)
        }
        .frame(height: 20)
    }

    private var bottomTools: some View {
        VStack(spacing: 8) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ToolButton(title: "Vídeo", icon: "video.badge.plus") { showVideoPicker = true }
                    ToolButton(title: "Texto", icon: "textformat") { model.addText() }
                    ToolButton(title: "Sólido", icon: "square.fill") { model.addSolid() }
                    ToolButton(title: "Forma", icon: "circle") { model.addShape() }
                    ToolButton(title: "Duplicar", icon: "plus.square.on.square") { model.duplicateSelected() }
                    ToolButton(title: "Dividir", icon: "scissors") { model.splitSelected() }
                    ToolButton(title: "Excluir", icon: "trash") { model.deleteSelected() }
                    ToolButton(title: "Transformar", icon: "move.3d") { activeTool = .transform; showInspector = true }
                    ToolButton(title: "Keyframe", icon: "diamond") { activeTool = .keyframe; showInspector = true }
                    ToolButton(title: "Efeitos", icon: "wand.and.stars") { showInspector = true }
                    ToolButton(title: "Projeto", icon: "rectangle.3.group") { showProjectSettings = true }
                    ToolButton(title: "Exportar", icon: "square.and.arrow.up") { exportVideo() }
                }
                .padding(.horizontal, 8)
            }
        }
        .padding(.horizontal, 0)
        .padding(.vertical, 4)
        .background(Color(white: 0.035))
    }

    private func exportVideo() {
        guard model.videoURL != nil else { exportError = "Importe um vídeo primeiro."; return }
        Task {
            do { _ = try await exporter.export(model: model); showExport = true }
            catch { exportError = error.localizedDescription }
        }
    }

    private func timeString(_ value: Double) -> String {
        let total = max(0, Int(value.rounded(.down)))
        return String(format: "%02d:%02d", total / 60, total % 60)
    }
}

struct LayerTrack: View {
    let layer: EditorLayer
    let duration: Double
    let zoom: Double
    let selected: Bool
    let currentTime: Double
    let action: () -> Void

    var body: some View {
        GeometryReader { geo in
            let baseWidth = max(geo.size.width, 260)
            let start = max(0, layer.startTime / max(duration, 0.1))
            let end = min(1, layer.endTime / max(duration, 0.1))
            let leading = baseWidth * start * zoom
            let width = max(82, baseWidth * max(0.03, end - start) * zoom)
            Button(action: action) {
                HStack(spacing: 10) {
                    Image(systemName: icon)
                        .frame(width: 24)
                    Text(layer.name)
                        .font(.caption.bold())
                        .lineLimit(1)
                    Spacer(minLength: 4)
                    if !layer.keyframes.isEmpty { Image(systemName: "diamond.fill").font(.caption2) }
                }
                .padding(.horizontal, 10)
                .frame(width: width, height: 48)
                .background(selected ? Color.blue.opacity(0.62) : Color.white.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 9))
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .offset(x: leading)
        }
        .frame(height: 48)
        .overlay {
            GeometryReader { geo in
                let x = min(max(0, currentTime / max(duration, 0.1)), 1) * geo.size.width
                Rectangle()
                    .fill(.red)
                    .frame(width: 2, height: geo.size.height)
                    .position(x: x, y: geo.size.height / 2)
                    .allowsHitTesting(false)
            }
        }
    }

    private var icon: String {
        switch layer.kind {
        case .video: return "video"
        case .image: return "photo"
        case .text: return "textformat"
        case .solid: return "square.fill"
        case .shape: return "circle"
        }
    }
}

struct ToolButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.title3)
                Text(title).font(.system(size: 10, weight: .medium))
            }
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(Color.white.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
        .foregroundStyle(.white)
    }
}

struct InspectorView: View {
    @ObservedObject var model: EditorModel
    var body: some View {
        NavigationStack {
            Form {
                Section("Transformação") {
                    SliderRow(title: "Opacidade", value: Binding(get: { model.selectedLayer?.opacity ?? 1 }, set: { model.updateSelected(opacity: $0) }), range: 0...1)
                    SliderRow(title: "Escala", value: Binding(get: { model.selectedLayer?.scale ?? 1 }, set: { model.updateSelected(scale: $0) }), range: 0.1...3)
                    SliderRow(title: "Rotação", value: Binding(get: { model.selectedLayer?.rotation ?? 0 }, set: { model.updateSelected(rotation: $0) }), range: -180...180)
                    SliderRow(title: "Posição X", value: Binding(get: { model.selectedLayer?.positionX ?? 0 }, set: { model.updateSelected(x: $0) }), range: -100...100)
                    SliderRow(title: "Posição Y", value: Binding(get: { model.selectedLayer?.positionY ?? 0 }, set: { model.updateSelected(y: $0) }), range: -100...100)
                }
                Section("Efeitos") {
                    SliderRow(title: "Brilho", value: $model.brightness, range: -1...1)
                    SliderRow(title: "Contraste", value: $model.contrast, range: 0...2)
                    SliderRow(title: "Saturação", value: $model.saturation, range: 0...2)
                    SliderRow(title: "Desfoque", value: $model.blur, range: 0...20)
                    SliderRow(title: "Volume", value: $model.volume, range: 0...1)
                    Button("Restaurar efeitos") { model.resetEffects() }
                }
                Section("Keyframes") {
                    Button("Adicionar keyframe de escala") { model.addKeyframe(property: "scale", value: model.selectedLayer?.scale ?? 1) }
                    Button("Adicionar keyframe de rotação") { model.addKeyframe(property: "rotation", value: model.selectedLayer?.rotation ?? 0) }
                    Button("Adicionar keyframe de posição X") { model.addKeyframe(property: "x", value: model.selectedLayer?.positionX ?? 0) }
                }
            }
            .navigationTitle("Inspector")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack { Text(title); Spacer(); Text(String(format: "%.2f", value)).font(.caption.monospacedDigit()).foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}

struct ProjectSettingsView: View {
    @ObservedObject var model: EditorModel
    var body: some View {
        NavigationStack {
            Form {
                Section("Canvas") {
                    Button("Vertical 1080 × 1920") { model.setAspect(1080, 1920) }
                    Button("Horizontal 1920 × 1080") { model.setAspect(1920, 1080) }
                    Button("Quadrado 1080 × 1080") { model.setAspect(1080, 1080) }
                }
                Section("Projeto") {
                    HStack { Text("Resolução"); Spacer(); Text("\(model.composition.width) × \(model.composition.height)").foregroundStyle(.secondary) }
                    HStack { Text("FPS"); Spacer(); Text("\(model.composition.frameRate)").foregroundStyle(.secondary) }
                    HStack { Text("Duração"); Spacer(); Text(String(format: "%.2fs", model.duration)).foregroundStyle(.secondary) }
                }
            }
            .navigationTitle("Projeto")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ExportView: View {
    let url: URL?
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "checkmark.circle.fill").font(.system(size: 64)).foregroundStyle(.green)
                Text("Exportação concluída").font(.title2.bold())
                if let url { ShareLink(item: url) { Label("Compartilhar MP4", systemImage: "square.and.arrow.up") } }
                Text("O vídeo foi renderizado em MP4.").foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding()
            .navigationTitle("Exportar")
        }
    }
}
