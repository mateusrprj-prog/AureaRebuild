AureaRebuild V2

Atualização focada em edição real de vídeo:
- Importação de vídeos pela Fototeca
- Preview com AVPlayer/VideoPlayer
- Timeline com camadas
- Trim IN/OUT
- Volume
- Inspector com brilho, contraste, saturação e desfoque (UI preparada para pipeline de efeitos)
- Undo/Redo
- Exportação MP4 real do trecho selecionado
- Compartilhamento do MP4 exportado
- Base preparada para próximas versões: efeitos, keyframes, composição 2D e 3D

Build:
1. GitHub Actions em macOS
2. xcodegen generate --spec project.yml
3. xcodebuild archive com CODE_SIGNING_ALLOWED=NO
4. Empacotar Products/Applications/AureaRebuild.app em Payload

V2.0.4 compatibility patch: iOS 16-compatible onChange syntax, explicit Combine imports, and explicit Data.WritingOptions.atomic.
