import Foundation
import AVFoundation
import CoreImage
import CoreImage.CIFilterBuiltins

@MainActor
final class CompositionExporter {
    func export(model: EditorModel) async throws -> URL {
        guard let inputURL = model.videoURL else {
            throw NSError(domain: "Aurea", code: 10, userInfo: [NSLocalizedDescriptionKey: "Importe um vídeo primeiro."])
        }

        let asset = AVAsset(url: inputURL)
        guard let sourceVideo = asset.tracks(withMediaType: .video).first else {
            throw NSError(domain: "Aurea", code: 11, userInfo: [NSLocalizedDescriptionKey: "O arquivo não contém vídeo."])
        }

        let sourceDuration = max(0.1, asset.duration.seconds)
        let start = max(0, min(model.trimStart, sourceDuration - 0.05))
        let end = max(start + 0.05, min(model.trimEnd, sourceDuration))
        let range = CMTimeRange(
            start: CMTime(seconds: start, preferredTimescale: 600),
            end: CMTime(seconds: end, preferredTimescale: 600)
        )

        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw NSError(domain: "Aurea", code: 12, userInfo: [NSLocalizedDescriptionKey: "Não foi possível criar a faixa de vídeo."])
        }

        try videoTrack.insertTimeRange(range, of: sourceVideo, at: .zero)
        videoTrack.preferredTransform = sourceVideo.preferredTransform

        var audioMix: AVAudioMix?
        if let audio = asset.tracks(withMediaType: .audio).first,
           let audioTrack = composition.addMutableTrack(
                withMediaType: .audio,
                preferredTrackID: kCMPersistentTrackID_Invalid
           ) {
            try audioTrack.insertTimeRange(range, of: audio, at: .zero)
            let params = AVMutableAudioMixInputParameters(track: audioTrack)
            params.setVolume(Float(model.volume), at: .zero)
            let mix = AVMutableAudioMix()
            mix.inputParameters = [params]
            audioMix = mix
        }

        return try await performExport(
            composition: composition,
            audioMix: audioMix,
            model: model
        )
    }

    private func performExport(
        composition: AVMutableComposition,
        audioMix: AVAudioMix?,
        model: EditorModel
    ) async throws -> URL {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("Aurea-V2-\(UUID().uuidString).mp4")
        try? FileManager.default.removeItem(at: url)

        guard let session = AVAssetExportSession(
            asset: composition,
            presetName: AVAssetExportPresetHighestQuality
        ) else {
            throw NSError(domain: "Aurea", code: 13, userInfo: [NSLocalizedDescriptionKey: "Este vídeo não pode ser exportado neste formato."])
        }

        session.outputURL = url
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true
        session.audioMix = audioMix

        let brightness = model.brightness
        let contrast = model.contrast
        let saturation = model.saturation
        let blur = model.blur

        session.videoComposition = AVVideoComposition(
            asset: composition,
            applyingCIFiltersWithHandler: { request in
                var image = request.sourceImage

                let controls = CIFilter.colorControls()
                controls.inputImage = image
                controls.brightness = Float(brightness)
                controls.contrast = Float(contrast)
                controls.saturation = Float(saturation)
                if let output = controls.outputImage {
                    image = output
                }

                if blur > 0 {
                    let filter = CIFilter.gaussianBlur()
                    filter.inputImage = image
                    filter.radius = Float(blur)
                    if let output = filter.outputImage?.cropped(to: request.sourceImage.extent) {
                        image = output
                    }
                }

                request.finish(with: image, context: nil)
            }
        )

        model.isExporting = true
        model.exportProgress = 0
        defer { model.isExporting = false }

        try await exportSession(session, model: model)

        model.exportProgress = 1
        model.lastExportURL = url
        return url
    }

    private func exportSession(
        _ session: AVAssetExportSession,
        model: EditorModel
    ) async throws {
        await withCheckedContinuation { continuation in
            session.exportAsynchronously {
                continuation.resume()
            }
        }

        switch session.status {
        case .completed:
            return
        case .failed, .cancelled:
            throw session.error ?? NSError(
                domain: "Aurea",
                code: 14,
                userInfo: [NSLocalizedDescriptionKey: "Falha ao exportar o vídeo."]
            )
        default:
            throw NSError(
                domain: "Aurea",
                code: 15,
                userInfo: [NSLocalizedDescriptionKey: "Exportação interrompida."]
            )
        }
    }
}
