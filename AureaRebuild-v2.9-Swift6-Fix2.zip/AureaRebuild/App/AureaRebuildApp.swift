import SwiftUI
import UIKit

@main
struct AureaRebuildApp: App {
    @StateObject private var model = EditorModel()
    @StateObject private var mediaStore = MediaStore()

    var body: some Scene {
        WindowGroup {
            EditorView()
                .environmentObject(model)
                .environmentObject(mediaStore)
                .preferredColorScheme(.dark)
                .background(Color.black)
                .ignoresSafeArea()
        }
    }
}
