# Aurea Rebuild 2.8.0

Atualização focada em importação de vídeo e limpeza da interface.

- Botão **Importar vídeo** visível no topo, no centro do preview e na barra inferior.
- Importação da galeria usando `PhotosPicker` + `CoreTransferable`/`FileRepresentation`, evitando carregar o vídeo inteiro como `Data`.
- Validação real do arquivo e duração antes de criar a camada.
- O vídeo importado entra imediatamente no preview e na timeline.
- Relógio da timeline acompanha a reprodução do `AVPlayer`.
- Removidas as camadas fictícias que apareciam cinza no primeiro carregamento.
- Removido o placeholder com partículas/círculos cinza do preview vazio.
- Interface inicial mais limpa e com ação de importação impossível de confundir.
- Mantido iOS 16.3+ e bundle id `com.aurea.aurearebuild`.

Build: 2800


## v2.8.0
- Corrige o acesso ao `PhotosPickerItem` mantendo o MediaStore independente de PhotosUI.
- Corrige as atualizações de estado do player sob Swift 6/concorrência estrita.
- Corrige o `mediaStore` ausente na barra inferior.
- Troca a faixa de mídia cinza por uma faixa azul para deixar o estado visual mais claro.
- Mantém três pontos visíveis para importar vídeo: topo, preview e barra inferior.


## v2.9 Swift 6 fix
- Removed MainActor-isolated state from the PhotosPicker label closure.
- Removed the unused MediaStore environment dependency from the bottom toolbar.
- Replaced LabelStyle.titleAndIcon in PhotosPicker with a simple HStack to avoid Swift 6 concurrency diagnostics.
