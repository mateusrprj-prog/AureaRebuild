import Foundation
import SwiftUI

enum LayerKind: String, Codable, CaseIterable {
    case text
    case solid
    case shape
    case image
    case video
}

struct EditorLayer: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var kind: LayerKind
    var opacity: Double = 1.0
    var scale: Double = 1.0
    var rotation: Double = 0.0
    var colorHex: String = "#FFFFFF"
}

struct Composition: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String = "Novo Projeto"
    var width: Int = 1080
    var height: Int = 1920
    var duration: Double = 10.0
    var layers: [EditorLayer] = []
}

@MainActor
final class EditorModel: ObservableObject {
    @Published var composition: Composition
    @Published var selectedID: UUID?
    @Published private(set) var undoStack: [Composition] = []
    @Published private(set) var redoStack: [Composition] = []

    init(composition: Composition = Composition()) {
        self.composition = composition
    }

    var selectedLayer: EditorLayer? {
        guard let id = selectedID else { return nil }
        return composition.layers.first(where: { $0.id == id })
    }

    func add(_ layer: EditorLayer) {
        saveUndo()
        composition.layers.append(layer)
        selectedID = layer.id
    }

    func deleteSelected() {
        guard let id = selectedID else { return }
        saveUndo()
        composition.layers.removeAll { $0.id == id }
        selectedID = composition.layers.last?.id
    }

    func duplicateSelected() {
        guard let layer = selectedLayer else { return }
        saveUndo()
        var copy = layer
        copy.id = UUID()
        copy.name += " Copy"
        composition.layers.append(copy)
        selectedID = copy.id
    }

    func splitSelected() {
        guard let layer = selectedLayer else { return }
        saveUndo()
        var copy = layer
        copy.id = UUID()
        copy.name += " Split"
        composition.layers.append(copy)
        selectedID = copy.id
    }

    func updateSelected(opacity: Double? = nil, scale: Double? = nil, rotation: Double? = nil) {
        guard let id = selectedID,
              let index = composition.layers.firstIndex(where: { $0.id == id }) else { return }
        if let opacity { composition.layers[index].opacity = opacity }
        if let scale { composition.layers[index].scale = scale }
        if let rotation { composition.layers[index].rotation = rotation }
    }

    func undo() {
        guard let previous = undoStack.popLast() else { return }
        redoStack.append(composition)
        composition = previous
        selectedID = composition.layers.last?.id
    }

    func redo() {
        guard let next = redoStack.popLast() else { return }
        undoStack.append(composition)
        composition = next
        selectedID = composition.layers.last?.id
    }

    private func saveUndo() {
        undoStack.append(composition)
        if undoStack.count > 30 { undoStack.removeFirst() }
        redoStack.removeAll()
    }
}
