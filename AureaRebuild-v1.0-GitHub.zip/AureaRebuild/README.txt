AureaRebuild v1.0
Independent SwiftUI reconstruction shell.

Build:
1. Generate the Xcode project with XcodeGen.
2. Archive for iOS.
3. Package Payload/AureaRebuild.app into an unsigned IPA.

This is an independent implementation and does not contain the original Aurea binary.
