import SwiftUI

struct EditorView: View {
    @StateObject private var model = EditorModel()

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                PreviewView(model: model)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                TimelineView(model: model)
                    .frame(height: 170)

                ToolbarView(model: model)
                    .frame(height: 62)
            }
            .background(Color.black)
            .navigationTitle("Aurea")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { model.undo() } label: {
                        Image(systemName: "arrow.uturn.backward")
                    }
                    Button { model.redo() } label: {
                        Image(systemName: "arrow.uturn.forward")
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct PreviewView: View {
    @ObservedObject var model: EditorModel

    var body: some View {
        ZStack {
            Color(white: 0.08)
            GeometryReader { geo in
                let w = min(geo.size.width * 0.72, 280)
                let h = w * 16.0 / 9.0
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.black)
                        .frame(width: w, height: min(h, geo.size.height * 0.9))
                        .overlay {
                            VStack(spacing: 10) {
                                Image(systemName: "sparkles")
                                    .font(.system(size: 36))
                                Text("Aurea")
                                    .font(.headline)
                                Text("\(model.composition.layers.count) camada(s)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }
}

struct TimelineView: View {
    @ObservedObject var model: EditorModel

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Timeline")
                    .font(.headline)
                Spacer()
                Text(String(format: "%.1fs", model.composition.duration))
                    .foregroundStyle(.secondary)
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(model.composition.layers) { layer in
                        Button {
                            model.selectedID = layer.id
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(layer.name)
                                    .font(.caption.bold())
                                    .lineLimit(1)
                                Text(layer.kind.rawValue.capitalized)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            .padding(10)
                            .frame(width: 130, alignment: .leading)
                            .background(model.selectedID == layer.id ? Color.blue.opacity(0.35) : Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                }
                .padding(.horizontal, 12)
            }

            if let selected = model.selectedLayer {
                HStack {
                    Text(selected.name)
                        .font(.caption)
                    Spacer()
                    Slider(
                        value: Binding(
                            get: { model.selectedLayer?.opacity ?? 1 },
                            set: { model.updateSelected(opacity: $0) }
                        ),
                        in: 0...1
                    )
                    .frame(width: 140)
                }
                .padding(.horizontal, 12)
            }
        }
        .padding(.vertical, 10)
        .background(Color(white: 0.07))
    }
}

struct ToolbarView: View {
    @ObservedObject var model: EditorModel

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 14) {
                tool("Texto", "textformat") {
                    model.add(EditorLayer(name: "Texto", kind: .text))
                }
                tool("Sólido", "square.fill") {
                    model.add(EditorLayer(name: "Sólido", kind: .solid))
                }
                tool("Forma", "circle") {
                    model.add(EditorLayer(name: "Forma", kind: .shape))
                }
                tool("Duplicar", "plus.square.on.square") {
                    model.duplicateSelected()
                }
                tool("Dividir", "scissors") {
                    model.splitSelected()
                }
                tool("Excluir", "trash") {
                    model.deleteSelected()
                }
            }
            .padding(.horizontal, 14)
        }
        .background(Color(white: 0.05))
    }

    private func tool(_ title: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                Text(title).font(.caption2)
            }
        }
        .foregroundStyle(.white)
    }
}

#Preview {
    EditorView()
}
