import SwiftUI

@main
struct AureaRebuildApp: App {
    var body: some Scene {
        WindowGroup {
            EditorView()
        }
    }
}
