import SwiftUI

/// Bottom tool strip — dense, icon-first, professional mobile editor style.
struct ToolbarUI: View {
    @Binding var selectedTool: EditorTool
    var onToolSelected: (EditorTool) -> Void = { _ in }

    private let tools: [EditorTool] = [
        .media, .text, .solid, .adjustment, .null, .shape, .audio, .presets
    ]

    private let accent = Color(red: 0.22, green: 0.84, blue: 0.42)

    var body: some View {
        HStack(spacing: 0) {
            ForEach(tools) { tool in
                toolButton(tool)
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 6)
        .background(
            Color(red: 0.07, green: 0.08, blue: 0.12)
                .overlay(alignment: .top) {
                    Rectangle()
                        .fill(Color.white.opacity(0.07))
                        .frame(height: 0.5)
                }
        )
    }

    private func toolButton(_ tool: EditorTool) -> some View {
        let isSelected = selectedTool == tool

        return Button {
            selectedTool = tool
            onToolSelected(tool)
        } label: {
            VStack(spacing: 3) {
                ZStack {
                    if isSelected {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(accent.opacity(0.15))
                            .frame(width: 36, height: 28)
                    }
                    Image(systemName: tool.icon)
                        .font(.system(size: 17, weight: isSelected ? .semibold : .medium))
                        .foregroundColor(isSelected ? accent : .white.opacity(0.55))
                }
                .frame(height: 28)

                Text(tool.title)
                    .font(.system(size: 9, weight: isSelected ? .semibold : .medium))
                    .foregroundColor(isSelected ? accent : .white.opacity(0.4))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 2)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(tool.title)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }
}

#Preview {
    VStack {
        Spacer()
        ToolbarUI(selectedTool: .constant(.media))
    }
    .background(Color.black)
    .preferredColorScheme(.dark)
}
