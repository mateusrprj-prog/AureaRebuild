import SwiftUI

/// Professional property inspector. Values are supplied as bindings by the host editor.
struct InspectorUI: View {
    let onDismiss: () -> Void
    @Binding var opacity: Double
    @Binding var scale: Double
    @Binding var rotation: Double
    @Binding var positionX: Double
    @Binding var positionY: Double

    @State private var selectedBlend = "Normal"

    private let accent = Color(red: 0.22, green: 0.84, blue: 0.42)

    init(
        onDismiss: @escaping () -> Void = {},
        opacity: Binding<Double>,
        scale: Binding<Double>,
        rotation: Binding<Double>,
        positionX: Binding<Double>,
        positionY: Binding<Double>
    ) {
        self.onDismiss = onDismiss
        _opacity = opacity
        _scale = scale
        _rotation = rotation
        _positionX = positionX
        _positionY = positionY
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    sectionHeader("Transform")
                    propertyRow(title: "Position X", value: $positionX, range: -500...500, unit: "px")
                    propertyRow(title: "Position Y", value: $positionY, range: -500...500, unit: "px")
                    propertyRow(title: "Scale", value: $scale, range: 0.1...3.0, unit: "×")
                    propertyRow(title: "Rotation", value: $rotation, range: -180...180, unit: "°")

                    thinDivider

                    sectionHeader("Appearance")
                    propertyRow(title: "Opacity", value: $opacity, range: 0...1, unit: "%")

                    thinDivider

                    sectionHeader("Blend Mode")
                    blendModeChips
                }
                .padding(.horizontal, 18)
                .padding(.top, 10)
                .padding(.bottom, 36)
            }
            .background(Color(white: 0.06))
            .navigationTitle("Inspector")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done", action: onDismiss)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(accent)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - Building blocks

    private func sectionHeader(_ title: String) -> some View {
        Text(title.uppercased())
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.white.opacity(0.35))
            .tracking(1.0)
    }

    private var thinDivider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.08))
            .frame(height: 0.5)
            .padding(.vertical, 2)
    }

    private func propertyRow(
        title: String,
        value: Binding<Double>,
        range: ClosedRange<Double>,
        unit: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.white.opacity(0.88))
                Spacer()
                Text(formatted(value.wrappedValue, unit: unit))
                    .font(.system(size: 12, weight: .semibold, design: .monospaced))
                    .foregroundColor(accent)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(Color.white.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
            }

            Slider(value: value, in: range)
                .tint(accent)
        }
    }

    private var blendModeChips: some View {
        let modes = ["Normal", "Add", "Multiply", "Screen", "Overlay"]
        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 7) {
                ForEach(modes, id: \.self) { mode in
                    let isOn = selectedBlend == mode
                    Button {
                        withAnimation(.easeInOut(duration: 0.12)) {
                            selectedBlend = mode
                        }
                    } label: {
                        Text(mode)
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(isOn ? .black : .white.opacity(0.75))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(isOn ? accent : Color.white.opacity(0.07))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func formatted(_ value: Double, unit: String) -> String {
        switch unit {
        case "%": return String(format: "%.0f%%", value * 100)
        case "×": return String(format: "%.2f×", value)
        case "°": return String(format: "%.0f°", value)
        default: return String(format: "%.0f%@", value, unit)
        }
    }
}
