import SwiftUI
import AVKit
import PhotosUI

struct EditorView: View {
    @EnvironmentObject private var model: EditorModel
    @EnvironmentObject private var mediaStore: MediaStore

    @State private var selectedVideo: PhotosPickerItem?
    @State private var showImportPicker = false
    @State private var player: AVPlayer?
    @State private var timeObserver: Any?
    @StateObject private var exporter = ExportService()

    var body: some View {
        EditorUI(
            projectName: model.projectName,
            currentTime: formatTime(model.currentTime),
            totalDuration: formatTime(model.duration),
            isPlaying: player == nil ? true : model.isPlaying,
            previewContent: AnyView(previewContent),
            timelineTracks: timelineTracks,
            playheadProgress: model.duration > 0 ? model.currentTime / model.duration : 0,
            onExport: { model.showExport = true },
            onInspector: { model.showInspector = true },
            onTogglePlay: togglePlayback,
            onSeek: seek(progress:),
            onToolSelected: handleTool(_:),
            onLayerSelected: selectLayer(id:)
        )
        .photosPicker(
            isPresented: $showImportPicker,
            selection: $selectedVideo,
            matching: .videos,
            photoLibrary: .shared()
        )
        .onChange(of: selectedVideo) { item in
            guard let item else { return }
            importVideo(item)
        }
        .onChange(of: model.isPlaying) { playing in
            if playing { player?.play() } else { player?.pause() }
        }
        .sheet(isPresented: $model.showInspector) {
            InspectorUI(
                onDismiss: { model.showInspector = false },
                opacity: modelBinding(\.opacity),
                scale: modelBinding(\.scale),
                rotation: modelBinding(\.rotation),
                positionX: modelBinding(\.positionX),
                positionY: modelBinding(\.positionY)
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $model.showExport) {
            ExportUI(
                projectName: model.projectName,
                estimatedSize: estimatedExportSize,
                isExporting: exporter.isExporting,
                progress: exporter.progress,
                message: exporter.message,
                error: exporter.error,
                onCancel: { model.showExport = false },
                onExport: { _ in startExport() }
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .onDisappear {
            removeTimeObserver()
            player?.pause()
        }
        .alert("Importação", isPresented: Binding(
            get: { mediaStore.errorMessage != nil },
            set: { if !$0 { mediaStore.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { mediaStore.errorMessage = nil }
        } message: {
            Text(mediaStore.errorMessage ?? "")
        }
    }

    private var previewContent: some View {
        ZStack {
            if let player {
                VideoPlayer(player: player)
                    .aspectRatio(contentMode: .fit)
                    .background(Color.black)
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "video.badge.plus")
                        .font(.system(size: 48, weight: .medium))
                        .foregroundColor(.white.opacity(0.75))
                        .symbolRenderingMode(.hierarchical)

                    Text("Nenhum vídeo")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)

                    Text("Adicione um vídeo para começar")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.white.opacity(0.4))

                    Button {
                        showImportPicker = true
                    } label: {
                        Label("Importar vídeo", systemImage: "photo.on.rectangle")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.black)
                            .padding(.horizontal, 18)
                            .padding(.vertical, 11)
                            .background(Color(red: 0.22, green: 0.84, blue: 0.42))
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 4)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var timelineTracks: [TimelineTrack] {
        model.layers.map { layer in
            TimelineTrack(
                id: layer.id.uuidString,
                name: layer.name,
                color: color(for: layer.type),
                height: layer.type == "media" ? 34 : 26,
                icon: icon(for: layer.type),
                isSelected: model.selectedLayerID == layer.id
            )
        }
    }

    private var estimatedExportSize: String {
        guard let url = mediaStore.importedURL,
              let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
              let size = attributes[.size] as? NSNumber else {
            return "Calculando…"
        }
        let megabytes = Double(truncating: size) / 1_048_576
        return String(format: "~%.1f MB", megabytes)
    }

    private func importVideo(_ item: PhotosPickerItem) {
        Task { @MainActor in
            do {
                guard let galleryVideo = try await item.loadTransferable(type: GalleryVideo.self) else {
                    throw MediaStore.ImportError.emptyData
                }
                guard let url = await mediaStore.importVideo(from: galleryVideo.url) else { return }

                player?.pause()
                removeTimeObserver()

                let newPlayer = AVPlayer(url: url)
                player = newPlayer
                model.setDuration(mediaStore.duration)
                model.addImportedVideo()
                model.currentTime = 0
                model.isPlaying = true
                addTimeObserver(to: newPlayer)
                newPlayer.play()
            } catch {
                mediaStore.errorMessage = error.localizedDescription
            }
        }
    }

    private func togglePlayback() {
        guard player != nil else {
            showImportPicker = true
            return
        }
        model.isPlaying.toggle()
    }

    private func seek(progress: Double) {
        let clamped = max(0, min(1, progress))
        let seconds = clamped * model.duration
        model.currentTime = seconds
        guard let player else { return }
        player.seek(
            to: CMTime(seconds: seconds, preferredTimescale: 600),
            toleranceBefore: .zero,
            toleranceAfter: .zero
        )
    }

    private func handleTool(_ tool: EditorTool) {
        switch tool {
        case .media:
            showImportPicker = true
        case .text:
            model.addLayer("Texto", type: "text")
        case .solid:
            model.addLayer("Sólido", type: "solid")
        case .adjustment:
            model.showInspector = true
        case .null:
            model.addLayer("Nulo", type: "null")
        case .shape:
            model.addLayer("Forma", type: "shape")
        case .audio:
            model.addLayer("Áudio", type: "audio")
        case .presets:
            model.showInspector = true
        case .element:
            model.addLayer("Elemento", type: "element")
        case .inspector:
            model.showInspector = true
        }
    }

    private func selectLayer(id: String) {
        guard let uuid = UUID(uuidString: id) else { return }
        model.selectedLayerID = uuid
    }

    private func startExport() {
        guard let url = mediaStore.importedURL else {
            exporter.error = "Importe um vídeo antes de exportar."
            return
        }
        Task { @MainActor in
            await exporter.exportVideo(from: url, duration: model.duration)
        }
    }

    private func addTimeObserver(to player: AVPlayer) {
        removeTimeObserver()
        let interval = CMTime(seconds: 0.05, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak model] time in
            let seconds = time.seconds
            guard seconds.isFinite else { return }
            Task { @MainActor [weak model] in
                guard let model else { return }
                model.currentTime = min(max(0, seconds), model.duration)
                if seconds >= model.duration - 0.05 {
                    model.isPlaying = false
                }
            }
        }
    }

    private func removeTimeObserver() {
        if let timeObserver {
            player?.removeTimeObserver(timeObserver)
            self.timeObserver = nil
        }
    }

    private func modelBinding(_ keyPath: WritableKeyPath<EditorModel.Layer, Double>) -> Binding<Double> {
        Binding(
            get: { model.selectedLayer?[keyPath: keyPath] ?? 0 },
            set: { newValue in
                model.updateSelected(recordHistory: false) { layer in
                    layer[keyPath: keyPath] = newValue
                }
            }
        )
    }

    private func formatTime(_ value: Double) -> String {
        let totalCs = Int((max(0, value) * 100).rounded())
        let m = totalCs / 6000
        let s = (totalCs % 6000) / 100
        let cs = totalCs % 100
        return String(format: "%02d:%02d.%02d", m, s, cs)
    }

    private func icon(for type: String) -> String {
        switch type {
        case "media": return "photo.on.rectangle"
        case "text": return "textformat"
        case "effect": return "wand.and.stars"
        case "audio": return "waveform"
        case "solid": return "square.fill"
        case "shape": return "circle"
        default: return "square.stack.3d.up"
        }
    }

    private func color(for type: String) -> Color {
        switch type {
        case "media": return Color.blue.opacity(0.85)
        case "text": return Color.cyan.opacity(0.85)
        case "effect": return Color.purple.opacity(0.85)
        case "audio": return Color.orange.opacity(0.9)
        case "solid": return Color.yellow.opacity(0.85)
        case "shape": return Color.pink.opacity(0.8)
        default: return Color.white.opacity(0.45)
        }
    }
}

#Preview {
    EditorView()
        .environmentObject(EditorModel())
        .environmentObject(MediaStore())
}
