import SwiftUI

struct ExportUI: View {
    let projectName: String
    let estimatedSize: String
    let isExporting: Bool
    let progress: Double
    let message: String?
    let error: String?
    var onCancel: () -> Void = {}
    var onExport: (ExportSettings) -> Void = { _ in }

    @State private var selectedResolution: ExportResolution = .p1080
    @State private var selectedFPS: ExportFPS = .fps30

    private let accent = Color(red: 0.22, green: 0.84, blue: 0.42)

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        sectionTitle("Resolution")
                        resolutionPicker

                        sectionTitle("Frame Rate (FPS)")
                        fpsPicker

                        sizeRow

                        if isExporting {
                            progressCard
                        }

                        if let message {
                            Label(message, systemImage: "checkmark.circle.fill")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(accent)
                        }

                        if let error {
                            Label(error, systemImage: "exclamationmark.triangle.fill")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(.orange)
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 16)
                    .padding(.bottom, 36)
                }

                bottomBar
            }
            .background(Color.black)
            .navigationTitle("Export Project")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: onCancel) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - Sections

    private func sectionTitle(_ text: String) -> some View {
        Text(text.uppercased())
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.white.opacity(0.35))
            .tracking(0.9)
    }

    private var resolutionPicker: some View {
        HStack(spacing: 8) {
            ForEach(ExportResolution.allCases) { res in
                let isOn = selectedResolution == res
                Button {
                    withAnimation(.easeInOut(duration: 0.12)) {
                        selectedResolution = res
                    }
                } label: {
                    Text(res.title)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(isOn ? .black : .white.opacity(0.8))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(isOn ? accent : Color.white.opacity(0.07))
                        .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(isExporting)
            }
        }
    }

    private var fpsPicker: some View {
        HStack(spacing: 8) {
            ForEach(ExportFPS.allCases) { fps in
                let isOn = selectedFPS == fps
                Button {
                    withAnimation(.easeInOut(duration: 0.12)) {
                        selectedFPS = fps
                    }
                } label: {
                    Text(fps.title)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(isOn ? .black : .white.opacity(0.8))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(isOn ? accent : Color.white.opacity(0.07))
                        .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(isExporting)
            }
        }
    }

    private var sizeRow: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Estimated File Size")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white.opacity(0.45))
                Text(estimatedSize)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
            }
            Spacer()
            Image(systemName: "arrow.down.circle.fill")
                .font(.system(size: 26))
                .foregroundColor(.white.opacity(0.25))
        }
        .padding(14)
        .background(Color.white.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
    }

    private var progressCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Exportando")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
                Spacer()
                Text("\(Int(progress * 100))%")
                    .font(.system(size: 12, weight: .semibold, design: .monospaced))
                    .foregroundColor(accent)
            }
            ProgressView(value: progress)
                .tint(accent)
        }
        .padding(14)
        .background(Color.white.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
    }

    private var bottomBar: some View {
        HStack(spacing: 10) {
            Button(action: onCancel) {
                Text("Cancel")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(isExporting)

            Button {
                onExport(ExportSettings(resolution: selectedResolution, fps: selectedFPS))
            } label: {
                Text(isExporting ? "Exporting…" : "Export Project")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(accent)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(isExporting)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(Color(white: 0.05))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color.white.opacity(0.06))
                .frame(height: 0.5)
        }
    }
}

// MARK: - Value types

enum ExportResolution: String, CaseIterable, Identifiable {
    case p720, p1080, p4k
    var id: String { rawValue }
    var title: String {
        switch self {
        case .p720: return "720p"
        case .p1080: return "1080p"
        case .p4k: return "4K"
        }
    }
}

enum ExportFPS: String, CaseIterable, Identifiable {
    case fps24, fps30, fps60
    var id: String { rawValue }
    var title: String {
        switch self {
        case .fps24: return "24 FPS"
        case .fps30: return "30 FPS"
        case .fps60: return "60 FPS"
        }
    }
}

struct ExportSettings {
    let resolution: ExportResolution
    let fps: ExportFPS
}
