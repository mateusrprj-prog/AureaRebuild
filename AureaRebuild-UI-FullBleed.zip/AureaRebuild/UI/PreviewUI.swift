import SwiftUI

/// Large preview canvas. Receives any content view from the caller.
struct PreviewUI: View {
    let content: AnyView
    let currentTime: String
    let isPlaying: Bool
    var onTogglePlay: () -> Void = {}

    var body: some View {
        ZStack {
            // Canvas background
            Color(red: 0.05, green: 0.06, blue: 0.09)

            // Subtle grid
            GridBackground()
                .opacity(0.4)

            // Caller-provided content (video / empty state)
            content
                .clipped()

            // Time badge
            VStack {
                HStack {
                    Spacer()
                    Text(currentTime)
                        .font(.system(size: 11, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.horizontal, 9)
                        .padding(.vertical, 4)
                        .background(
                            Capsule()
                                .fill(Color.black.opacity(0.6))
                                .overlay(
                                    Capsule()
                                        .stroke(Color.white.opacity(0.12), lineWidth: 0.5)
                                )
                        )
                        .padding(.top, 10)
                        .padding(.trailing, 12)
                }
                Spacer()
            }

            // Center play overlay only when paused and content is present
            if !isPlaying {
                Button(action: onTogglePlay) {
                    Image(systemName: "play.fill")
                        .font(.system(size: 26, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(16)
                        .background(
                            Circle()
                                .fill(Color.black.opacity(0.5))
                                .overlay(
                                    Circle()
                                        .stroke(Color.white.opacity(0.15), lineWidth: 1)
                                )
                        )
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Reproduzir")
                .transition(.opacity.combined(with: .scale(scale: 0.92)))
            }
        }
        .background(Color(red: 0.05, green: 0.06, blue: 0.09))
        .animation(.easeInOut(duration: 0.18), value: isPlaying)
    }
}

// MARK: - Subtle grid

private struct GridBackground: View {
    var body: some View {
        Canvas { context, size in
            let step: CGFloat = 28
            var path = Path()
            for x in stride(from: 0, through: size.width, by: step) {
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
            }
            for y in stride(from: 0, through: size.height, by: step) {
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(.white.opacity(0.05)), lineWidth: 0.5)
        }
    }
}

#Preview {
    PreviewUI(
        content: AnyView(
            ZStack {
                Color.black
                RoundedRectangle(cornerRadius: 12)
                    .fill(LinearGradient(
                        colors: [.blue.opacity(0.7), .purple.opacity(0.5)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 220, height: 160)
            }
        ),
        currentTime: "00:06.20",
        isPlaying: false
    )
    .frame(height: 320)
    .preferredColorScheme(.dark)
}
