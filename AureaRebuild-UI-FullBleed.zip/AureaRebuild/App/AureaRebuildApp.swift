import SwiftUI
import UIKit

@main
struct AureaRebuildApp: App {
    init() {
        forceBlackChrome()
    }

    @StateObject private var model = EditorModel()
    @StateObject private var mediaStore = MediaStore()

    var body: some Scene {
        WindowGroup {
            ZStack {
                // Absolute base layer — pure black, all edges
                Color.black
                    .ignoresSafeArea(.all)

                EditorView()
                    .environmentObject(model)
                    .environmentObject(mediaStore)

                // Keeps every UIWindow black after layout
                WindowBackgroundFixer()
                    .frame(width: 0, height: 0)
            }
            .preferredColorScheme(.dark)
            .background(Color.black.ignoresSafeArea(.all))
            .ignoresSafeArea(.all)
        }
    }

    private func forceBlackChrome() {
        let black = UIColor.black

        UIView.appearance().backgroundColor = black
        UIWindow.appearance().backgroundColor = black

        UINavigationBar.appearance().isTranslucent = false
        UINavigationBar.appearance().barTintColor = black
        UINavigationBar.appearance().backgroundColor = black
        UINavigationBar.appearance().barStyle = .black
        UINavigationBar.appearance().tintColor = .white
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.white
        ]

        UITabBar.appearance().barTintColor = black
        UITabBar.appearance().backgroundColor = black
        UITabBar.appearance().isTranslucent = false

        UITableView.appearance().backgroundColor = black
        UICollectionView.appearance().backgroundColor = black
        UIScrollView.appearance().backgroundColor = black

        UITextField.appearance().keyboardAppearance = .dark
        UITextView.appearance().backgroundColor = black
    }
}

/// Finds the key window after first layout and paints it (and its root VC) solid black.
/// This is what removes the light-gray safe-area letterboxing on device / ESign.
private struct WindowBackgroundFixer: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.isUserInteractionEnabled = false
        view.backgroundColor = .clear
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            guard let window = uiView.window ?? Self.keyWindow() else { return }
            window.backgroundColor = .black
            window.overrideUserInterfaceStyle = .dark
            window.rootViewController?.view.backgroundColor = .black
            window.rootViewController?.view.overrideUserInterfaceStyle = .dark

            // Also paint any sibling windows (keyboard, alerts, etc.)
            if let scene = window.windowScene {
                for w in scene.windows {
                    w.backgroundColor = .black
                    w.overrideUserInterfaceStyle = .dark
                }
            }
        }
    }

    private static func keyWindow() -> UIWindow? {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
    }
}
