# Aurea Rebuild 2.6.0

Atualização de estabilidade e mídia.

- Corrige importação de vídeo da galeria sem acoplar `MediaStore` ao `PhotosPickerItem`.
- Corrige acesso à biblioteca de fotos (`PHPhotoLibrary.shared()`).
- Corrige os bindings do Inspector e os sliders de opacidade, escala e rotação.
- Adiciona controles de início/fim da camada.
- Evita criar dezenas de entradas de undo ao arrastar sliders.
- Mantém o projeto independente e compatível com iOS 16.3+.

Build: 2600
