import Foundation
import AVFoundation
import UniformTypeIdentifiers

@MainActor
final class MediaStore: ObservableObject {
    @Published var importedURL: URL?
    @Published var duration: Double = 10
    @Published var isImporting = false
    @Published var errorMessage: String?

    func importVideo(data: Data, preferredExtension: String = "mov") async -> URL? {
        isImporting = true
        errorMessage = nil
        defer { isImporting = false }

        guard !data.isEmpty else {
            errorMessage = ImportError.emptyData.localizedDescription
            return nil
        }

        do {
            let safeExtension = preferredExtension.isEmpty ? "mov" : preferredExtension
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent("AureaMedia-\(UUID().uuidString).\(safeExtension)")
            try data.write(to: url, options: [.atomic])

            let asset = AVURLAsset(url: url)
            let loadedDuration = try await asset.load(.duration)
            let seconds = loadedDuration.seconds
            guard seconds.isFinite && seconds > 0 else {
                throw ImportError.invalidVideo
            }

            importedURL = url
            duration = max(0.1, seconds)
            return url
        } catch {
            errorMessage = "Não foi possível importar o vídeo: \(error.localizedDescription)"
            return nil
        }
    }

    func clear() {
        if let importedURL { try? FileManager.default.removeItem(at: importedURL) }
        importedURL = nil
        duration = 10
        errorMessage = nil
    }

    enum ImportError: LocalizedError {
        case emptyData
        case invalidVideo

        var errorDescription: String? {
            switch self {
            case .emptyData: return "O vídeo selecionado não retornou dados."
            case .invalidVideo: return "O arquivo selecionado não contém uma duração de vídeo válida."
            }
        }
    }
}
