import SwiftUI
import AVKit
import PhotosUI
import Photos
import UniformTypeIdentifiers

struct EditorView: View {
    @EnvironmentObject private var model: EditorModel
    @EnvironmentObject private var mediaStore: MediaStore
    @State private var selectedVideo: PhotosPickerItem?
    @State private var showAdd = false
    @State private var showDeleteConfirm = false
    @State private var player: AVPlayer?

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 0) {
                    HeaderBar()

                    PreviewCanvas(player: player)
                        .frame(height: min(max(proxy.size.height * 0.34, 250), 380))

                    PlaybackBar(player: player)

                    TimelineView()
                        .frame(maxHeight: .infinity)

                    BottomToolBar(
                        selectedVideo: $selectedVideo,
                        showAdd: $showAdd,
                        showDeleteConfirm: $showDeleteConfirm
                    )
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .background(Color.black)
                .ignoresSafeArea(.container, edges: [.bottom])
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
        .ignoresSafeArea()
        .onChange(of: selectedVideo) { item in
            guard let item else { return }
            Task {
                let movieType = item.supportedContentTypes.first(where: { $0.conforms(to: .movie) })
                    ?? UTType.movie
                let preferredExtension = movieType.preferredFilenameExtension ?? "mov"

                do {
                    let data = try await item.loadTransferable(type: Data.self)
                    if let data, let url = await mediaStore.importVideo(data: data, preferredExtension: preferredExtension) {
                        player?.pause()
                        player = AVPlayer(url: url)
                        model.setDuration(mediaStore.duration)
                        model.addImportedVideo()
                        model.currentTime = 0
                    }
                } catch {
                    mediaStore.errorMessage = "Não foi possível ler o vídeo selecionado: \(error.localizedDescription)"
                }
                selectedVideo = nil
            }
        }
        .onChange(of: mediaStore.importedURL) { url in
            if let url {
                player?.pause()
                player = AVPlayer(url: url)
            }
        }
        .sheet(isPresented: $model.showInspector) { InspectorView() }
        .sheet(isPresented: $model.showExport) { ExportView() }
        .sheet(isPresented: $showAdd) { AddLayerView() }
        .alert("Excluir camada?", isPresented: $showDeleteConfirm) {
            Button("Cancelar", role: .cancel) {}
            Button("Excluir", role: .destructive) { model.deleteSelected() }
        } message: {
            Text("A camada selecionada será removida da timeline.")
        }
        .alert("Erro ao importar", isPresented: Binding(
            get: { mediaStore.errorMessage != nil },
            set: { if !$0 { mediaStore.errorMessage = nil } }
        )) {
            Button("OK") { mediaStore.errorMessage = nil }
        } message: {
            Text(mediaStore.errorMessage ?? "Não foi possível importar o vídeo.")
        }
    }
}

private struct HeaderBar: View {
    @EnvironmentObject var model: EditorModel

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: "photo.stack.fill")
                .font(.system(size: 21, weight: .bold))
            Text("Aurea")
                .font(.system(size: 24, weight: .bold))
            Spacer()
            Button { model.undo() } label: { Image(systemName: "arrow.uturn.backward") }
                .disabled(model.history.isEmpty)
            Button { model.redo() } label: { Image(systemName: "arrow.uturn.forward") }
                .disabled(model.redoStack.isEmpty)
            Button { model.showInspector = true } label: { Image(systemName: "slider.horizontal.3") }
        }
        .font(.system(size: 21, weight: .semibold))
        .foregroundStyle(.white)
        .padding(.horizontal, 18)
        .frame(height: 62)
        .background(Color.black)
    }
}

private struct PreviewCanvas: View {
    @EnvironmentObject var model: EditorModel
    let player: AVPlayer?

    var body: some View {
        ZStack {
            if let player {
                VideoPlayer(player: player)
                    .background(Color.black)
                    .onDisappear { player.pause() }
            } else {
                EmptyPreview()
            }

            VStack {
                HStack {
                    Spacer()
                    Text(model.selectedLayer?.name ?? "AUTO")
                        .font(.caption.bold())
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(.black.opacity(0.7))
                        .clipShape(Capsule())
                }
                Spacer()
            }
            .padding(10)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
        .clipped()
    }
}

private struct EmptyPreview: View {
    var body: some View {
        ZStack {
            Color.black
            ForEach(0..<70, id: \.self) { i in
                Circle()
                    .fill(.white.opacity(0.25 + Double(i % 5) * 0.08))
                    .frame(width: CGFloat((i % 4) + 1) * 2.2)
                    .offset(
                        x: CGFloat((i * 71) % 360) - 180,
                        y: CGFloat((i * 47) % 240) - 120
                    )
            }
            VStack(spacing: 14) {
                Image(systemName: "film.stack")
                    .font(.system(size: 56, weight: .semibold))
                Text("Importe um vídeo para começar")
                    .font(.title3.bold())
                Text("Toque em Vídeo na barra inferior e escolha um vídeo da galeria.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
            .foregroundStyle(.white)
        }
    }
}

private struct PlaybackBar: View {
    @EnvironmentObject var model: EditorModel
    let player: AVPlayer?

    var body: some View {
        VStack(spacing: 6) {
            HStack(spacing: 8) {
                Text(time(model.currentTime))
                Slider(value: $model.currentTime, in: 0...max(model.duration, 0.1))
                    .tint(.blue)
                Text(time(model.duration))
            }
            .font(.caption.monospacedDigit())
            .foregroundStyle(.white)

            HStack(spacing: 30) {
                Button { seek(0) } label: { Image(systemName: "backward.end.fill") }
                Button { seek(max(0, model.currentTime - 0.1)) } label: { Image(systemName: "backward.frame.fill") }
                Button {
                    if model.isPlaying {
                        player?.pause()
                    } else {
                        player?.play()
                    }
                    model.isPlaying.toggle()
                } label: {
                    Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                        .font(.title3)
                }
                Button { seek(min(model.duration, model.currentTime + 0.1)) } label: { Image(systemName: "forward.frame.fill") }
                Button { seek(model.duration) } label: { Image(systemName: "forward.end.fill") }
            }
            .foregroundStyle(.white)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(Color(red: 0.035, green: 0.035, blue: 0.04))
    }

    private func seek(_ value: Double) {
        model.currentTime = value
        player?.seek(to: CMTime(seconds: value, preferredTimescale: 600))
    }

    private func time(_ value: Double) -> String {
        String(format: "%02d:%05.2f", Int(value) / 60, value.truncatingRemainder(dividingBy: 60))
    }
}

private struct TimelineView: View {
    @EnvironmentObject var model: EditorModel

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Timeline").font(.title3.bold())
                Text("1.00x").foregroundStyle(.secondary)
                Spacer()
                Image(systemName: "number")
                Text("\(Int(model.duration.rounded()))s")
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 9)

            ScrollView(.horizontal, showsIndicators: false) {
                VStack(spacing: 6) {
                    HStack(spacing: 0) {
                        ForEach(0...10, id: \.self) { i in
                            Text("\(i)")
                                .frame(width: 72)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }

                    ForEach(model.layers) { layer in
                        HStack(spacing: 0) {
                            Button {
                                model.toggleVisibility(layer)
                            } label: {
                                Image(systemName: layer.visible ? "eye.fill" : "eye.slash")
                                    .frame(width: 36)
                                    .foregroundStyle(.white)
                            }

                            Button {
                                model.selectedLayerID = layer.id
                            } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: icon(for: layer.type))
                                    Text(layer.name).bold()
                                    Spacer()
                                    if layer.id == model.selectedLayerID {
                                        Image(systemName: "diamond.fill")
                                            .font(.caption2)
                                    }
                                }
                                .padding(.horizontal, 10)
                            }
                            .frame(width: 590, height: 38, alignment: .leading)
                            .background(layer.id == model.selectedLayerID ? Color.blue.opacity(0.85) : trackColor(layer.type))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                        }
                    }
                    Spacer(minLength: 4)
                }
                .frame(minWidth: 760, alignment: .leading)
            }
        }
        .background(Color(red: 0.045, green: 0.055, blue: 0.08))
    }

    private func icon(for type: String) -> String {
        switch type {
        case "media": return "photo.on.rectangle"
        case "text": return "textformat"
        case "effect": return "wand.and.stars"
        case "solid": return "square.fill"
        default: return "circle"
        }
    }

    private func trackColor(_ type: String) -> Color {
        switch type {
        case "effect": return .purple.opacity(0.55)
        case "media": return .gray.opacity(0.48)
        case "text": return .blue.opacity(0.48)
        default: return .orange.opacity(0.55)
        }
    }
}

private struct BottomToolBar: View {
    @EnvironmentObject var model: EditorModel
    @EnvironmentObject var mediaStore: MediaStore
    @Binding var selectedVideo: PhotosPickerItem?
    @Binding var showAdd: Bool
    @Binding var showDeleteConfirm: Bool

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                PhotosPicker(selection: $selectedVideo, matching: .videos, photoLibrary: PHPhotoLibrary.shared()) {
                    ToolContent(icon: "video.fill", title: mediaStore.isImporting ? "Importando" : "Vídeo")
                }
                .disabled(mediaStore.isImporting)

                ToolButton("textformat", "Texto") { model.addLayer("Texto", type: "text") }
                ToolButton("square.fill", "Sólido") { model.addLayer("Sólido", type: "solid") }
                ToolButton("circle", "Forma") { model.addLayer("Forma", type: "shape") }
                ToolButton("plus.square.on.square", "Duplicar") { model.duplicateSelected() }
                ToolButton("wand.and.stars", "Efeitos") { model.showInspector = true }
                ToolButton("slider.horizontal.3", "Inspetor") { model.showInspector = true }
                ToolButton("trash", "Excluir") { showDeleteConfirm = true }
                ToolButton("square.and.arrow.up", "Exportar") { model.showExport = true }
                ToolButton("plus", "Adicionar") { showAdd = true }
            }
            .padding(8)
        }
        .frame(height: 80)
        .background(Color.black)
    }

    @ViewBuilder private func ToolButton(_ icon: String, _ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            ToolContent(icon: icon, title: title)
        }
    }
}

private struct ToolContent: View {
    let icon: String
    let title: String

    var body: some View {
        VStack(spacing: 5) {
            Image(systemName: icon).font(.title3)
            Text(title).font(.caption2.bold()).lineLimit(1)
        }
        .frame(width: 78, height: 64)
        .foregroundStyle(.white)
        .background(Color.white.opacity(0.055))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

private struct AddLayerView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var model: EditorModel

    var body: some View {
        NavigationStack {
            List {
                ForEach([("Forma", "shape"), ("Texto", "text"), ("Sólido", "solid"), ("Particular", "effect")], id: \.0) { item in
                    Button(item.0) {
                        model.addLayer(item.0, type: item.1)
                        dismiss()
                    }
                }
            }
            .navigationTitle("Adicionar camada")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Fechar") { dismiss() }
                }
            }
        }
    }
}

#Preview {
    EditorView()
        .environmentObject(EditorModel())
        .environmentObject(MediaStore())
}
