import Foundation
import AVFoundation
import Photos

@MainActor
final class ExportService: ObservableObject {
    @Published var isExporting = false
    @Published var progress: Double = 0
    @Published var message: String?
    @Published var error: String?

    func exportVideo(from sourceURL: URL, duration: Double) {
        guard !isExporting else { return }
        isExporting = true
        progress = 0
        message = nil
        error = nil

        let asset = AVAsset(url: sourceURL)
        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("AureaExport-\(UUID().uuidString).mp4")

        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            isExporting = false
            error = "Este vídeo não pode ser exportado neste dispositivo."
            return
        }

        session.outputURL = outputURL
        session.outputFileType = .mp4
        let sourceDuration = asset.duration.seconds
        let end = min(max(duration, 0.1), sourceDuration.isFinite ? sourceDuration : duration)
        session.timeRange = CMTimeRange(start: .zero, duration: CMTime(seconds: end, preferredTimescale: 600))

        Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { [weak self, weak session] timer in
            guard let self, let session else {
                timer.invalidate()
                return
            }
            Task { @MainActor in
                self.progress = Double(session.progress)
                if session.status != .exporting {
                    timer.invalidate()
                }
            }
        }

        session.exportAsynchronously { [weak self] in
            Task { @MainActor in
                guard let self else { return }
                switch session.status {
                case .completed:
                    self.saveToPhotos(outputURL: outputURL)
                case .failed, .cancelled:
                    self.isExporting = false
                    self.error = session.error?.localizedDescription ?? "A exportação foi cancelada."
                default:
                    self.isExporting = false
                }
            }
        }
    }

    private func saveToPhotos(outputURL: URL) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { [weak self] status in
            guard let self else { return }
            Task { @MainActor in
                guard status == .authorized || status == .limited else {
                    self.isExporting = false
                    self.error = "Permita que o Aurea salve vídeos na galeria."
                    return
                }

                let library = PHPhotoLibrary.shared()
                library.performChanges({
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: outputURL)
                }) { success, error in
                    Task { @MainActor in
                        self.isExporting = false
                        self.progress = 1
                        self.message = success ? "Vídeo salvo na galeria." : nil
                        self.error = success ? nil : (error?.localizedDescription ?? "Não foi possível salvar o vídeo.")
                        try? FileManager.default.removeItem(at: outputURL)
                    }
                }
            }
        }
    }
}
