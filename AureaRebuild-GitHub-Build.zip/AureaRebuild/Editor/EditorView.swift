import SwiftUI
import PhotosUI

public struct EditorView: View {
    @StateObject private var model=EditorModel()
    @StateObject private var media=MediaStore()
    @State private var showExporter=false
    public init(){}
    public var body: some View {
        NavigationStack {
            VStack(spacing:0) {
                PreviewPane(model:model).frame(maxHeight:.infinity)
                Toolbar(model:model,media:media)
                TimelineView(model:model)
                Inspector(model:model)
            }
            .navigationTitle(model.composition.name)
            .toolbar { ToolbarItemGroup(placement:.topBarTrailing) { Button("Undo"){model.undo()}.disabled(model.undoStack.isEmpty); Button("Redo"){model.redo()}.disabled(model.redoStack.isEmpty); Button("Export"){showExporter=true} } }
            .sheet(isPresented:$showExporter){ExportView(model:model)}
        }
    }
}

private struct PreviewPane:View { @ObservedObject var model:EditorModel; var body:some View { ZStack{ Color.black; VStack{ Text("PREVIEW").foregroundStyle(.white.opacity(.35)); Text(String(format:"%02d:%02d",Int(model.currentTime)/60,Int(model.currentTime).truncatingRemainder(dividingBy:60))).foregroundStyle(.white.opacity(.6)) } }.aspectRatio(CGFloat(model.composition.width)/CGFloat(model.composition.height),contentMode:.fit).padding(12) } }

private struct Toolbar:View { @ObservedObject var model:EditorModel; @ObservedObject var media:MediaStore; @State private var photoItems:[PhotosPickerItem]=[]; var body:some View { ScrollView(.horizontal,showsIndicators:false){HStack{ PhotosPicker(selection:$photoItems,maxSelectionCount:10,matching:.any){Label("Importar",systemImage:"plus")}.onChange(of:photoItems){_,items in media.selectedItems=items; media.importItems()}; Button("Texto"){model.addLayer(Layer(name:"Texto",kind:.text))}; Button("Sólido"){model.addLayer(Layer(name:"Sólido",kind:.solid))}; Button("Forma"){model.addLayer(Layer(name:"Forma",kind:.shape))}; Button("Duplicar"){model.duplicateSelected()}; Button("Split"){model.splitSelected()}; Button("Excluir"){model.deleteSelected()} }.padding(10)} }

private struct TimelineView:View { @ObservedObject var model:EditorModel; var body:some View { VStack(alignment:.leading){ HStack{Text("Timeline").font(.headline); Spacer(); Button(model.isPlaying ? "Pause":"Play"){model.isPlaying.toggle()} }; ScrollView(.horizontal){ ZStack(alignment:.topLeading){ Rectangle().fill(.gray.opacity(.12)).frame(width:max(600,CGFloat(model.composition.duration)*70),height:CGFloat(max(1,model.composition.layers.count))*46+10); VStack(spacing:4){ForEach(model.composition.layers){layer in HStack{Text(layer.name).frame(width:100,alignment:.leading).lineLimit(1); RoundedRectangle(cornerRadius:5).fill(layer.id==model.selectedLayerID ? .blue.opacity(.65):.gray.opacity(.45)).frame(width:max(30,CGFloat(layer.duration*70)),height:36).overlay(Text(layer.kind.rawValue).font(.caption2)); Spacer()}.contentShape(Rectangle()).onTapGesture{model.selectedLayerID=layer.id}}}}.padding(.vertical,5) } }.padding(10).frame(height:180) } }

private struct Inspector:View { @ObservedObject var model:EditorModel; var body:some View { if let id=model.selectedLayerID, let layer=model.composition.layers.first(where:{$0.id==id}) { VStack(alignment:.leading){Text("Inspector").font(.headline); HStack{Text(layer.name);Spacer();Text(layer.kind.rawValue)}; HStack{Text("Opacity");Slider(value:Binding(get:{layer.opacity.value},set:{v in model.transact{$0.layers.firstIndex(where:{$0.id==id}).map{$0.layers[$0].opacity.value=v}}}),in:0...1)}; HStack{Text("Scale");Slider(value:Binding(get:{layer.scale.value},set:{v in model.transact{$0.layers.firstIndex(where:{$0.id==id}).map{$0.layers[$0].scale.value=v}}}),in:0.1...4)}; HStack{Text("Rotation");Slider(value:Binding(get:{layer.rotation.value},set:{v in model.transact{$0.layers.firstIndex(where:{$0.id==id}).map{$0.layers[$0].rotation.value=v}}}),in:-180...180)} }.padding(10) } else { Text("Selecione uma camada").foregroundStyle(.secondary).padding(12) } } }

private struct ExportView:View { @ObservedObject var model:EditorModel; @Environment(\.dismiss) private var dismiss; @State private var progress=0.0; @State private var exporting=false; var body:some View { VStack(spacing:20){Text("Exportar").font(.title2);ProgressView(value:progress);Text("\(Int(progress*100))%");Button("Iniciar"){exporting=true;Task{let url=FileManager.default.temporaryDirectory.appendingPathComponent("Aurea-Export-\(UUID().uuidString).mp4");try? await CompositionExporter().exportVideo(composition:model.composition,to:url){p in Task{@MainActor in progress=p }}; exporting=false}}.disabled(exporting);Button("Fechar"){dismiss()} }.padding(30) } }
