import Foundation
import SwiftUI
import Combine
import AVFoundation

enum LayerKind: String, Codable, CaseIterable {
    case video, image, text, solid, shape
}

struct Keyframe: Identifiable, Codable, Equatable {
    var id = UUID()
    var time: Double
    var value: Double
}

struct EditorLayer: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var kind: LayerKind
    var opacity: Double = 1
    var scale: Double = 1
    var rotation: Double = 0
    var positionX: Double = 0
    var positionY: Double = 0
    var colorHex: String = "#FFFFFF"
    var sourcePath: String?
    var startTime: Double = 0
    var endTime: Double = 10
    var keyframes: [String: [Keyframe]] = [:]
}

struct Composition: Identifiable, Codable, Equatable {
    var id = UUID()
    var name = "Novo Projeto"
    var width = 1080
    var height = 1920
    var duration = 10.0
    var frameRate = 30
    var layers: [EditorLayer] = []
}

@MainActor
final class EditorModel: ObservableObject {
    @Published var composition = Composition()
    @Published var selectedID: UUID?
    @Published var currentTime: Double = 0
    @Published var videoURL: URL?
    @Published var isExporting = false
    @Published var exportProgress: Double = 0
    @Published var lastExportURL: URL?
    @Published var trimStart: Double = 0
    @Published var trimEnd: Double = 10
    @Published var brightness: Double = 0
    @Published var contrast: Double = 1
    @Published var saturation: Double = 1
    @Published var blur: Double = 0
    @Published var volume: Double = 1
    @Published var timelineZoom: Double = 1
    @Published var snapEnabled = true
    @Published var showGrid = false
    @Published var undoStack: [Composition] = []
    @Published var redoStack: [Composition] = []

    var selectedLayer: EditorLayer? {
        guard let selectedID else { return nil }
        return composition.layers.first { $0.id == selectedID }
    }

    var duration: Double { max(0.1, composition.duration) }

    func add(_ layer: EditorLayer) {
        saveUndo()
        composition.layers.append(layer)
        selectedID = layer.id
    }

    func importVideo(url: URL) {
        saveUndo()
        videoURL = url
        let duration = max(0.1, AVAsset(url: url).duration.seconds)
        composition.duration = duration
        trimStart = 0
        trimEnd = duration
        var layer = EditorLayer(name: "Vídeo", kind: .video, sourcePath: url.path)
        layer.endTime = duration
        composition.layers.removeAll()
        composition.layers.append(layer)
        selectedID = layer.id
        currentTime = 0
    }

    func deleteSelected() {
        guard let id = selectedID else { return }
        saveUndo()
        composition.layers.removeAll { $0.id == id }
        if composition.layers.isEmpty { videoURL = nil }
        selectedID = composition.layers.last?.id
    }

    func duplicateSelected() {
        guard let layer = selectedLayer else { return }
        saveUndo()
        var copy = layer
        copy.id = UUID()
        copy.name += " Copy"
        copy.positionY += 4
        composition.layers.append(copy)
        selectedID = copy.id
    }

    func splitSelected() {
        guard let layer = selectedLayer else { return }
        let cut = min(max(currentTime, layer.startTime + 0.05), layer.endTime - 0.05)
        guard cut > layer.startTime && cut < layer.endTime else { return }
        saveUndo()
        var left = layer
        left.id = UUID()
        left.name = layer.name + " A"
        left.endTime = cut
        var right = layer
        right.id = UUID()
        right.name = layer.name + " B"
        right.startTime = cut
        if let index = composition.layers.firstIndex(where: { $0.id == layer.id }) {
            composition.layers.remove(at: index)
            composition.layers.insert(right, at: index)
            composition.layers.insert(left, at: index)
        }
        selectedID = left.id
    }

    func addText() {
        var layer = EditorLayer(name: "Texto", kind: .text)
        layer.startTime = currentTime
        layer.endTime = min(duration, currentTime + 3)
        add(layer)
    }

    func addSolid() {
        var layer = EditorLayer(name: "Sólido", kind: .solid, colorHex: "#222222")
        layer.startTime = 0; layer.endTime = duration
        add(layer)
    }

    func addShape() {
        var layer = EditorLayer(name: "Forma", kind: .shape)
        layer.startTime = currentTime
        layer.endTime = min(duration, currentTime + 3)
        add(layer)
    }

    func updateSelected(opacity: Double? = nil, scale: Double? = nil, rotation: Double? = nil, x: Double? = nil, y: Double? = nil) {
        guard let id = selectedID, let i = composition.layers.firstIndex(where: { $0.id == id }) else { return }
        if let opacity { composition.layers[i].opacity = opacity }
        if let scale { composition.layers[i].scale = scale }
        if let rotation { composition.layers[i].rotation = rotation }
        if let x { composition.layers[i].positionX = x }
        if let y { composition.layers[i].positionY = y }
    }

    func addKeyframe(property: String, value: Double) {
        guard let id = selectedID, let i = composition.layers.firstIndex(where: { $0.id == id }) else { return }
        saveUndo()
        composition.layers[i].keyframes[property, default: []].append(Keyframe(time: currentTime, value: value))
        composition.layers[i].keyframes[property]?.sort { $0.time < $1.time }
    }

    func undo() {
        guard let previous = undoStack.popLast() else { return }
        redoStack.append(composition)
        composition = previous
        selectedID = composition.layers.last?.id
    }

    func redo() {
        guard let next = redoStack.popLast() else { return }
        undoStack.append(composition)
        composition = next
        selectedID = composition.layers.last?.id
    }

    func resetEffects() {
        brightness = 0; contrast = 1; saturation = 1; blur = 0
    }

    func setAspect(_ width: Int, _ height: Int) {
        saveUndo()
        composition.width = width
        composition.height = height
    }

    private func saveUndo() {
        undoStack.append(composition)
        if undoStack.count > 60 { undoStack.removeFirst() }
        redoStack.removeAll()
    }
}
