import SwiftUI
import AVKit
import AVFoundation

struct VideoPreview: View {
    let url: URL?
    @Binding var currentTime: Double
    @Binding var isPlaying: Bool
    let duration: Double
    let showGrid: Bool
    @State private var player = AVPlayer()
    @State private var timer: Timer?

    var body: some View {
        ZStack {
            Color.black
            if let url {
                VideoPlayer(player: player)
                    .onAppear {
                        player.replaceCurrentItem(with: AVPlayerItem(url: url))
                        seek(currentTime)
                        startTimer()
                    }
                    .onDisappear { timer?.invalidate(); timer = nil }
                    .onChange(of: url) { newURL in
                        player.replaceCurrentItem(with: AVPlayerItem(url: newURL))
                        seek(0)
                    }
                    .onChange(of: isPlaying) { value in
                        if value { player.play() } else { player.pause() }
                    }
                    .onChange(of: currentTime) { value in
                        let p = player.currentTime().seconds
                        if abs(p - value) > 0.25 { seek(value) }
                    }
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "film.stack")
                        .font(.system(size: 54))
                    Text("Importe um vídeo para começar")
                        .font(.headline)
                    Text("Aurea V3")
                        .foregroundStyle(.secondary)
                }
                .foregroundStyle(.white)
            }

            if showGrid {
                GeometryReader { geo in
                    Path { path in
                        let w = geo.size.width, h = geo.size.height
                        path.move(to: CGPoint(x: w/3, y: 0)); path.addLine(to: CGPoint(x: w/3, y: h))
                        path.move(to: CGPoint(x: 2*w/3, y: 0)); path.addLine(to: CGPoint(x: 2*w/3, y: h))
                        path.move(to: CGPoint(x: 0, y: h/3)); path.addLine(to: CGPoint(x: w, y: h/3))
                        path.move(to: CGPoint(x: 0, y: 2*h/3)); path.addLine(to: CGPoint(x: w, y: 2*h/3))
                    }
                    .stroke(.white.opacity(0.25), lineWidth: 1)
                }
            }

            VStack {
                Spacer()
                HStack(spacing: 14) {
                    Button {
                        isPlaying.toggle()
                    } label: {
                        Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                            .font(.title3.bold())
                            .frame(width: 44, height: 44)
                            .background(.black.opacity(0.72))
                            .clipShape(Circle())
                    }
                    Text(timeString(currentTime) + " / " + timeString(duration))
                        .font(.caption.monospacedDigit())
                    Spacer()
                    Button { seek(0); isPlaying = false } label: {
                        Image(systemName: "arrow.counterclockwise")
                    }
                }
                .foregroundStyle(.white)
                .padding(12)
                .background(.black.opacity(0.55))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            let value = player.currentTime().seconds
            guard value.isFinite else { return }
            DispatchQueue.main.async {
                currentTime = min(max(0, value), duration)
                if value >= duration - 0.03 { isPlaying = false }
            }
        }
    }

    private func seek(_ value: Double) {
        let safe = min(max(0, value), max(0, duration))
        player.seek(to: CMTime(seconds: safe, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
    }

    private func timeString(_ value: Double) -> String {
        let total = max(0, Int(value.rounded(.down)))
        return String(format: "%02d:%02d", total / 60, total % 60)
    }
}
