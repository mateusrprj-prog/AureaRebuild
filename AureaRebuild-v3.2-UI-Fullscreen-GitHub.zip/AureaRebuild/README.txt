AureaRebuild V3.0

Grande atualização de interface e base de edição.

Inclui:
- preview grande com controles de reprodução e scrub
- timeline com régua, faixas, seleção, zoom e playhead
- ferramentas em duas linhas, maiores e mais confortáveis
- inspector de transformação e efeitos
- keyframes armazenados para escala, rotação e posição X
- configurações de canvas 9:16, 16:9 e 1:1
- grid de composição e snapping
- undo/redo
- importação de vídeo via PHPicker (iOS 16)
- exportação MP4 com corte, áudio, brilho, contraste, saturação e blur

Próximas etapas: composição real de camadas, imagens/texto sobre vídeo, transições, máscaras, partículas e 3D/Metal.
