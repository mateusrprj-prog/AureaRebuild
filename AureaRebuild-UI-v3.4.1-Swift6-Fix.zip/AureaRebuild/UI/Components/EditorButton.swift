import SwiftUI

/// Reusable toolbar / tool chip button used across the editor.
@MainActor
struct EditorButton: View {
    let icon: String
    let title: String
    var isSelected: Bool = false
    var accent: Color = Color(red: 0.35, green: 0.55, blue: 1.0)
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .medium))
                Text(title)
                    .font(.system(size: 10, weight: .semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .frame(width: 68, height: 58)
            .foregroundStyle(isSelected ? accent : .white.opacity(0.92))
            .background(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(isSelected ? accent.opacity(0.18) : Color.white.opacity(0.06))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(isSelected ? accent.opacity(0.45) : Color.white.opacity(0.06), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

/// Compact icon-only control for playback / header actions.
@MainActor
struct EditorIconButton: View {
    let systemName: String
    var size: CGFloat = 18
    var disabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size, weight: .semibold))
                .foregroundStyle(disabled ? Color.white.opacity(0.28) : Color.white.opacity(0.95))
                .frame(width: 36, height: 36)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(disabled)
    }
}
