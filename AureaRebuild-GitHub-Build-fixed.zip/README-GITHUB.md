# AureaRebuild — GitHub build

This project is configured to build an unsigned iOS IPA with GitHub Actions on macOS.

Use **Actions → Build unsigned IPA → Run workflow**. The IPA is uploaded as a workflow artifact.

The resulting IPA is unsigned and must be signed with a certificate/profile compatible with the installation method you use on your iPhone.
