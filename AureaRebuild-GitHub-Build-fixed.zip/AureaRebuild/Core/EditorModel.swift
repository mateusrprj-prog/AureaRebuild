import Combine
import Foundation
import CoreGraphics

public enum LayerKind: String, Codable, CaseIterable { case video, image, text, solid, audio, shape }
public enum BlendMode: String, Codable, CaseIterable { case normal, multiply, screen, overlay, darken, lighten, difference }
public enum KeyframeCurve: String, Codable, CaseIterable { case linear, easeIn, easeOut, easeInOut }

public struct Keyframe: Identifiable, Codable, Equatable {
    public var id = UUID(); public var time: Double; public var value: Double; public var curve: KeyframeCurve = .linear
    public init(time: Double, value: Double, curve: KeyframeCurve = .linear) { self.time = time; self.value = value; self.curve = curve }
}

public struct AnimatableDouble: Codable, Equatable {
    public var value: Double; public var keyframes: [Keyframe] = []
    public init(_ value: Double) { self.value = value }
    public func value(at time: Double) -> Double {
        guard !keyframes.isEmpty else { return value }
        let sorted = keyframes.sorted { $0.time < $1.time }
        if time <= sorted[0].time { return sorted[0].value }
        if time >= sorted.last!.time { return sorted.last!.value }
        for pair in zip(sorted, sorted.dropFirst()) {
            let a = pair.0, b = pair.1; guard time <= b.time else { continue }
            let raw = (time - a.time) / max(0.0001, b.time - a.time)
            let t: Double
            switch a.curve { case .linear: t = raw; case .easeIn: t = raw * raw; case .easeOut: t = 1 - pow(1 - raw, 2); case .easeInOut: t = raw < 0.5 ? 2*raw*raw : 1-pow(-2*raw+2,2)/2 }
            return a.value + (b.value - a.value) * t
        }
        return value
    }
}

public struct Transform: Codable, Equatable { public var x=0.0; public var y=0.0; public var scaleX=1.0; public var scaleY=1.0; public var rotation=0.0; public var opacity=1.0 }
public struct Effect: Identifiable, Codable, Equatable { public var id=UUID(); public var name:String; public var intensity=1.0; public var enabled=true; public init(name:String,intensity:Double=1){self.name=name;self.intensity=intensity} }

public struct Layer: Identifiable, Codable, Equatable {
    public var id=UUID(); public var name:String; public var kind:LayerKind; public var start:Double=0; public var duration:Double=5
    public var assetPath:String?; public var text:String=""; public var colorHex:String="#FFFFFF"; public var transform=Transform(); public var blendMode:BlendMode = .normal; public var effects:[Effect]=[]
    public var opacity=AnimatableDouble(1); public var x=AnimatableDouble(0); public var y=AnimatableDouble(0); public var scale=AnimatableDouble(1); public var rotation=AnimatableDouble(0)
    public init(name:String, kind:LayerKind) { self.name=name; self.kind=kind }
}

public struct Composition: Identifiable, Codable, Equatable { public var id=UUID(); public var name="Projeto"; public var width=1080; public var height=1920; public var fps=30.0; public var duration=10.0; public var backgroundHex="#000000"; public var layers:[Layer]=[] }

@MainActor public final class EditorModel: ObservableObject {
    @Published public var composition: Composition
    @Published public var selectedLayerID: UUID?
    @Published public var currentTime=0.0
    @Published public var isPlaying=false
    @Published public private(set) var undoStack:[Composition]=[]
    @Published public private(set) var redoStack:[Composition]=[]
    public init(composition:Composition = Composition()) { self.composition=composition }
    public var selectedLayer: Layer? { composition.layers.first { $0.id == selectedLayerID } }
    public func transact(_ change: (inout Composition)->Void) { undoStack.append(composition); redoStack.removeAll(); change(&composition) }
    public func undo(){ guard let previous=undoStack.popLast() else{return}; redoStack.append(composition); composition=previous }
    public func redo(){ guard let next=redoStack.popLast() else{return}; undoStack.append(composition); composition=next }
    public func addLayer(_ layer:Layer){ transact{$0.layers.append(layer)}; selectedLayerID=layer.id }
    public func deleteSelected(){ guard let id=selectedLayerID else{return}; transact{$0.layers.removeAll{$0.id==id}}; selectedLayerID=nil }
    public func duplicateSelected(){ guard let id=selectedLayerID, let layer=composition.layers.first(where:{$0.id==id}) else{return}; var copy=layer; copy.id=UUID(); copy.name += " Copy"; copy.start += 0.25; transact{$0.layers.append(copy)}; selectedLayerID=copy.id }
    public func splitSelected(){ guard let id=selectedLayerID, let index=composition.layers.firstIndex(where:{$0.id==id}) else{return}; let layer=composition.layers[index]; let cut=currentTime; guard cut>layer.start+0.05 && cut<layer.start+layer.duration-0.05 else{return}; var right=layer; right.id=UUID(); right.name += " 2"; right.start=cut; right.duration=layer.start+layer.duration-cut; transact{ $0.layers[index].duration=cut-layer.start; $0.layers.append(right) } }
    public func trimSelected(to start:Double?, end:Double?){ guard let id=selectedLayerID else{return}; transact{ c in guard let i=c.layers.firstIndex(where:{$0.id==id}) else{return}; if let s=start { let delta=s-c.layers[i].start; c.layers[i].start=s; c.layers[i].duration=max(0.05,c.layers[i].duration-delta) }; if let e=end { c.layers[i].duration=max(0.05,e-c.layers[i].start) } } }
}
