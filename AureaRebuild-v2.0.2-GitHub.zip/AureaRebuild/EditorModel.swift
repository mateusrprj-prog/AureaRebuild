import Foundation
import SwiftUI
import AVFoundation

enum LayerKind: String, Codable, CaseIterable {
    case video, image, text, solid, shape
}

struct EditorLayer: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var kind: LayerKind
    var opacity: Double = 1
    var scale: Double = 1
    var rotation: Double = 0
    var positionX: Double = 0
    var positionY: Double = 0
    var colorHex: String = "#FFFFFF"
    var sourcePath: String?
}

struct Composition: Identifiable, Codable, Equatable {
    var id = UUID()
    var name = "Novo Projeto"
    var width = 1080
    var height = 1920
    var duration = 10.0
    var layers: [EditorLayer] = []
}

@MainActor
final class EditorModel: ObservableObject {
    @Published var composition = Composition()
    @Published var selectedID: UUID?
    @Published var currentTime: Double = 0
    @Published var videoURL: URL?
    @Published var isExporting = false
    @Published var exportProgress: Double = 0
    @Published var lastExportURL: URL?
    @Published var trimStart: Double = 0
    @Published var trimEnd: Double = 10
    @Published var brightness: Double = 0
    @Published var contrast: Double = 1
    @Published var saturation: Double = 1
    @Published var blur: Double = 0
    @Published var volume: Double = 1
    @Published private(set) var undoStack: [Composition] = []
    @Published private(set) var redoStack: [Composition] = []

    var selectedLayer: EditorLayer? {
        guard let selectedID else { return nil }
        return composition.layers.first { $0.id == selectedID }
    }

    func add(_ layer: EditorLayer) {
        saveUndo()
        composition.layers.append(layer)
        selectedID = layer.id
    }

    func importVideo(url: URL) {
        saveUndo()
        videoURL = url
        let duration = max(0.1, AVAsset(url: url).duration.seconds)
        composition.duration = duration
        trimStart = 0
        trimEnd = duration
        let layer = EditorLayer(name: "Vídeo", kind: .video, sourcePath: url.path)
        composition.layers.removeAll()
        composition.layers.append(layer)
        selectedID = layer.id
        currentTime = 0
    }

    func deleteSelected() {
        guard let id = selectedID else { return }
        saveUndo()
        composition.layers.removeAll { $0.id == id }
        if composition.layers.isEmpty { videoURL = nil }
        selectedID = composition.layers.last?.id
    }

    func duplicateSelected() {
        guard let layer = selectedLayer else { return }
        saveUndo()
        var copy = layer
        copy.id = UUID()
        copy.name += " Copy"
        composition.layers.append(copy)
        selectedID = copy.id
    }

    func splitSelected() {
        guard let layer = selectedLayer else { return }
        saveUndo()
        var copy = layer
        copy.id = UUID()
        copy.name += " Split"
        composition.layers.append(copy)
        selectedID = copy.id
    }

    func addText() { add(EditorLayer(name: "Texto", kind: .text)) }
    func addSolid() { add(EditorLayer(name: "Sólido", kind: .solid, colorHex: "#222222")) }
    func addShape() { add(EditorLayer(name: "Forma", kind: .shape)) }

    func updateSelected(opacity: Double? = nil, scale: Double? = nil, rotation: Double? = nil) {
        guard let id = selectedID, let i = composition.layers.firstIndex(where: { $0.id == id }) else { return }
        if let opacity { composition.layers[i].opacity = opacity }
        if let scale { composition.layers[i].scale = scale }
        if let rotation { composition.layers[i].rotation = rotation }
    }

    func undo() {
        guard let previous = undoStack.popLast() else { return }
        redoStack.append(composition)
        composition = previous
        selectedID = composition.layers.last?.id
    }

    func redo() {
        guard let next = redoStack.popLast() else { return }
        undoStack.append(composition)
        composition = next
        selectedID = composition.layers.last?.id
    }

    func resetEffects() {
        brightness = 0; contrast = 1; saturation = 1; blur = 0
    }

    private func saveUndo() {
        undoStack.append(composition)
        if undoStack.count > 40 { undoStack.removeFirst() }
        redoStack.removeAll()
    }
}
