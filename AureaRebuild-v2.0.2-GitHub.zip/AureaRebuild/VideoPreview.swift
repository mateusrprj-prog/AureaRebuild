import SwiftUI
import AVKit

struct VideoPreview: View {
    let url: URL?
    @Binding var currentTime: Double
    @Binding var isPlaying: Bool

    var body: some View {
        ZStack {
            Color.black
            if let url {
                VideoPlayer(player: PlayerStore.shared.player(for: url))
                    .onAppear { PlayerStore.shared.playIfNeeded(url: url, playing: isPlaying) }
                    .onChange(of: isPlaying) { _, value in
                        if value { PlayerStore.shared.play(url: url) } else { PlayerStore.shared.pause(url: url) }
                    }
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "film.stack")
                        .font(.system(size: 44))
                    Text("Importe um vídeo para começar")
                        .font(.headline)
                    Text("Aurea V2")
                        .foregroundStyle(.secondary)
                }
                .foregroundStyle(.white)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

final class PlayerStore {
    static let shared = PlayerStore()
    private var players: [String: AVPlayer] = [:]
    private init() {}

    func player(for url: URL) -> AVPlayer {
        if let p = players[url.path] { return p }
        let p = AVPlayer(url: url)
        players[url.path] = p
        return p
    }

    func play(url: URL) { player(for: url).play() }
    func pause(url: URL) { player(for: url).pause() }
    func playIfNeeded(url: URL, playing: Bool) { if playing { play(url: url) } }
}
