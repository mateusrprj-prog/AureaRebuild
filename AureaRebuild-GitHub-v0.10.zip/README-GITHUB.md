# AureaRebuild GitHub Build v0.10

Independent SwiftUI reconstruction prototype.

This package contains the XcodeGen project specification and source code. The GitHub Actions workflow in the user's repository extracts this ZIP, generates the Xcode project, and builds an unsigned iOS archive.

v0.10 fixes the Swift syntax errors in EditorView and exposes a public Composition initializer required by the public EditorModel initializer.
