import XCTest
@testable import AureaRebuild
final class EditorModelTests:XCTestCase{@MainActor func testSplit(){let s=EditorStore();s.addLayer(Layer(name:"A",kind:.solid,duration:10));s.composition.playhead=4;s.splitSelected();XCTAssertEqual(s.composition.layers.count,2)};func testBezier(){XCTAssertEqual(CubicBezier.linear.solve(0.5),0.5,accuracy:0.001)}}
