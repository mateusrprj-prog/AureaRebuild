// swift-tools-version: 5.9
import PackageDescription
let package = Package(name:"AureaRebuild", platforms:[.iOS(.v16)], products:[.library(name:"AureaRebuild",targets:["AureaRebuild"])], targets:[.target(name:"AureaRebuild",path:"AureaRebuild"),.testTarget(name:"AureaRebuildTests",dependencies:["AureaRebuild"],path:"AureaRebuildTests")])
