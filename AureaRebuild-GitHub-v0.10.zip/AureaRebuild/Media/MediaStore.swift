import Combine
import Foundation
import PhotosUI
import AVFoundation

@MainActor public final class MediaStore: ObservableObject {
    @Published public var selectedItems:[PhotosPickerItem]=[]
    @Published public var importedURLs:[URL]=[]
    public func importItems(){ Task { for item in selectedItems { if let data=try? await item.loadTransferable(type:Data.self) { let ext=(item.supportedContentTypes.first?.preferredFilenameExtension) ?? "dat"; let url=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext); try? data.write(to:url); importedURLs.append(url) } } } }
    public func metadata(for url:URL) async -> (Double,CGSize)? { let asset=AVURLAsset(url:url); let duration=(try? await asset.load(.duration).seconds) ?? 0; let tracks=(try? await asset.loadTracks(withMediaType:.video)) ?? []; let size=(try? await tracks.first?.load(.naturalSize)) ?? .zero; return (duration,size) }
}
