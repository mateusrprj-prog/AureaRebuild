import Foundation
import CoreImage
import CoreImage.CIFilterBuiltins
import AVFoundation

public final class PreviewRenderer {
    public let context: CIContext
    public init(){ context=CIContext(options:[.workingColorSpace: NSNull()]) }
    public func apply(_ image: CIImage, effects:[Effect]) -> CIImage {
        var output=image
        for effect in effects where effect.enabled {
            let n=effect.name.lowercased(); let v=Float(effect.intensity)
            if n.contains("blur") { let f=CIFilter.gaussianBlur(); f.inputImage=output; f.radius=v*12; output=f.outputImage ?? output }
            else if n.contains("sharpen") { let f=CIFilter.sharpenLuminance(); f.inputImage=output; f.sharpness=v; output=f.outputImage ?? output }
            else if n.contains("brightness") { let f=CIFilter.colorControls(); f.inputImage=output; f.brightness=v-1; output=f.outputImage ?? output }
            else if n.contains("contrast") { let f=CIFilter.colorControls(); f.inputImage=output; f.contrast=v; output=f.outputImage ?? output }
            else if n.contains("saturation") { let f=CIFilter.colorControls(); f.inputImage=output; f.saturation=v; output=f.outputImage ?? output }
            else if n.contains("grayscale") { let f=CIFilter.colorMonochrome(); f.inputImage=output; f.intensity=v; output=f.outputImage ?? output }
            else if n.contains("invert") { let f=CIFilter.colorInvert(); f.inputImage=output; output=f.outputImage ?? output }
        }
        return output
    }
}
