import Combine
import Foundation

@MainActor public final class ProjectStore: ObservableObject {
    @Published public private(set) var projects:[Composition]=[]
    private let root: URL
    public init(){ root = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("AureaProjects",isDirectory:true); try? FileManager.default.createDirectory(at:root,withIntermediateDirectories:true); load() }
    public func save(_ project:Composition) throws { let data=try JSONEncoder().encode(project); try data.write(to:root.appendingPathComponent(project.id.uuidString).appendingPathExtension("json")); load() }
    public func delete(_ project:Composition){ try? FileManager.default.removeItem(at:root.appendingPathComponent(project.id.uuidString).appendingPathExtension("json")); load() }
    public func load(){ projects=(try? FileManager.default.contentsOfDirectory(at:root,includingPropertiesForKeys:nil).compactMap{try? JSONDecoder().decode(Composition.self,from:Data(contentsOf:$0))}) ?? [] }
}
