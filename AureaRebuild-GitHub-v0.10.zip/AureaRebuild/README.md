# Aurea Rebuild v0.9

Grande atualização do núcleo do editor, construída como implementação independente baseada na observação da superfície funcional do IPA fornecido.

## Incluído
- modelo Codable de composição/layers;
- timeline, split, trim, duplicate, delete;
- undo/redo transacional;
- keyframes e curvas linear/ease-in/ease-out/ease-in-out;
- importação via PhotosPicker;
- preview/editor SwiftUI;
- inspector de opacity, scale e rotation;
- blend modes e efeitos como dados de projeto;
- Core Image para blur, sharpen, brightness, contrast, saturation, grayscale e invert;
- persistência de projetos em Application Support;
- export pipeline H.264 baseado em AVAssetWriter;
- comandos e presets observados no pacote original preservados em Resources.

## Próxima etapa
Compilar em Xcode para iOS, corrigir incompatibilidades de SDK/assinatura e gerar o primeiro IPA de teste para ESign.
