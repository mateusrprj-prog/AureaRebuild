import Foundation
import AVFoundation

public final class CompositionExporter {
    public init() {}
    public func exportVideo(composition:Composition, to url:URL, progress:@escaping(Double)->Void) async throws {
        let writer=try AVAssetWriter(outputURL:url,fileType:.mp4)
        let settings:[String:Any]=[AVVideoCodecKey:AVVideoCodecType.h264,AVVideoWidthKey:composition.width,AVVideoHeightKey:composition.height]
        let input=AVAssetWriterInput(mediaType:.video,outputSettings:settings); input.expectsMediaDataInRealTime=false; writer.add(input)
        guard writer.startWriting() else { throw writer.error ?? NSError(domain:"AureaExport",code:1) }; writer.startSession(atSourceTime:.zero)
        let frameCount=Int(composition.duration*composition.fps); let adaptor=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:input,sourcePixelBufferAttributes:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA,kCVPixelBufferWidthKey as String:composition.width,kCVPixelBufferHeightKey as String:composition.height])
        for frame in 0..<frameCount { while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds:2_000_000) }; guard let pb=makeBuffer(width:composition.width,height:composition.height) else {continue}; let time=CMTime(value:CMTimeValue(frame),timescale:CMTimeScale(composition.fps)); adaptor.append(pb,withPresentationTime:time); progress(Double(frame+1)/Double(max(frameCount,1))) }
        input.markAsFinished(); await writer.finishWriting(); if writer.status != .completed { throw writer.error ?? NSError(domain:"AureaExport",code:2) }
    }
    private func makeBuffer(width:Int,height:Int)->CVPixelBuffer? { var pb:CVPixelBuffer?; CVPixelBufferCreate(kCFAllocatorDefault,width,height,kCVPixelFormatType_32BGRA,[kCVPixelBufferCGImageCompatibilityKey:true,kCVPixelBufferCGBitmapContextCompatibilityKey:true] as CFDictionary,&pb); return pb }
}
